#!/usr/bin/env python3
"""
Long COVID (PASC) Case-Finding Precision and Demographic Skew Simulator
Reference implementation of the spec's arithmetic. Standard library only.
"""

# ---------------------------------------------------------------------------
# Default inputs
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "covid_case_count": 85364,              # patients
    "raw_prevalence_percent": 28.5,         # percent
    "algorithm_ppv_percent": 79.9,          # percent
    "u09_9_ppv_percent": 77.8,              # percent
    "u09_9_raw_count": 6340,                # patients
    "female_share_u09_percent": 67.5,       # percent
    "female_share_algorithm_percent": 64.5, # percent
}


# ---------------------------------------------------------------------------
# Output computations (mirrors the "expression" trees in the spec exactly)
# ---------------------------------------------------------------------------

def ppv_adjusted_prevalence_percent(inputs):
    """(raw_prevalence/100) * (algorithm_ppv/100) * 100"""
    raw = inputs["raw_prevalence_percent"] / 100.0
    ppv = inputs["algorithm_ppv_percent"] / 100.0
    return (raw * ppv) * 100.0


def u09_9_estimated_true_count(inputs):
    """u09_9_raw_count * (u09_9_ppv_percent/100)"""
    return inputs["u09_9_raw_count"] * (inputs["u09_9_ppv_percent"] / 100.0)


def algorithm_identified_adjusted_count(inputs):
    """covid_case_count * (raw_prevalence/100) * (algorithm_ppv/100)"""
    raw = inputs["raw_prevalence_percent"] / 100.0
    ppv = inputs["algorithm_ppv_percent"] / 100.0
    return inputs["covid_case_count"] * (raw * ppv)


def female_share_difference_pp(inputs):
    """female_share_algorithm - female_share_u09"""
    return inputs["female_share_algorithm_percent"] - inputs["female_share_u09_percent"]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def compute_all_outputs(inputs):
    return {
        "ppv_adjusted_prevalence_percent": ppv_adjusted_prevalence_percent(inputs),
        "u09_9_estimated_true_count": u09_9_estimated_true_count(inputs),
        "algorithm_identified_adjusted_count": algorithm_identified_adjusted_count(inputs),
        "female_share_difference_pp": female_share_difference_pp(inputs),
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    results = compute_all_outputs(inputs)

    print("Long COVID (PASC) Case-Finding Precision and Demographic Skew Simulator")
    print("=" * 75)
    print("\nInputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key}: {value}")

    print("\nOutputs:")
    print(
        "  ppv_adjusted_prevalence_percent "
        f"(PPV-adjusted PASC prevalence, %): "
        f"{results['ppv_adjusted_prevalence_percent']:.4f}"
    )
    print(
        "  u09_9_estimated_true_count "
        f"(Estimated confirmed-PASC count among U09.9-coded patients): "
        f"{results['u09_9_estimated_true_count']:.4f}"
    )
    print(
        "  algorithm_identified_adjusted_count "
        f"(Estimated PPV-adjusted long-hauler count, algorithm): "
        f"{results['algorithm_identified_adjusted_count']:.4f}"
    )
    print(
        "  female_share_difference_pp "
        f"(Female-share difference, algorithm minus U09.9, pp): "
        f"{results['female_share_difference_pp']:.4f}"
    )