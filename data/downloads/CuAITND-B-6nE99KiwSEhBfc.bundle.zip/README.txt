================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : CuAITND-B-6nE99KiwSEhBfc
    Generated   : 2026-10-09 03:04:25 UTC
================================================================

TITLE
-----
Long COVID (PASC) Case-Finding Precision and Demographic Skew Simulator

BOUNDARY
--------
This simulator covers only what Azhir et al. (2025, Med) measured: how precisely a computational phenotyping algorithm versus the standard U09.9 diagnosis code identifies likely long COVID ('PASC', post-acute sequelae of COVID-19) patients from electronic health records at one Massachusetts health system (Mass General Brigham), including how demographically representative each method's identified group is. It contains no dollar costs, productivity loss, caregiving burden, insurance/access data, or Lyme disease content of any kind. All counts and percentages apply only to this one health system's 2020-2023 COVID-19 case cohort and should not be treated as nationally representative.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed methods study that built and validated a computational algorithm to identify patients with post-acute sequelae of COVID-19 (PASC, i.e., long COVID) from electronic health record data across 14 hospitals and 20 community health centers in Massachusetts (Mass General Brigham system). Using records from over 295,000 patients, the algorithm flagged 24,360 'long-haulers' among 85,364 COVID-19 cases (an adjusted prevalence of 22.8%) with 79.9% precision, which the authors say outperforms the standard U09.9 ICD-10 diagnosis code (77.8% precision in their own chart review) and shows less demographic bias in who gets identified as having long COVID. The paper documents that relying on diagnosis codes alone (U09.9) captures far fewer and a demographically skewed subset of likely PASC patients, and it reports which organ systems are most affected and how the odds of PASC differ by sex, race/ethnicity, and age. It contains no dollar costs, no direct/indirect economic burden figures, no insurance/access-barrier data, and no Lyme disease content of any kind.

WHY THIS COULD BE USEFUL
------------------------
This document is a clinical/informatics methods study, not a cost-of-illness report, so a simulator built from it cannot supply dollar costs, productivity loss, or caregiving burden for long COVID or Lyme disease. What it can usefully inform is how much claims/EHR diagnosis-code-based counts of long COVID likely undercount and demographically skew the true patient population, and which organ systems carry the largest share of persistent post-COVID symptom burden within a studied health system. Care-delivery teams, EHR/informatics teams, and research-cohort designers are the most direct audiences; patient/advocate and payer/policy audiences could use the precision/undercounting findings only as context for why official U09.9-based counts may understate need, not as a cost figure.

WHAT YOU COULD DO WITH IT
-------------------------
- Health-system informatics or care-delivery teams can use the documented gap between U09.9-code-based ascertainment (77.8% PPV, 6,340 raw coded patients, an estimated 'under 5,000' true PASC cases) and the precision-algorithm estimate (79.9% PPV, 22.8% adjusted prevalence among COVID-19 cases) to gauge how much relying on diagnosis codes alone may undercount the population that actually needs long COVID follow-up care.
- Clinical-trial and research-cohort designers can use the paper's demographic representativeness findings (U09.9-coded patients skewed toward White, female patients relative to the Massachusetts census; the precision algorithm's cohort is somewhat less skewed) to evaluate and improve recruitment equity for EHR-derived long COVID study cohorts.
- Care-coordination or capacity-planning teams within a comparable integrated health system can use the organ-system-specific case counts (e.g., ~10,044 with systemic sequelae, ~7,000 cardiovascular, >4,000 gastrointestinal, ~3,000 neurological) to anticipate which specialties see the largest share of long-hauler referrals, while treating these as Massachusetts-specific counts from one study period rather than national rates.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 196 Long COVID-related terms (for example, "post-acute sequelae", "PASC", "long COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Azhir 2025 phenotyping.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- COVID-19 case cohort size (patients), default 85364, source: Results, cohort description (p.3); this is the stated total adult COVID-19 case count in the MGB EHR cohort; 50000-120000 range is an assumed exploration bound, not from the source.
- Raw algorithm-flagged PASC share (percent), default 28.5, source: Results (p.3) and Discussion prevalence paragraph (p.8); 15-40 range is an assumed exploration bound, not from the source.
- Algorithm positive predictive value (percent), default 79.9, source: Results, chart-review paragraph (p.3); 60-95 range is an assumed exploration bound, not from the source.
- U09.9 diagnosis code positive predictive value (percent), default 77.8, source: Results, chart-review paragraph (p.3), which also cites a 40-65% precision range from prior literature; 40-95 range is an assumed exploration bound covering both this cohort's own figure and the cited prior-literature range.
- Patients with a U09.9 diagnosis code (patients), default 6340, source: Results (p.3); 2000-15000 range is an assumed exploration bound, not from the source.
- Female share among U09.9-coded patients (percent), default 67.5, source: Results (p.3) and Discussion bias paragraph (p.8); 50-80 range is an assumed exploration bound, not from the source.
- Female share among algorithm-identified long-haulers (percent), default 64.5, source: Results (p.3) and Discussion bias paragraph (p.8); 50-80 range is an assumed exploration bound, not from the source.

OUTPUTS (4)
-----------
- PPV-adjusted PASC prevalence: 22.77 (percent) at default assumptions
- Estimated confirmed-PASC count among U09.9-coded patients: 4,932.5 (patients) at default assumptions
- Estimated PPV-adjusted long-hauler count (algorithm): 19,438.7 (patients) at default assumptions
- Female-share difference, algorithm cohort minus U09.9-coded cohort (percentage points; positive = algorithm cohort has a higher female share, negative = lower): -3 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 503 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::4::Code Descriptions/icd10cm_order_2026.txt, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::1::Code Descriptions/icd10cmCodesFile.pdf, scope: both)

ORIGINAL SOURCE
---------------
Azhir A et al. Precision phenotyping for curating research cohorts of patients with unexplained post-acute sequelae of COVID-19. Med. 2025;6:100532
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39520983/
  DOI: https://doi.org/10.1016/j.medj.2024.10.009

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.