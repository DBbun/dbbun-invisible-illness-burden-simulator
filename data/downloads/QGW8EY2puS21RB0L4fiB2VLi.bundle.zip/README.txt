================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : QGW8EY2puS21RB0L4fiB2VLi
    Generated   : 2026-10-05 21:15:59 UTC
================================================================

TITLE
-----
Long COVID Prevalence Differences Across U.S. Adult Subgroups (NCHS 2022)

BOUNDARY
--------
This simulation represents only self-reported Long COVID prevalence percentages from the 2022 National Health Interview Survey (NCHS Data Brief No. 480), broken out by sex, age, and urbanization. It computes simple gaps between subgroup prevalence figures. It does NOT represent, and cannot be used to derive, any dollar cost, productivity loss, caregiving time, diagnostic delay, or insurance/access burden, because the source document reports none of these. It also does not represent a multi-year or lifetime estimate; all figures are a single cross-sectional year (2022).

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a CDC/NCHS Data Brief (No. 480, September 2023) using 2022 National Health Interview Survey data to report what percentage of U.S. adults ever had or currently have Long COVID, defined as self-reported symptoms lasting 3+ months after a positive test or doctor-diagnosed COVID-19. It breaks these percentages down by sex, age group, race/Hispanic origin, family income relative to the federal poverty level, and urbanization level. The document reports prevalence only - it contains no dollar costs, treatment costs, productivity-loss, caregiving-time, or insurance-access figures. Women, adults ages 35-49, and adults in more rural areas showed higher prevalence of both 'ever' and 'current' Long COVID, while Asian adults and higher-income adults (400%+ FPL) showed lower prevalence.

WHY THIS COULD BE USEFUL
------------------------
This document supplies population-level prevalence benchmarks (not cost data) that could help patients/advocates understand how common Long COVID is within their demographic group, help care delivery teams identify higher-prevalence subpopulations (women, adults 35-49, nonmetropolitan residents) for screening or outreach prioritization, and help payers/policymakers estimate the relative size of affected subpopulations for 2022. Any economic simulator built from this document alone would need to source cost-per-case, treatment-utilization, or productivity-loss data from elsewhere, since none is reported here. The demographic breakdowns are useful for equity-focused resource targeting given CDC's own protected-category framing (sex, age, race/ethnicity, income, urbanization).

WHAT YOU COULD DO WITH IT
-------------------------
- Policy or payer analysts can use the sex/age/race/income/urbanization prevalence breakdowns to estimate the relative size of affected adult subpopulations in 2022 for planning purposes, while sourcing cost-per-case data separately since this document reports no cost figures.
- Care delivery teams can use the higher-prevalence subgroups identified here (women, adults ages 35-49, nonmetropolitan/rural residents) to prioritize screening, outreach, or clinical-capacity planning for Long COVID.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 127 Long COVID-related terms (for example, "Long COVID", "post-acute sequelae", "PASC"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
db480-tables.pdf
db480.pdf

PARAMETERS (8)
--------------
- Ever Long COVID prevalence - women (percent of adults), default 8.5, source: NCHS Data Brief No. 480, Figure 1 and text, page 1-2; the 0-15 exploration range is an assumed bound, not from the source.
- Ever Long COVID prevalence - men (percent of adults), default 5.2, source: NCHS Data Brief No. 480, Figure 1 and text, page 1-2; the 0-15 exploration range is an assumed bound, not from the source.
- Current Long COVID prevalence - women (percent of adults), default 4.4, source: NCHS Data Brief No. 480, Figure 1 and text, page 1-2; the 0-15 exploration range is an assumed bound, not from the source.
- Current Long COVID prevalence - men (percent of adults), default 2.3, source: NCHS Data Brief No. 480, Figure 1 and text, page 1-2; the 0-15 exploration range is an assumed bound, not from the source.
- Ever Long COVID prevalence - ages 35-49 (percent of adults), default 8.9, source: NCHS Data Brief No. 480, Figure 2 and text, page 2; the 0-15 exploration range is an assumed bound, not from the source.
- Ever Long COVID prevalence - ages 65+ (percent of adults), default 4.1, source: NCHS Data Brief No. 480, Figure 2 and text, page 2; the 0-15 exploration range is an assumed bound, not from the source.
- Ever Long COVID prevalence - nonmetropolitan areas (percent of adults), default 7.7, source: NCHS Data Brief No. 480, Figure 5 and text, page 5; the 0-15 exploration range is an assumed bound, not from the source.
- Ever Long COVID prevalence - large central metropolitan areas (percent of adults), default 6.3, source: NCHS Data Brief No. 480, Figure 5 and text, page 5; the 0-15 exploration range is an assumed bound, not from the source.

OUTPUTS (4)
-----------
- Ever Long COVID prevalence gap: women minus men (positive = women higher, negative = men higher): 3.3 (percentage points) at default assumptions
- Current Long COVID prevalence gap: women minus men (positive = women higher, negative = men higher): 2.1 (percentage points) at default assumptions
- Ever Long COVID prevalence gap: ages 35-49 minus ages 65+ (positive = younger group higher, negative = older group higher): 4.8 (percentage points) at default assumptions
- Ever Long COVID prevalence gap: nonmetropolitan minus large central metro (positive = nonmetro higher, negative = large metro higher): 1.4 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle04_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle04_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle05_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle05_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle06_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle06_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle07_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle07_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-2Cycle08_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.2 Cycle08_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-2Cycle09_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.2 Cycle09_CSV .xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week58_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_58.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4Cycle01_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.0 Cycle01_CSV.xlsx, scope: long_covid)

ORIGINAL SOURCE
---------------
Adjaye-Gbewonyo D, Vahratian A, Perrine CG, Bertolli J. Long COVID in adults: United States, 2022. NCHS Data Brief No. 480, National Center for Health Statistics (CDC). September 2023
  DOI: https://doi.org/10.15620/cdc:132417
  CDC page: https://www.cdc.gov/nchs/products/databriefs/db480.htm
  PDF: https://www.cdc.gov/nchs/data/databriefs/db480.pdf
  Data tables: https://www.cdc.gov/nchs/data/databriefs/db480-tables.pdf

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.