#!/usr/bin/env python3
"""
Reference implementation: Long COVID Prevalence Differences Across
U.S. Adult Subgroups (NCHS 2022)

Source-grounded reference implementation of subgroup prevalence gaps
from NCHS Data Brief No. 480 (2022 National Health Interview Survey).
Standard library only. No statistical modeling, sampling, or synthetic
patients are introduced here - this merely computes the simple
subtraction expressions defined in the spec.
"""

# ---------------------------------------------------------------------
# Default inputs (all values are percent of adults, as reported in
# NCHS Data Brief No. 480)
# ---------------------------------------------------------------------

DEFAULT_INPUTS = {
    "ever_prevalence_women": 8.5,
    "ever_prevalence_men": 5.2,
    "current_prevalence_women": 4.4,
    "current_prevalence_men": 2.3,
    "ever_prevalence_age_3549": 8.9,
    "ever_prevalence_age_65plus": 4.1,
    "ever_prevalence_nonmetro": 7.7,
    "ever_prevalence_large_central_metro": 6.3,
}


def compute_outputs(inputs):
    """Compute the four subgroup prevalence gap outputs.

    Each output is a simple subtraction (percentage points) between
    two subgroup prevalence percentages, exactly as specified.
    """

    sex_gap_ever = (
        inputs["ever_prevalence_women"] - inputs["ever_prevalence_men"]
    )

    sex_gap_current = (
        inputs["current_prevalence_women"] - inputs["current_prevalence_men"]
    )

    age_gap_ever = (
        inputs["ever_prevalence_age_3549"] - inputs["ever_prevalence_age_65plus"]
    )

    urbanization_gap_ever = (
        inputs["ever_prevalence_nonmetro"]
        - inputs["ever_prevalence_large_central_metro"]
    )

    return {
        "sex_gap_ever": sex_gap_ever,
        "sex_gap_current": sex_gap_current,
        "age_gap_ever": age_gap_ever,
        "urbanization_gap_ever": urbanization_gap_ever,
    }


if __name__ == "__main__":
    inputs = DEFAULT_INPUTS
    results = compute_outputs(inputs)

    print("Long COVID Prevalence Differences Across U.S. Adult Subgroups (NCHS 2022)")
    print("All figures are percentage points, derived from 2022 NHIS self-reported data.")
    print()

    print(
        "Ever Long COVID prevalence gap: women minus men = "
        f"{results['sex_gap_ever']:.2f} percentage points "
        f"(women {inputs['ever_prevalence_women']}%, men {inputs['ever_prevalence_men']}%)"
    )

    print(
        "Current Long COVID prevalence gap: women minus men = "
        f"{results['sex_gap_current']:.2f} percentage points "
        f"(women {inputs['current_prevalence_women']}%, men {inputs['current_prevalence_men']}%)"
    )

    print(
        "Ever Long COVID prevalence gap: ages 35-49 minus ages 65+ = "
        f"{results['age_gap_ever']:.2f} percentage points "
        f"(35-49 {inputs['ever_prevalence_age_3549']}%, 65+ {inputs['ever_prevalence_age_65plus']}%)"
    )

    print(
        "Ever Long COVID prevalence gap: nonmetropolitan minus large central metro = "
        f"{results['urbanization_gap_ever']:.2f} percentage points "
        f"(nonmetro {inputs['ever_prevalence_nonmetro']}%, "
        f"large metro {inputs['ever_prevalence_large_central_metro']}%)"
    )