================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : lhtYXPD8ZnO_6kfniR2ZNS3T
    Generated   : 2026-10-10 14:07:31 UTC
================================================================

TITLE
-----
Long COVID Care-Coordination and Symptom-Duration Explorer (Single-Clinic Qualitative Study, n=21)

BOUNDARY
--------
This simulation represents only what a qualitative interview study of 21 adult patients at one academic post-COVID recovery clinic reported: a stated range for how long severe symptoms lasted, the clinic's minimum eligibility duration, and the specialist types patients described being referred across. It contains no cost, insurance, income, or caregiving-time data from the document, because none were reported. The symptom-duration range (1-2 years) is a reported range, not a precise point estimate. The specialist-coordination-links output is an illustrative construct built for this simulator from a count of specialist types the study names; it is not a number the study itself calculated. Findings come from a single, self-selected, referral-based sample and must not be generalized to all long COVID patients.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a qualitative study in which researchers interviewed 21 adult patients at an academic medical center's post-COVID recovery clinic about their experiences seeking and receiving care for long COVID. Patients described barriers and facilitators to accessing care, confusion communicating symptoms across multiple specialists, frustration with normal test results or diagnoses not attributed to long COVID, uncertainty about treatment because evidence-based guidelines do not yet exist, and ongoing worries about long-term effects such as cognitive decline and life expectancy. The study documents care-coordination and diagnostic-uncertainty burdens qualitatively but does not quantify direct medical costs, non-medical costs, lost income, or caregiving time.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would be most useful to care delivery teams and health system administrators designing long COVID clinics or care-coordination pathways, and to patient/advocate audiences seeking language to validate common care-navigation frustrations (disbelief, fragmented specialist communication, uncertain treatment, normal test results, long-term health worries). Because the document contains no cost, insurance, or productivity-loss figures, it cannot inform payer/policy cost-modeling questions; any economic burden category must be flagged as unquantified rather than populated with estimates from this source.

WHAT YOU COULD DO WITH IT
-------------------------
- Health systems could use the documented care-coordination pain points (confusion communicating symptoms across specialists, frustration with normal/non-attributed test results, feeling nothing more can be done) to prioritize design features of multidisciplinary 'one-stop-shop' long COVID clinics.
- Patient advocacy groups could use the qualitative themes (provider disbelief, self-advocacy burden, worry about long-term cognitive/life-expectancy effects) to develop patient-facing communication guides for interactions with primary care and specialists, while explicitly noting that no cost or productivity data are available from this source.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 125 Long COVID-related terms (for example, "long COVID", "post-COVID", "post COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
MacEwan 2024 care coordination.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (4)
--------------
- Lower bound of reported symptom duration (months) (months), default 12, source: Limitations section, p.1299, states patients had symptoms for '1-2 years'; the lower bound (12 months) is used as the default. The 6-18 month range is an assumed exploration bound, not from the source.
- Upper bound of reported symptom duration (months) (months), default 24, source: Limitations section, p.1299, states patients had symptoms for '1-2 years'; the upper bound (24 months) is used as the default. The 18-30 month range is an assumed exploration bound, not from the source.
- Clinic minimum symptom-duration eligibility (months) (months), default 3, source: The study's population description states eligibility required symptoms impacting life for at least 3 months after infection (Limitations section context, p.1299). The 1-6 month range is an assumed exploration bound, not from the source.
- Number of distinct specialist referral types described (types), default 4, source: Results section names cardiology, physical therapy, rehabilitation psychology, and speech therapy as specialist referral types patients described navigating (specific page not given in the provided analysis excerpt); default of 4 reflects this count. The 1-6 range is an assumed exploration bound, not from the source.

OUTPUTS (3)
-----------
- Reported symptom-duration range width (upper minus lower bound): 12 (months) at default assumptions
- Lower-bound symptom duration minus clinic eligibility threshold (positive = even the shorter end of the reported range exceeded the minimum eligibility window; negative could not occur under the study's own criteria): 9 (months) at default assumptions
- Illustrative count of potential communication links among reported specialist types (not a figure reported by the study): 6 (links) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week58_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_58.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week59_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_59.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week60_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_60.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week46_PUF_CSV.zip::1::pulse2022_puf_46.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week47_PUF_CSV.zip::0::pulse2022_puf_47.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week48_PUF_CSV.zip::0::pulse2022_puf_48.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week61_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_61.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week62_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_62.xlsx, scope: long_covid)

ORIGINAL SOURCE
---------------
MacEwan SR et al. Patient Experiences Navigating Care Coordination For Long COVID: A Qualitative Study. J Gen Intern Med. 2024
  PubMed: https://pubmed.ncbi.nlm.nih.gov/38308155/
  DOI: https://doi.org/10.1007/s11606-024-08622-z

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.