#!/usr/bin/env python3
"""
Long COVID Care-Coordination and Symptom-Duration Explorer
(Single-Clinic Qualitative Study, n=21)

Standard-library-only reference implementation of the interactive spec.
This is NOT a reproduction of the source paper's statistical model; it
implements only the stated arithmetic for the stated default inputs,
plus the named scenarios as parameter overrides on those same formulas.
"""

TITLE = "Long COVID Care-Coordination and Symptom-Duration Explorer (Single-Clinic Qualitative Study, n=21)"

DEFAULT_INPUTS = {
    "duration_low_months": 12,
    "duration_high_months": 24,
    "eligibility_threshold_months": 3,
    "specialist_referral_types": 4,
}

SCENARIOS = [
    {
        "id": "baseline",
        "label": "Baseline (study defaults)",
        "overrides": {},
    },
    {
        "id": "narrower_duration_range",
        "label": "Shorter illustrative duration range",
        "overrides": {"duration_low_months": 6, "duration_high_months": 18},
    },
    {
        "id": "wider_duration_range",
        "label": "Longer illustrative duration range",
        "overrides": {"duration_low_months": 6, "duration_high_months": 30},
    },
    {
        "id": "stricter_eligibility_threshold",
        "label": "Stricter clinic eligibility policy",
        "overrides": {"eligibility_threshold_months": 6},
    },
    {
        "id": "fewer_specialist_types",
        "label": "Single specialist pathway",
        "overrides": {"specialist_referral_types": 1},
    },
    {
        "id": "more_specialist_types",
        "label": "Expanded specialist network",
        "overrides": {"specialist_referral_types": 6},
    },
]


def compute_outputs(inputs):
    """Compute the three spec outputs from a dict of inputs, using the
    exact arithmetic expressions given in the spec."""
    duration_low_months = inputs["duration_low_months"]
    duration_high_months = inputs["duration_high_months"]
    eligibility_threshold_months = inputs["eligibility_threshold_months"]
    specialist_referral_types = inputs["specialist_referral_types"]

    # duration_range_width_months = subtract(duration_high, duration_low)
    duration_range_width_months = duration_high_months - duration_low_months

    # low_end_duration_minus_eligibility_months = subtract(duration_low, eligibility_threshold)
    low_end_duration_minus_eligibility_months = (
        duration_low_months - eligibility_threshold_months
    )

    # specialist_coordination_links = (n * (n - 1)) / 2
    specialist_coordination_links = (
        specialist_referral_types * (specialist_referral_types - 1)
    ) / 2

    return {
        "duration_range_width_months": duration_range_width_months,
        "low_end_duration_minus_eligibility_months": low_end_duration_minus_eligibility_months,
        "specialist_coordination_links": specialist_coordination_links,
    }


def resolve_inputs(overrides):
    resolved = dict(DEFAULT_INPUTS)
    resolved.update(overrides)
    return resolved


def run_scenario(scenario):
    inputs = resolve_inputs(scenario["overrides"])
    outputs = compute_outputs(inputs)
    return inputs, outputs


def print_block(label, inputs, outputs):
    print(f"--- {label} ---")
    print("Inputs:")
    for k in (
        "duration_low_months",
        "duration_high_months",
        "eligibility_threshold_months",
        "specialist_referral_types",
    ):
        print(f"  {k}: {inputs[k]}")
    print("Outputs:")
    print(
        "  duration_range_width_months: "
        f"{outputs['duration_range_width_months']}"
    )
    print(
        "  low_end_duration_minus_eligibility_months: "
        f"{outputs['low_end_duration_minus_eligibility_months']}"
    )
    print(
        "  specialist_coordination_links: "
        f"{outputs['specialist_coordination_links']}"
    )
    print()


if __name__ == "__main__":
    print(TITLE)
    print()
    for scenario in SCENARIOS:
        inputs, outputs = run_scenario(scenario)
        print_block(scenario["label"], inputs, outputs)