================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 6AefGyqlhLgPS6uw_6vy_vi8
    Generated   : 2026-10-05 20:15:15 UTC
================================================================

TITLE
-----
Chronic Lyme Disease Patient-Reported Burden Simulator (Johnson et al. 2014)

BOUNDARY
--------
This simulation reproduces descriptive comparisons from a 2014 self-selected internet survey of 3,090 people with chronic Lyme disease (CLD), contrasted with published general-population figures the authors cite (NHIS, BLS/general-population employment, CDC surveillance). It does not compute a total medical-expenditure dollar figure or a dollar value of lost productivity, because the study itself states it was not designed to do either. All CLD figures come from a non-probability, forum-recruited sample and cannot be generalized to all Lyme disease patients.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 2014 peer-reviewed survey study (PeerJ) in which LymeDisease.org and academic co-authors used the CDC's 9-item health-related quality of life (HRQoL) metric to compare 3,090 self-selected online-survey respondents with chronic Lyme disease (CLD) - defined as clinically diagnosed Lyme disease with symptoms persisting more than six months after at least 21 days of antibiotic treatment - against published general-population and other-chronic-disease data. It reports that CLD respondents had markedly worse self-rated health, more bad physical/mental health days, high rates of severe symptoms, much greater healthcare utilization (doctor visits, ED visits, inpatient stays, homecare), higher self-reported out-of-pocket costs, and large declines in employment and work capacity compared with the general population. The authors explicitly state the study was not designed to calculate total medical expenditures or a dollar value for lost productivity, and the sample is a self-selected, non-probability internet sample recruited from Lyme patient forums.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this study's findings could help patient advocates and Lyme disease patient organizations illustrate the scale of self-reported functional impairment, healthcare utilization, and out-of-pocket cost burden faced by patients with persistent post-treatment Lyme disease symptoms. Care-delivery teams could use the diagnostic-delay and utilization figures to understand how late diagnosis correlates with worse self-rated health over time. Payers/policy audiences could reference the employment-loss and healthcare-utilization contrasts when discussing coverage of extended treatment for persistent symptoms, but the simulator cannot produce a total national medical expenditure or a dollar-denominated productivity-loss estimate, since the study itself did not calculate either.

WHAT YOU COULD DO WITH IT
-------------------------
- Patient advocates could use the out-of-pocket cost comparisons (e.g., 43% of CLD survey respondents vs. ~6% of the general population exceeding $5,000/year; Discussion states 46% vs. 5%) to illustrate financial burden in policy or insurance-coverage discussions, while flagging that this is a self-selected internet sample, not a probability sample, and that the two cited percentages are not fully consistent within the document itself.
- Payers/policy audiences could use the diagnostic-delay statistics (61.7% not diagnosed within 2 years) alongside employment-loss figures (42% stopped working, 24% of those receiving disability) to discuss the potential value of earlier diagnosis, while recognizing the study provides no dollar-denominated productivity-loss or total-expenditure estimate to plug directly into a cost model.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 70 Lyme-related terms (for example, "Lyme", "Borrelia", "Tick-Borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2014.pdf

PARAMETERS (7)
--------------
- CLD respondents with >$5,000/year out-of-pocket costs (%) (percent), default 43.2, source: Table 4 full-sample figure (43.2%), p.10-13 (Increased utilization of services; Discussion); default is the document's own reported value. 30-60 range is an assumed exploration bound, not from the source.
- General population with >$5,000/year out-of-pocket costs (%) (percent), default 6, source: NHIS 2011 comparison figure (~6%) cited on p.10-13; default is the document's own reported value. 2-10 range is an assumed exploration bound, not from the source.
- CLD respondents aged 25-54 employed (%) (percent), default 45.9, source: p.11-12 (Productivity losses), reported employment rate for CLD respondents age 25-54, March 2013. 20-60 range is an assumed exploration bound, not from the source.
- General population aged 25-54 employed (%) (percent), default 81.0, source: p.11-12 (Productivity losses), general-population comparison figure for age 25-54. 70-90 range is an assumed exploration bound, not from the source.
- CLD respondents not diagnosed within 2 years of symptom onset (%) (percent), default 61.7, source: p.3 (Patient Selection and Characteristics). 0-100 range is an assumed exploration bound, not from the source.
- CDC estimated annual U.S. Lyme disease diagnoses (cases/year), default 300000, source: p.2 (Introduction, citing CDC 2013b); p.14-15 (Discussion). 250000-350000 range is an assumed exploration bound, not from the source.
- Prior CDC surveillance-reported Lyme cases per year (cases/year), default 30000, source: p.14 (Discussion). 20000-40000 range is an assumed exploration bound, not from the source.

OUTPUTS (4)
-----------
- CLD out-of-pocket (>$5,000/year) share minus general-population share (percentage points; positive = CLD respondents more likely to exceed threshold, negative = general population more likely): 37.2 (percentage points) at default assumptions
- General-population employment rate (25-54) minus CLD employment rate (25-54) (percentage points; positive = CLD respondents employed at a lower rate, negative = CLD respondents employed at a higher rate): 35.1 (percentage points) at default assumptions
- Share of CLD respondents not diagnosed within 2 years of symptom onset: 61.7 (percent) at default assumptions
- CDC estimated diagnoses minus prior surveillance-reported case count (positive = broader estimate exceeds restrictive surveillance count; these are two different case-ascertainment methods, not a confidence range): 270000 (cases/year) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 384 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::548::SAGDP11_NY_1998_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson L et al. Severity of chronic Lyme disease compared to other chronic conditions: a quality of life survey. PeerJ. 2014
  PubMed: https://pubmed.ncbi.nlm.nih.gov/24749006/
  DOI: https://doi.org/10.7717/peerj.322

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.