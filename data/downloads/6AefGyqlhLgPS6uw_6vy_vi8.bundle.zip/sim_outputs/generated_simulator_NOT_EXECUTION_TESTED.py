#!/usr/bin/env python3
"""
Chronic Lyme Disease Patient-Reported Burden Simulator (Johnson et al. 2014)

Reference implementation of descriptive comparisons from a 2014 self-selected
internet survey of people with chronic Lyme disease (CLD), contrasted with
published general-population benchmarks cited by the authors (NHIS, BLS/
general-population employment, CDC surveillance). This script does not
compute a total medical-expenditure dollar figure or a dollar value of lost
productivity, since the source study was not designed to do either.

All default input values and ranges are taken from the spec; range bounds
not explicitly sourced in the document are labeled as assumed exploration
bounds, not source-reported figures.
"""

# ---------------------------------------------------------------------------
# Default inputs
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    # CLD respondents with >$5,000/year out-of-pocket costs (%)
    "pct_oop_over_5000_cld": 43.2,
    # General population with >$5,000/year out-of-pocket costs (%) (NHIS 2011)
    "pct_oop_over_5000_genpop": 6,
    # CLD respondents aged 25-54 employed (%) (March 2013)
    "pct_employed_cld_25_54": 45.9,
    # General population aged 25-54 employed (%) (2013)
    "pct_employed_genpop_25_54": 81.0,
    # CLD respondents not diagnosed within 2 years of symptom onset (%)
    "pct_not_diagnosed_2yr": 61.7,
    # CDC estimated annual U.S. Lyme disease diagnoses (2013 estimate)
    "cdc_estimated_diagnoses": 300000,
    # Prior CDC surveillance-reported Lyme cases per year
    "cdc_surveillance_reported_cases": 30000,
}


# ---------------------------------------------------------------------------
# Output computations
# ---------------------------------------------------------------------------

def compute_oop_cost_burden_gap(inputs):
    """CLD >$5000/yr OOP share minus general-population share (pct points)."""
    return inputs["pct_oop_over_5000_cld"] - inputs["pct_oop_over_5000_genpop"]


def compute_employment_rate_gap(inputs):
    """General-population employment rate (25-54) minus CLD rate (25-54)."""
    return inputs["pct_employed_genpop_25_54"] - inputs["pct_employed_cld_25_54"]


def compute_diagnostic_delay_share(inputs):
    """Share of CLD respondents not diagnosed within 2 years of onset."""
    return inputs["pct_not_diagnosed_2yr"]


def compute_surveillance_case_gap(inputs):
    """CDC estimated diagnoses minus prior surveillance-reported case count."""
    return inputs["cdc_estimated_diagnoses"] - inputs["cdc_surveillance_reported_cases"]


def compute_all_outputs(inputs):
    return {
        "oop_cost_burden_gap": compute_oop_cost_burden_gap(inputs),
        "employment_rate_gap": compute_employment_rate_gap(inputs),
        "diagnostic_delay_share": compute_diagnostic_delay_share(inputs),
        "surveillance_case_gap": compute_surveillance_case_gap(inputs),
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_all_outputs(inputs)

    print("Chronic Lyme Disease Patient-Reported Burden Simulator")
    print("(Johnson et al. 2014) - default inputs\n")

    print("Inputs:")
    for key, value in inputs.items():
        print(f"  {key}: {value}")

    print("\nOutputs:")
    print(
        "  oop_cost_burden_gap (percentage points, CLD minus general "
        f"population): {outputs['oop_cost_burden_gap']}"
    )
    print(
        "  employment_rate_gap (percentage points, general population "
        f"minus CLD, ages 25-54): {outputs['employment_rate_gap']}"
    )
    print(
        "  diagnostic_delay_share (% not diagnosed within 2 years): "
        f"{outputs['diagnostic_delay_share']}"
    )
    print(
        "  surveillance_case_gap (cases/year, CDC estimate minus prior "
        f"surveillance count): {outputs['surveillance_case_gap']}"
    )

    print(
        "\nNote: These are descriptive gaps from a self-selected, "
        "non-probability patient survey compared with cited general-"
        "population or CDC benchmarks. They are not calibrated national "
        "cost, incidence, or causal estimates, and patient out-of-pocket "
        "payments are never added into any total expenditure figure here."
    )