#!/usr/bin/env python3
"""
Long COVID Care-Coordination Navigation Burden
(Illustrative, Qualitative-Study-Based)

Reference implementation of the interactive spec's arithmetic only.
Standard library only. No synthetic patients, no sampling, no plots,
no CSV output, no CLI.
"""


# ---- Default inputs ---------------------------------------------------

DEFAULT_INPUTS = {
    "symptom_duration_years": 1.5,
    "num_specialist_referrals": 3,
    "diagnostic_test_rounds": 2,
    "barrier_theme_count": 5,
}


# ---- Output computations -----------------------------------------------

def compute_total_care_navigation_touchpoints(inputs):
    """total_care_navigation_touchpoints = num_specialist_referrals + diagnostic_test_rounds"""
    return inputs["num_specialist_referrals"] + inputs["diagnostic_test_rounds"]


def compute_specialist_referral_share(inputs, total_care_navigation_touchpoints):
    """specialist_referral_share = num_specialist_referrals / total_care_navigation_touchpoints"""
    return inputs["num_specialist_referrals"] / total_care_navigation_touchpoints


def compute_total_navigation_burden_index(inputs, total_care_navigation_touchpoints):
    """total_navigation_burden_index = total_care_navigation_touchpoints + barrier_theme_count"""
    return total_care_navigation_touchpoints + inputs["barrier_theme_count"]


def compute_severe_symptom_duration_display(inputs):
    """severe_symptom_duration_display = symptom_duration_years * 1"""
    return inputs["symptom_duration_years"] * 1


def compute_all_outputs(inputs):
    total_care_navigation_touchpoints = compute_total_care_navigation_touchpoints(inputs)
    specialist_referral_share = compute_specialist_referral_share(
        inputs, total_care_navigation_touchpoints
    )
    total_navigation_burden_index = compute_total_navigation_burden_index(
        inputs, total_care_navigation_touchpoints
    )
    severe_symptom_duration_display = compute_severe_symptom_duration_display(inputs)

    return {
        "total_care_navigation_touchpoints": total_care_navigation_touchpoints,
        "specialist_referral_share": specialist_referral_share,
        "total_navigation_burden_index": total_navigation_burden_index,
        "severe_symptom_duration_display": severe_symptom_duration_display,
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_all_outputs(inputs)

    print("Long COVID Care-Coordination Navigation Burden")
    print("(Illustrative, Qualitative-Study-Based)")
    print()
    print("Inputs (defaults):")
    print(f"  symptom_duration_years      = {inputs['symptom_duration_years']}")
    print(f"  num_specialist_referrals    = {inputs['num_specialist_referrals']}")
    print(f"  diagnostic_test_rounds      = {inputs['diagnostic_test_rounds']}")
    print(f"  barrier_theme_count         = {inputs['barrier_theme_count']}")
    print()
    print("Outputs:")
    print(
        "  total_care_navigation_touchpoints (touchpoints) = "
        f"{outputs['total_care_navigation_touchpoints']}"
    )
    print(
        "  specialist_referral_share (fraction)             = "
        f"{outputs['specialist_referral_share']:.6f}"
    )
    print(
        "  total_navigation_burden_index (index points)     = "
        f"{outputs['total_navigation_burden_index']}"
    )
    print(
        "  severe_symptom_duration_display (years)          = "
        f"{outputs['severe_symptom_duration_display']}"
    )
    print()
    print(
        "Note: These are illustrative, qualitative-study-derived counts, not "
        "measured clinic metrics, costs, or prevalence estimates."
    )