================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : ilOjfHhbNLHAW2eSbmkHUMNY
    Generated   : 2026-10-05 21:16:21 UTC
================================================================

TITLE
-----
Long COVID Care-Coordination Navigation Burden (Illustrative, Qualitative-Study-Based)

BOUNDARY
--------
This simulation represents illustrative counts of care-coordination touchpoints and barrier themes drawn from a qualitative interview study of 21 long COVID patients at one academic medical center's post-COVID clinic (Aug-Sep 2022). It does not represent or estimate any dollar cost, income loss, prevalence, or national population figure, none of which this document reports. All counts except severe symptom duration are illustrative assumptions built to explore the study's themes, not measured averages.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a qualitative interview study (n=21) conducted at an Ohio State University Wexner Medical Center post-COVID recovery clinic in August-September 2022, examining how adult patients with long COVID experienced access to care, evaluation, treatment, and ongoing care concerns. Patients described being disbelieved or having symptoms misattributed by providers, confusion about which symptoms to report to which specialist, frustration when tests came back normal or diagnoses were not linked to COVID, and anxiety about long-term effects such as cognitive decline and shortened life expectancy. The authors conclude that healthcare systems are currently unprepared to coordinate care for this new chronic condition, citing a shortage of knowledgeable providers and a lack of evidence-based treatment guidelines. The study reports no dollar costs, no quantified productivity loss, and no formal economic burden estimates; its findings are entirely qualitative/experiential.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could not model dollar costs or prevalence (none are reported), but it could surface the qualitative care-coordination failure points patients experience: provider disbelief, confusing multi-specialist communication, inconclusive or misattributed test results, absence of treatment guidelines, and anxiety about long-term effects. Patients/advocates could use this to articulate and validate the practical burden of navigating care for long COVID. Care delivery teams could use the identified themes (access barriers, evaluation confusion, treatment uncertainty, ongoing care concerns) to redesign referral pathways or consider 'one-stop-shop' multidisciplinary clinic models, which the Discussion explicitly raises as a potential solution. Payers/policy audiences could use the systemic-gap description (provider shortage, lack of guidelines) to motivate investment in long COVID care infrastructure, though this document supplies no cost-effectiveness or budget-impact figures to support a financial business case.

WHAT YOU COULD DO WITH IT
-------------------------
- Illustrating, for patient/advocate audiences, the specific recurring care-coordination pain points (disbelief, fragmented specialist communication, inconclusive test results, no treatment guidelines) reported by long COVID patients, to support self-advocacy or clinic feedback.
- Informing care delivery teams' design of multidisciplinary or 'one-stop-shop' long COVID clinic models and referral/triage communication tools, directly referencing the barriers and facilitators to access described in this qualitative dataset.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 125 Long COVID-related terms (for example, "long COVID", "post-COVID", "post COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
MacEwan 2024 care coordination.pdf

PARAMETERS (4)
--------------
- Severe symptom duration among interviewed patients (years) (years), default 1.5, source: Document's Limitations section states many interviewed patients had been experiencing severe long COVID symptoms for 1-2 years; exact page not specified in the available analysis. The 1-2 range is the document's own stated range, used directly as the min/max here.
- Number of specialists typically involved (specialists), default 3, source: Document describes patients referred to multiple specialists including cardiology, physical therapy, and speech therapy among others (qualitative themes), but does not report a count per patient. 3 is an assumed illustrative default reflecting the specialties explicitly named; the 1-6 range is an assumed exploration bound, not from the source.
- Rounds of diagnostic testing before clarity (rounds), default 2, source: Document describes patients' frustration with diagnostic tests repeatedly coming back normal or not being linked to long COVID (qualitative theme), but does not report a specific number of testing rounds. 2 is an assumed illustrative default; the 1-5 range is an assumed exploration bound, not from the source.
- Distinct care-coordination barrier themes identified (themes), default 5, source: Count of distinct qualitative barrier themes described in the document (provider disbelief/dismissal, confusion over which symptoms to report to which specialist, inconclusive or misattributed test results, absence of evidence-based treatment guidelines, and anxiety about long-term effects). This is the analysis's own count of the document's reported themes, not a number the document states directly, so it is labeled assumed; the 3-7 range is an assumed exploration bound.

OUTPUTS (4)
-----------
- Total illustrative care navigation touchpoints (specialists + testing rounds): 5 (touchpoints) at default assumptions
- Specialist referrals as a share of total touchpoints: 0.6 (fraction) at default assumptions
- Illustrative combined navigation and barrier-theme index: 10 (index points (illustrative, unitless)) at default assumptions
- Severe symptom duration among interviewed patients (years, displayed): 1.5 (years) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week58_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_58.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week59_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_59.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week60_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_60.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week46_PUF_CSV.zip::1::pulse2022_puf_46.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week47_PUF_CSV.zip::0::pulse2022_puf_47.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week48_PUF_CSV.zip::0::pulse2022_puf_48.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week61_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_61.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week62_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_62.xlsx, scope: long_covid)

ORIGINAL SOURCE
---------------
MacEwan SR et al. Patient Experiences Navigating Care Coordination For Long COVID: A Qualitative Study. J Gen Intern Med. 2024
  PubMed: https://pubmed.ncbi.nlm.nih.gov/38308155/
  DOI: https://doi.org/10.1007/s11606-024-08622-z

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.