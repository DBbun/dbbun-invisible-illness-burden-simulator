#!/usr/bin/env python3
"""
Reference implementation of the spec:
"Excess Direct Medical Costs After COVID-19 Diagnosis (Post-COVID Conditions),
Privately Insured Under-65 Cohort, 2020"

Plain arithmetic reproduction of the documented comparisons. No synthetic
patients, no sampling, no plotting, no CLI.
"""

DEFAULT_INPUTS = {
    "child_excess_cost_1month": 208,
    "child_excess_cost_3month": 549,
    "child_excess_cost_6month": 1011,
    "adult_excess_cost_1month": 393,
    "adult_excess_cost_3month": 930,
    "adult_excess_cost_6month": 1562,
    "child_hospitalized_multiplier_6month": 9.47,
    "adult_hospitalized_multiplier_6month": 3.18,
}

SCENARIOS = {
    "narrowest_adult_child_gap": {
        "child_excess_cost_1month": 290,
        "adult_excess_cost_1month": 300,
        "child_excess_cost_6month": 1290,
        "adult_excess_cost_6month": 1300,
    },
    "widest_adult_child_gap": {
        "child_excess_cost_1month": 100,
        "adult_excess_cost_1month": 480,
        "child_excess_cost_6month": 700,
        "adult_excess_cost_6month": 1800,
    },
    "narrow_hospitalization_gap": {
        "child_hospitalized_multiplier_6month": 7.0,
        "adult_hospitalized_multiplier_6month": 5.0,
    },
    "wide_hospitalization_gap": {
        "child_hospitalized_multiplier_6month": 12.0,
        "adult_hospitalized_multiplier_6month": 2.0,
    },
}


def compute_outputs(inputs):
    """Compute all spec outputs from a dict of inputs using the same
    arithmetic expressions described in the spec (simple subtractions)."""
    out = {}

    out["adult_minus_child_excess_cost_1month"] = (
        inputs["adult_excess_cost_1month"] - inputs["child_excess_cost_1month"]
    )

    out["adult_minus_child_excess_cost_6month"] = (
        inputs["adult_excess_cost_6month"] - inputs["child_excess_cost_6month"]
    )

    out["adult_6month_minus_3month_incremental_cost"] = (
        inputs["adult_excess_cost_6month"] - inputs["adult_excess_cost_3month"]
    )

    out["child_6month_minus_3month_incremental_cost"] = (
        inputs["child_excess_cost_6month"] - inputs["child_excess_cost_3month"]
    )

    out["hospitalization_cost_multiplier_gap_6month"] = (
        inputs["child_hospitalized_multiplier_6month"]
        - inputs["adult_hospitalized_multiplier_6month"]
    )

    return out


def run_scenario(overrides=None):
    """Apply overrides on top of the default inputs and compute outputs."""
    inputs = dict(DEFAULT_INPUTS)
    if overrides:
        inputs.update(overrides)
    outputs = compute_outputs(inputs)
    return inputs, outputs


def print_results(name, inputs, outputs):
    print(f"--- {name} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    for k, v in outputs.items():
        print(f"  {k}: {v}")
    print()


if __name__ == "__main__":
    # Default inputs
    default_inputs, default_outputs = run_scenario()
    print_results("Default inputs", default_inputs, default_outputs)

    # Each named scenario, applied on top of defaults
    for scenario_id, overrides in SCENARIOS.items():
        scen_inputs, scen_outputs = run_scenario(overrides)
        print_results(scenario_id, scen_inputs, scen_outputs)