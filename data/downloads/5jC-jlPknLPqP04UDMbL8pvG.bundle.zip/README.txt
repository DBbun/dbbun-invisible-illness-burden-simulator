================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 5jC-jlPknLPqP04UDMbL8pvG
    Generated   : 2026-10-05 21:16:24 UTC
================================================================

TITLE
-----
Excess Direct Medical Costs After COVID-19 Diagnosis (Post-COVID Conditions), Privately Insured Under-65 Cohort, 2020

BOUNDARY
--------
This simulation reproduces the document's own claims-based comparisons of direct medical cost (combined payer-paid and patient-paid total expenditures) between privately insured people diagnosed with COVID-19 (April-August 2020) and matched uninfected controls, for children (0-17) and adults (18-64), across cumulative follow-up windows starting 31 days after diagnosis, plus the document's separately-reported hospitalization-associated cost ratios. It does not include out-of-pocket costs, productivity or caregiving losses (the authors state these were not measured), the cohort-wide 'up to' $47M/$308M extrapolated totals (population-level, not a national estimate), race/ethnicity/socioeconomic breakdowns (not available in this data), or any data beyond 6 months, beyond 2020, or outside privately insured unvaccinated people under 65.

ABOUT THE SOURCE DOCUMENT
-------------------------
This CDC-authored study used commercial insurance claims (IQVIA PharMetrics Plus) to compare direct medical costs, starting 31 days after a COVID-19 diagnosis, between privately insured people under 65 who were diagnosed with COVID-19 (April-August 2020) and matched people who were not. It finds that people with COVID-19 had notably higher medical costs than matched controls over the following 1, 3, and 6 months, with the gap larger for children than adults, larger for men than women in some windows, larger for adults aged 50-64, and much larger for those who had been hospitalized with COVID-19. The authors describe this as a lower-bound estimate of the economic burden of post-COVID-19 conditions, since no PCC-specific diagnosis code existed during the study period and the analysis captures only direct medical (not out-of-pocket or productivity) costs.

WHY THIS COULD BE USEFUL
------------------------
This document provides claims-based, age- and sex-disaggregated estimates of excess direct medical costs attributable to post-COVID-19 conditions among privately insured people under 65, plus a cost multiplier for those hospitalized with COVID-19. Payers and policy analysts could use these figures to bound the direct medical cost burden of PCC in a commercially insured population for budget or cost-effectiveness modeling (e.g., of vaccination), while recognizing the authors' own framing of this as a lower-bound, first-pandemic-year, unvaccinated-cohort estimate. Care delivery teams could use the age/hospitalization patterns (higher excess costs among adults 50-64 and among hospitalized patients) to anticipate which post-COVID patients may need more follow-up care coordination. Patients and advocates could use the sex- and age-specific figures to understand that cost burden is not uniform, but the document itself warns these are population averages from a specific insured cohort, not predictors of any individual's bill, and exclude out-of-pocket costs and productivity/caregiving losses entirely.

WHAT YOU COULD DO WITH IT
-------------------------
- A payer or health-system analyst models the likely direct medical cost add-on of PCC in a commercially insured population under 65 using the per-patient excess cost figures by age group and hospitalization status, while treating the $47M/$308M cohort totals as study-specific extrapolations, not a national estimate.
- A care-coordination team uses the finding that excess PCC costs are concentrated in older adults (50-64) and in those with a COVID-19 hospitalization to prioritize structured follow-up outreach for those subgroups, while noting the study provides no data on children's or adults' costs beyond 6 months.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 6 Long COVID-related terms (for example, "U09.9", "post-COVID", "post-acute sequelae"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Pike 2023.pdf

PARAMETERS (8)
--------------
- Children's excess direct medical cost, 1-month window (USD), default 208, source: Table 2, p.9; the 100-290 range is an assumed exploration bound around the reported $208 figure, not from the source
- Children's excess direct medical cost, 3-month window (USD), default 549, source: Table 2, p.9; the 310-650 range is an assumed exploration bound around the reported $549 figure, not from the source
- Children's excess direct medical cost, 6-month window (USD), default 1011, source: Table 2, p.9; the 700-1290 range is an assumed exploration bound around the reported $1,011 figure, not from the source
- Adults' excess direct medical cost, 1-month window (USD), default 393, source: Table 2, p.9; the 300-480 range is an assumed exploration bound around the reported $393 figure, not from the source
- Adults' excess direct medical cost, 3-month window (USD), default 930, source: Table 2, p.9; the 700-1100 range is an assumed exploration bound around the reported $930 figure, not from the source
- Adults' excess direct medical cost, 6-month window (USD), default 1562, source: Table 2, p.9; the 1300-1800 range is an assumed exploration bound around the reported $1,562 figure, not from the source
- Children's hospitalized-vs-non-hospitalized cost ratio, 6-month window (ratio (dimensionless)), default 9.47, source: Table 4, p.11; the 7.0-12.0 range is an assumed exploration bound around the reported 9.47 figure, not from the source
- Adults' hospitalized-vs-non-hospitalized cost ratio, 6-month window (ratio (dimensionless)), default 3.18, source: Table 4, p.11; the 2.0-5.0 range is an assumed exploration bound around the reported 3.18 figure, not from the source

OUTPUTS (5)
-----------
- Adults minus children's excess direct medical cost, 1-month window (positive = adults' excess cost exceeds children's; negative = children's exceeds adults'): 185 (USD) at default assumptions
- Adults minus children's excess direct medical cost, 6-month window (positive = adults' excess cost exceeds children's; negative = children's exceeds adults'): 551 (USD) at default assumptions
- Adults' 6-month minus 3-month cumulative excess cost (positive = additional excess cost accrued between months 3 and 6): 632 (USD) at default assumptions
- Children's 6-month minus 3-month cumulative excess cost (positive = additional excess cost accrued between months 3 and 6): 462 (USD) at default assumptions
- Children's minus adults' hospitalized-vs-non-hospitalized cost ratio, 6-month window (positive = the hospitalization cost ratio is larger for children than adults; negative = the reverse): 6.29 (ratio (dimensionless) difference) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::436::SAGDP8_US_1997_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)

ORIGINAL SOURCE
---------------
Pike J et al. Direct Medical Costs Associated With Post-COVID-19 Conditions Among Privately Insured Children and Adults. Prev Chronic Dis. 2023
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36757854/
  DOI: https://doi.org/10.5888/pcd20.220292

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.