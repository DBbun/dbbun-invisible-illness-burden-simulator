DEFAULTS = {
    "pld_late_diagnosis_share": 77,
    "pld_misdiagnosis_share": 74,
    "pld_no_insurance_provider_share": 50,
    "pld_doctor_visits_per_year": 19.4,
    "general_doctor_visits_per_year": 1.09,
    "claims_based_annual_system_cost": 1000000000,
}


def compute_outputs(inputs):
    late_diagnosis_share_output = inputs["pld_late_diagnosis_share"]
    misdiagnosis_share_output = inputs["pld_misdiagnosis_share"]
    no_insurance_provider_share_output = inputs["pld_no_insurance_provider_share"]
    doctor_visit_utilization_gap = (
        inputs["pld_doctor_visits_per_year"] - inputs["general_doctor_visits_per_year"]
    )
    claims_based_annual_system_cost_output = inputs["claims_based_annual_system_cost"]

    return {
        "late_diagnosis_share_output": late_diagnosis_share_output,
        "misdiagnosis_share_output": misdiagnosis_share_output,
        "no_insurance_provider_share_output": no_insurance_provider_share_output,
        "doctor_visit_utilization_gap": doctor_visit_utilization_gap,
        "claims_based_annual_system_cost_output": claims_based_annual_system_cost_output,
    }


def compute_trajectory(outputs, periods=5):
    gap = outputs["doctor_visit_utilization_gap"]
    values = []
    prev = 0.0
    for _ in range(periods):
        prev = prev + gap
        values.append(prev)
    return values


def run(inputs=None):
    if inputs is None:
        inputs = dict(DEFAULTS)
    outputs = compute_outputs(inputs)
    trajectory = compute_trajectory(outputs, periods=5)
    return outputs, trajectory


if __name__ == "__main__":
    outputs, trajectory = run()

    print("Persistent Lyme Disease: Diagnostic Delay, Access Barriers, and Care Utilization")
    print("(MyLymeData 2025 Chartbook) - Reference Implementation")
    print()

    print("Inputs (defaults):")
    for k, v in DEFAULTS.items():
        print(f"  {k}: {v}")
    print()

    print("Outputs:")
    print(
        "  late_diagnosis_share_output (percent of PLD patients): "
        f"{outputs['late_diagnosis_share_output']}"
    )
    print(
        "  misdiagnosis_share_output (percent of PLD patients): "
        f"{outputs['misdiagnosis_share_output']}"
    )
    print(
        "  no_insurance_provider_share_output (percent of PLD patients): "
        f"{outputs['no_insurance_provider_share_output']}"
    )
    print(
        "  doctor_visit_utilization_gap (visits/year, PLD minus general population): "
        f"{outputs['doctor_visit_utilization_gap']}"
    )
    print(
        "  claims_based_annual_system_cost_output (USD, externally cited, Adrion et al. 2015): "
        f"{outputs['claims_based_annual_system_cost_output']}"
    )
    print()

    print(
        "Trajectory - cumulative_excess_doctor_visits "
        "(flat, assumes the reported annual gap repeats unchanged each year):"
    )
    for i, val in enumerate(trajectory, start=1):
        print(f"  year {i}: {val}")