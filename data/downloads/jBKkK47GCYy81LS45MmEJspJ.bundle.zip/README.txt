================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : jBKkK47GCYy81LS45MmEJspJ
    Generated   : 2026-10-06 17:06:00 UTC
================================================================

TITLE
-----
Persistent Lyme Disease: Diagnostic Delay, Access Barriers, and Care Utilization (MyLymeData 2025 Chartbook)

BOUNDARY
--------
This simulation reflects self-reported findings from the MyLymeData patient registry (19,000+ enrollees, 85% women) as summarized in LymeDisease.org's 2025 chartbook, focused on the subset of participants who report persistent Lyme disease (PLD). It covers diagnostic delay, misdiagnosis, insurance/clinician access barriers, and self-reported healthcare utilization, plus one externally cited insurance-claims-based system cost estimate. It does not include any MyLymeData-generated dollar cost figure, any nationally representative incidence/prevalence estimate, caregiving burden, or a lifetime cost projection - none of these are reported in the source document. The registry sample is self-selected and skews toward more severe, persistent illness, so percentages here describe this sample, not the general U.S. Lyme disease population.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 10th-anniversary chartbook from LymeDisease.org summarizing findings from MyLymeData, a patient-powered registry of over 19,000 U.S. Lyme disease patients. It reports high rates of diagnostic delay and misdiagnosis, heavy co-infection burden, worse quality of life and higher healthcare utilization among patients with persistent Lyme disease (PLD) compared to acute Lyme disease patients and the general population, and describes substantial barriers to care including insurance non-acceptance, travel distance, and clinician scarcity. It also reports work-schedule disruption (reduced hours or quitting work) among a large share of PLD patients and cites one external claims-based estimate that Lyme disease costs the U.S. healthcare system about $1 billion a year. Most figures come from self-reported registry survey data, with several key background statistics drawn from previously published external studies rather than measured directly by MyLymeData itself.

WHY THIS COULD BE USEFUL
------------------------
Patients and advocates could use a simulator built from this document to understand typical diagnostic-delay pathways, symptom burden, and the access-to-care and insurance barriers reported by a large real-world PLD patient population, helping frame conversations with clinicians or insurers about treatment history. Care delivery teams could use the reported healthcare-utilization multipliers (e.g., roughly 5x more doctor visits, roughly 2x more ER visits than the general population, self-reported) to anticipate the intensity of care PLD patients require when planning clinic capacity. Payers and policy audiences could use the reported insurance-access statistics (e.g., ~75% of PLD-treating clinicians outside insurance networks, ~50% of patients whose provider doesn't accept insurance, 27% unable to find a treating clinician) to evaluate network-adequacy and access gaps, while recognizing that this document supports none of these uses with an independently modeled total or per-patient direct-cost figure - only one externally cited, claims-based $1 billion/year system-cost estimate with no stated price year.

WHAT YOU COULD DO WITH IT
-------------------------
- Care-access barrier explorer: let users see how insurance non-acceptance (50% of providers), inability to find a treating clinician (27%), and travel distance (32% traveling 100+ miles) combine to delay or prevent PLD treatment, without implying these percentages generalize beyond the MyLymeData registry sample.
- Healthcare-utilization-intensity comparator: let care delivery planners compare self-reported PLD utilization rates (doctor visits, ER visits, hospital stays, home care visits) against the general-population baseline reported in this document, clearly labeled as self-reported registry data, not claims-derived.
- Cohort/subgroup design screening aid: given the document's extensive discussion of clinical-trial exclusion criteria (RCTs excluding 89-99% of real-world PLD patients) and treatment-response heterogeneity (High/Low/Non-Responders), a simulator could flag the value of screening trial cohorts for unmeasured confounders - such as home environmental exposure (mold, mildew, pet dander) - before attributing response variance to a studied treatment, since this document already shows unexplained subgroup variation in treatment response that averages can obscure.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 140 Lyme-related terms (for example, "Lyme", "Tick-Borne", "borreliosis") and 1 Long COVID-related term (for example, "long COVID"). The 1 term(s) about the other condition are 0.7% of all matched terms, so they are treated as incidental and the document is classified as Lyme disease.

SOURCE FILES
------------
MyLymeData 2025 Chartbook.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- PLD patients not diagnosed until ≥6 months (late/chronic stage) (percent of PLD patients), default 77, source: Value of 77 is from MyLymeData chartbook page 16 (restated on page 7); the 0-100 range is an assumed exploration bound covering the full percentage scale, not from the source.
- PLD patients initially misdiagnosed before Lyme diagnosis (percent of PLD patients), default 74, source: Value of 74 is from MyLymeData chartbook page 17; the 0-100 range is an assumed exploration bound, not from the source.
- PLD patients whose treating provider does not accept insurance (percent of PLD patients), default 50, source: Value of 50 is from MyLymeData chartbook page 15 (also page 24); the 0-100 range is an assumed exploration bound, not from the source.
- PLD patients: self-reported annual doctor visits (visits/year), default 19.4, source: Value of 19.4 is from MyLymeData chartbook page 23 (self-reported, MEPS-style survey item); the 5-40 range is an assumed exploration bound chosen so it cannot fall below the general-population comparator's range, preserving the document's reported ordering.
- General population: annual doctor visits (comparator) (visits/year), default 1.09, source: Value of 1.09 is from MyLymeData chartbook page 23, cited as a general-population comparator; the 0-3 range is an assumed exploration bound chosen so it cannot exceed the PLD input's range, preserving the document's reported ordering.
- Insurance-claims-based annual U.S. Lyme disease system cost (Adrion et al. 2015, cited) (USD), default 1000000000, source: Value of $1,000,000,000 is from MyLymeData chartbook page 23, quoting Adrion et al. 2015 (no price year stated in the chartbook); the 500,000,000-2,000,000,000 range is an assumed exploration bound reflecting uncertainty around this single cited estimate, not from the source.

OUTPUTS (5)
-----------
- Share of PLD patients diagnosed at ≥6 months (late/chronic stage): 77 (percent of PLD patients) at default assumptions
- Share of PLD patients initially misdiagnosed before Lyme diagnosis: 74 (percent of PLD patients) at default assumptions
- Share of PLD patients whose treating provider does not accept insurance: 50 (percent of PLD patients) at default assumptions
- PLD minus general-population annual doctor visits (positive = PLD patients report more visits per year than the general-population comparator): 18.31 (visits/year) at default assumptions
- Externally cited annual U.S. healthcare system cost attributable to Lyme disease (insurance claims, price year not stated): 1e+09 (USD) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 423 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2022_2023__cdc_9mtj-y2ba.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Johnson L. MyLymeData 2025 Research Chartbook (patient-registry report, LymeDisease.org). 2025
  Report (PDF, LymeDisease.org): https://www.lymedisease.org/assets/MLD-2025-chartbook.pdf
  MyLymeData research page: https://www.lymedisease.org/mylymedata-lyme-disease-research/

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.