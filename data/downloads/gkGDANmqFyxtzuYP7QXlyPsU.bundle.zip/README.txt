================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : gkGDANmqFyxtzuYP7QXlyPsU
    Generated   : 2026-10-07 02:16:33 UTC
================================================================

TITLE
-----
Lyme Disease Economic Burden Simulator (Maryland Eastern Shore, 1997-2000)

BOUNDARY
--------
This simulator models a 2006 CDC-authored peer-reviewed cost-of-illness study of Lyme disease among patients in five Maryland Eastern Shore counties, 1997-2000, covering per-patient direct medical, indirect medical (extra drug costs), nonmedical (paid help, travel), and productivity-loss costs by disease stage, plus the study's own extrapolation to a nationwide total using a 2002 national case count. It does not model costs beyond the 4-year study window, costs from other regions, intangible costs such as pain and suffering, public health administration costs, unpaid caregiver time (the study asked about this but did not quantify it), vaccine-related costs, or any demographic disaggregation beyond the single sex comparison the study reports.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 2006 CDC-authored peer-reviewed study that measured the economic burden of Lyme disease among patients in five Maryland Eastern Shore counties from 1997 to 2000, using medical-record charge data plus a patient-mailed cost questionnaire (reproduced as Appendix 1). It reports per-patient direct medical costs that were higher for late-stage than early-stage disease and declined over the study period, plus indirect medical costs (extra drug spending), nonmedical costs (paid help, travel), and productivity losses (lost work time) collected by survey. The authors then extrapolated their Maryland per-patient cost estimates to the 23,763 Lyme disease cases reported nationally to CDC in 2002, producing a rough nationwide economic-impact estimate that they themselves caution is likely understated. The study explicitly notes multiple limitations, including a small questionnaire response rate, use of a clinical rather than surveillance case definition, and exclusion of intangible and public-health administrative costs.

WHY THIS COULD BE USEFUL
------------------------
This document is a societal-perspective cost-of-illness study of Lyme disease among patients in five Maryland counties (1997-2000), combining medical-record direct medical cost data with patient-reported indirect, nonmedical, and productivity-loss costs, and extrapolating to a rough nationwide estimate. A simulator built on it could let patients/advocates see how historical US Lyme disease costs differed by disease stage, let care delivery teams compare direct-medical-cost components (visits, serology, therapy, hospitalization) by diagnosis stage and study year, and let payers/policy audiences explore how stage-of-diagnosis and case-definition choices affect per-patient and population-level cost estimates. Because the data are nearly two decades old, drawn from a single endemic region, and mix at least two different price years in the national extrapolation, any simulator should present these as historical reference points rather than current cost benchmarks.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients/advocates could explore how per-patient total costs differed between early-stage (median $397) and late-stage (median $923) Lyme disease in this 1997-2000 Maryland cohort, illustrating the potential value of earlier diagnosis, while being shown these are historical, single-region, year-2000-dollar figures rather than current national costs.
- Payers/policy users could examine the $2,970 direct-medical-cost-per-patient and $5,202 indirect/nonmedical/productivity-cost-per-patient figures alongside the document's own flagged price-year and case-definition mismatches in the ≈$203 million nationwide extrapolation, to understand the limits of scaling a single-region cost study to a national policy estimate.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 45 Lyme-related terms (for example, "Lyme", "Borrelia"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Zhang 2006 supplement.pdf
Zhang 2006.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Early-stage median total cost (USD), default 397, source: p.657, Results/Figure 3 and Abstract; 200-600 range is an assumed exploration bound around the reported $397 median, not from the source
- Late-stage median total cost (USD), default 923, source: p.657, Results/Figure 3 and Abstract; 700-1200 range is an assumed exploration bound around the reported $923 median, chosen so it cannot fall below the early-stage input's range, not from the source
- Per-patient direct medical cost (extrapolation input) (USD), default 2970, source: p.658, Discussion ($1,455,081 total direct medical cost / 490 clinically defined early- or late-stage cases); 2000-4000 range is an assumed exploration bound, not from the source
- Per-patient indirect, nonmedical, and productivity-loss cost (extrapolation input) (USD), default 5202, source: p.658, Discussion ($436,949 total indirect medical, nonmedical, and productivity-loss cost / 84 clinically defined early- or late-stage cases with questionnaire data); 3500-7000 range is an assumed exploration bound, not from the source
- National Lyme disease cases reported to CDC (cases), default 23763, source: p.654/p.658, citing CDC national surveillance count for 2002; 15000-35000 range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Late-stage minus early-stage median total cost (always positive here; higher = larger late-stage cost premium): 526 (USD) at default assumptions
- Late-stage to early-stage median cost ratio: 2.32 (ratio) at default assumptions
- Combined per-patient cost used in nationwide extrapolation: 8,172 (USD) at default assumptions
- Recomputed nationwide economic impact (combined per-patient cost x national case count): 194,191,236 (USD) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 553 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::1::ed2017.do, scope: both)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::310::SAGDP6_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Zhang X et al. Economic impact of Lyme disease. Emerg Infect Dis. 2006
  PubMed: https://pubmed.ncbi.nlm.nih.gov/16704815/
  DOI: https://doi.org/10.3201/eid1204.050602

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.