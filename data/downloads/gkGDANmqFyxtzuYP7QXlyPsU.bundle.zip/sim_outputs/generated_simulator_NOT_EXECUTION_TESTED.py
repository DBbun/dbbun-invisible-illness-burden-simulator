DEFAULT_INPUTS = {
    "early_stage_median_cost": 397,
    "late_stage_median_cost": 923,
    "per_patient_direct_medical_cost": 2970,
    "per_patient_other_costs": 5202,
    "national_case_count": 23763,
}

SCENARIOS = {
    "late_stage_heavy_case_mix": {
        "per_patient_direct_medical_cost": 4000,
        "per_patient_other_costs": 7000,
    },
    "early_stage_heavy_case_mix": {
        "per_patient_direct_medical_cost": 2000,
        "per_patient_other_costs": 3500,
    },
    "higher_national_case_count": {
        "national_case_count": 35000,
    },
    "worse_case_combined_underestimate": {
        "per_patient_direct_medical_cost": 4000,
        "per_patient_other_costs": 7000,
        "national_case_count": 35000,
    },
}


def compute_outputs(inputs):
    """Compute all outputs from a given inputs dict, using exactly the
    arithmetic defined in the spec's output expressions."""
    early_stage_median_cost = inputs["early_stage_median_cost"]
    late_stage_median_cost = inputs["late_stage_median_cost"]
    per_patient_direct_medical_cost = inputs["per_patient_direct_medical_cost"]
    per_patient_other_costs = inputs["per_patient_other_costs"]
    national_case_count = inputs["national_case_count"]

    late_minus_early_median_cost = late_stage_median_cost - early_stage_median_cost

    late_early_cost_ratio = late_stage_median_cost / early_stage_median_cost

    per_patient_combined_cost_for_extrapolation = (
        per_patient_direct_medical_cost + per_patient_other_costs
    )

    national_extrapolated_economic_impact = (
        per_patient_combined_cost_for_extrapolation * national_case_count
    )

    return {
        "late_minus_early_median_cost": late_minus_early_median_cost,
        "late_early_cost_ratio": late_early_cost_ratio,
        "per_patient_combined_cost_for_extrapolation": per_patient_combined_cost_for_extrapolation,
        "national_extrapolated_economic_impact": national_extrapolated_economic_impact,
    }


def print_outputs(label, inputs, outputs):
    print(f"--- {label} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    print(
        "  late_minus_early_median_cost (USD): "
        f"{outputs['late_minus_early_median_cost']}"
    )
    print(
        "  late_early_cost_ratio: "
        f"{outputs['late_early_cost_ratio']:.4f}"
    )
    print(
        "  per_patient_combined_cost_for_extrapolation (USD): "
        f"{outputs['per_patient_combined_cost_for_extrapolation']}"
    )
    print(
        "  national_extrapolated_economic_impact (USD): "
        f"{outputs['national_extrapolated_economic_impact']:.2f}"
    )
    print()


if __name__ == "__main__":
    # Default inputs
    default_inputs = dict(DEFAULT_INPUTS)
    default_outputs = compute_outputs(default_inputs)
    print_outputs("Default inputs", default_inputs, default_outputs)

    # Scenarios (apply overrides on top of defaults)
    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = dict(DEFAULT_INPUTS)
        scenario_inputs.update(overrides)
        scenario_outputs = compute_outputs(scenario_inputs)
        print_outputs(f"Scenario: {scenario_id}", scenario_inputs, scenario_outputs)