#!/usr/bin/env python3
"""
Long COVID Diagnosis Code (U09.9) Uptake, Representation, and Care-Pattern Simulator

Reference implementation of the interactive spec. Standard library only.

Boundary: This simulation reflects only diagnostic-coding patterns,
demographic/area-level (ZIP-code) composition, and short-term (60-day)
care-utilization percentages reported in one EHR-based study (N3C database,
34 US health systems, October 2021-May 2022, n=33,782 patients coded U09.9).
It contains no direct medical cost, out-of-pocket cost, lost income, or
caregiving-burden data and cannot support any financial burden estimate.
Findings are not nationally representative, demographic/SDoH variables are
ZIP-code-level proxies rather than individual-level measures, and the study
does not establish a chart-reviewed 'true' long COVID case count.
"""

# ---- Default inputs (directly reported in the source study unless noted) ----

DEFAULT_INPUTS = {
    "u09_female_pct": 66.9,
    "comparator_female_pct": 55.6,
    "u09_white_pct": 71.8,
    "comparator_white_pct": 61.1,
    "u09_no_index_test_pct": 37.2,
    "u09_hospitalization_pct": 9.7,
    "u09_imaging_pct": 22.8,
}


def compute_outputs(inputs):
    """Compute all defined outputs from the given inputs dict."""
    female_representation_gap = (
        inputs["u09_female_pct"] - inputs["comparator_female_pct"]
    )
    white_representation_gap = (
        inputs["u09_white_pct"] - inputs["comparator_white_pct"]
    )
    no_recorded_test_rate = inputs["u09_no_index_test_pct"] * 1
    hospitalization_during_acute_infection_rate = (
        inputs["u09_hospitalization_pct"] * 1
    )
    imaging_utilization_rate = inputs["u09_imaging_pct"] * 1

    return {
        "female_representation_gap": female_representation_gap,
        "white_representation_gap": white_representation_gap,
        "no_recorded_test_rate": no_recorded_test_rate,
        "hospitalization_during_acute_infection_rate": (
            hospitalization_during_acute_infection_rate
        ),
        "imaging_utilization_rate": imaging_utilization_rate,
    }


OUTPUT_LABELS = {
    "female_representation_gap": (
        "Female representation gap (percentage points)"
    ),
    "white_representation_gap": (
        "White representation gap (percentage points)"
    ),
    "no_recorded_test_rate": (
        "No recorded acute COVID-19 test (%)"
    ),
    "hospitalization_during_acute_infection_rate": (
        "Hospitalized during acute infection (%)"
    ),
    "imaging_utilization_rate": (
        "Imaging within 60 days of diagnosis (%)"
    ),
}


def run(inputs=None):
    """Run the simulator with given inputs (falling back to defaults)."""
    merged = dict(DEFAULT_INPUTS)
    if inputs:
        merged.update(inputs)
    return merged, compute_outputs(merged)


if __name__ == "__main__":
    used_inputs, results = run()

    print("=== Long COVID U09.9 Simulator: Default Run ===\n")

    print("Inputs:")
    for key, value in used_inputs.items():
        print(f"  {key}: {value}")

    print("\nOutputs:")
    for key, value in results.items():
        label = OUTPUT_LABELS.get(key, key)
        print(f"  {label}: {value:.1f}")

    print(
        "\nNote: This is a reference arithmetic implementation of a single "
        "EHR-based study's reported coding patterns and care-pattern "
        "percentages. It is not a cost model, not nationally representative, "
        "and does not establish a chart-reviewed true long COVID case count."
    )