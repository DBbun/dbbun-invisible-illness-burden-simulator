================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : m0OASZ_a41Kjxki2eVmUOCwl
    Generated   : 2026-10-10 21:10:39 UTC
================================================================

TITLE
-----
Long COVID Diagnosis Code (U09.9) Uptake, Representation, and Care-Pattern Simulator

BOUNDARY
--------
This simulation reflects only diagnostic-coding patterns, demographic/area-level (ZIP-code) composition, and short-term (60-day) care-utilization percentages reported in one EHR-based study (N3C database, 34 US health systems, October 2021-May 2022, n=33,782 patients coded U09.9). It contains no direct medical cost, out-of-pocket cost, lost income, or caregiving-burden data and cannot support any financial burden estimate. Findings are not nationally representative, demographic/SDoH variables are ZIP-code-level proxies rather than individual-level measures, and the study does not establish a chart-reviewed 'true' long COVID case count.

ABOUT THE SOURCE DOCUMENT
-------------------------
This study used a large national EHR database (N3C, 16+ million patients, 34 health systems) to examine how the new ICD-10-CM code for long COVID (U09.9, available starting October 2021) was actually used in US clinical practice between October 2021 and May 2022, in a cohort of 33,782 coded patients. It reports which other diagnoses, procedures, and medications cluster with a U09.9 diagnosis, and shows that patients who received the U09.9 code were demographically skewed toward female, White, non-Hispanic individuals and toward lower-poverty, lower-unemployment areas compared to all SARS-CoV-2-positive patients at the same sites. The authors argue this skew likely reflects disparities in who gets diagnosed and coded, not the true distribution of long COVID, and note that the code's nearly two-year delayed release left many earlier patients uncounted. The paper reports no direct medical costs, non-medical costs, lost income, or caregiving burden figures; its burden evidence is limited to diagnostic/coding patterns, care-utilization percentages, and demographic/SDoH disparities in who receives a diagnosis.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would mainly serve patients/advocates and policy/payer audiences interested in why claims- or EHR-code-based long COVID counts and demographic patterns may not reflect the true patient population, and care-delivery teams interested in what diagnostic/treatment utilization patterns (imaging, ECG, rehab, medications) currently accompany a long COVID diagnosis. It cannot inform direct cost, insurance-barrier, or financial-burden questions because the document reports no dollar figures, out-of-pocket costs, lost income, or caregiving-time data. Its real value is in flagging who is and isn't getting diagnosed, and what care patterns follow diagnosis, within an EHR-coded US cohort from late 2021-mid 2022.

WHAT YOU COULD DO WITH IT
-------------------------
- Policy or payer audiences evaluating claims/EHR-code-based long COVID prevalence or cost estimates could use this document's demographic/SDoH skew findings to flag that such estimates likely undercount patients in socially deprived, higher-unemployment, or lower-insurance-access areas, rather than treating code-based counts as a true population figure.
- Clinical/care-delivery teams designing long COVID care pathways could use the age-stratified comorbidity clusters and procedure/medication utilization rates (e.g., 22.8% imaging, ECG/echo rates, rehabilitation service use) to anticipate common diagnostic and treatment patterns in the 60 days following a U09.9 diagnosis.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 187 Long COVID-related terms (for example, "long COVID", "post-acute sequelae", "PASC"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Pfaff 2023 coding.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- Percent female in U09.9-coded cohort (%), default 66.9, source: Results, p.5 (directly reported); 50-80 range is an assumed exploration bound, not from the source
- Percent female among all SARS-CoV-2-positive patients (same sites) (%), default 55.6, source: Results, p.5 (directly reported); 40-70 range is an assumed exploration bound, not from the source
- Percent White in U09.9-coded cohort (%), default 71.8, source: Results, p.5 (directly reported); 55-85 range is an assumed exploration bound, not from the source
- Percent White among all SARS-CoV-2-positive patients (same sites) (%), default 61.1, source: Results, p.5 (directly reported); 45-75 range is an assumed exploration bound, not from the source
- Percent of U09.9 cohort with no recorded acute COVID-19 test (%), default 37.2, source: Results, p.4-5 (directly reported); 20-50 range is an assumed exploration bound, not from the source
- Percent of U09.9 cohort hospitalized during acute infection (%), default 9.7, source: Results, p.4 (directly reported); 0-20 range is an assumed exploration bound, not from the source
- Percent of U09.9 cohort with imaging within 60 days of diagnosis (%), default 22.8, source: Discussion, p.8 (directly reported, averaged across age groups); 0-50 range is an assumed exploration bound, not from the source

OUTPUTS (5)
-----------
- U09.9 cohort percent female minus comparator percent female (positive = more female representation among coded patients; negative = less): 11.3 (percentage points) at default assumptions
- U09.9 cohort percent White minus comparator percent White (positive = more White representation among coded patients; negative = less): 10.7 (percentage points) at default assumptions
- Percent of U09.9 cohort with no recorded acute COVID-19 test: 37.2 (%) at default assumptions
- Percent of U09.9 cohort hospitalized during acute COVID-19 infection: 9.7 (%) at default assumptions
- Percent of U09.9 cohort with imaging within 60 days of diagnosis: 22.8 (%) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::1::ed2017.do, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::4::Code Descriptions/icd10cm_order_2026.txt, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::3::Code Descriptions/icd10cm_codes_2026.txt, scope: both)

ORIGINAL SOURCE
---------------
Pfaff ER et al. Coding long COVID: characterizing a new disease through an ICD-10 lens. BMC Med. 2023;21:58
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36793086/
  DOI: https://doi.org/10.1186/s12916-023-02737-6

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.