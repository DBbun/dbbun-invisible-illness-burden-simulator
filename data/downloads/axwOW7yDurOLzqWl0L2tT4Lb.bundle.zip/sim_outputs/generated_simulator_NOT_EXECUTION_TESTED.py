#!/usr/bin/env python3
"""
Reference implementation of the MyLymeData sex-differences simulator spec.

Models self-reported percentage-point differences between women and men
in a single self-selected patient registry (MyLymeData, n=2170, dataset
dated April 27, 2017) regarding diagnostic delay, clinician-seeking
before diagnosis, misdiagnosis with chronic fatigue syndrome/
fibromyalgia/psychiatric conditions, and self-identified disability.

These are associational, self-reported findings from one registry and
are not generalizable. No cost or national burden data are modeled.
"""

# ---- Default inputs (all percentages, 0-100) ----

DEFAULT_INPUTS = {
    "women_diagnostic_delay_3yr_pct": 57,
    "men_diagnostic_delay_3yr_pct": 49,
    "women_clinicians_10plus_pct": 36,
    "men_clinicians_10plus_pct": 25,
    "women_misdiagnosis_cfs_fms_psych_pct": 78,
    "men_misdiagnosis_cfs_fms_psych_pct": 63,
    "women_disabled_main_work_status_pct": 36,
    "men_disabled_main_work_status_pct": 30,
}


def compute_outputs(inputs):
    """Compute the four sex-gap outputs (women minus men, percentage points)."""

    diagnostic_delay_gap_pct_points = (
        inputs["women_diagnostic_delay_3yr_pct"]
        - inputs["men_diagnostic_delay_3yr_pct"]
    )

    clinicians_seen_gap_pct_points = (
        inputs["women_clinicians_10plus_pct"]
        - inputs["men_clinicians_10plus_pct"]
    )

    misdiagnosis_cfs_fms_psych_gap_pct_points = (
        inputs["women_misdiagnosis_cfs_fms_psych_pct"]
        - inputs["men_misdiagnosis_cfs_fms_psych_pct"]
    )

    disabled_main_work_status_gap_pct_points = (
        inputs["women_disabled_main_work_status_pct"]
        - inputs["men_disabled_main_work_status_pct"]
    )

    return {
        "diagnostic_delay_gap_pct_points": diagnostic_delay_gap_pct_points,
        "clinicians_seen_gap_pct_points": clinicians_seen_gap_pct_points,
        "misdiagnosis_cfs_fms_psych_gap_pct_points": misdiagnosis_cfs_fms_psych_gap_pct_points,
        "disabled_main_work_status_gap_pct_points": disabled_main_work_status_gap_pct_points,
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("Inputs (defaults, MyLymeData registry, dataset dated 2017-04-27):")
    for key, value in inputs.items():
        print(f"  {key}: {value}%")

    print()
    print("Outputs (percentage-point gaps, women minus men):")
    print(
        "  diagnostic_delay_gap_pct_points "
        f"(3+ year diagnostic delay): {outputs['diagnostic_delay_gap_pct_points']} pp"
    )
    print(
        "  clinicians_seen_gap_pct_points "
        f"(saw 10+ clinicians before diagnosis): {outputs['clinicians_seen_gap_pct_points']} pp"
    )
    print(
        "  misdiagnosis_cfs_fms_psych_gap_pct_points "
        f"(prior CFS/fibromyalgia/psychiatric misdiagnosis): "
        f"{outputs['misdiagnosis_cfs_fms_psych_gap_pct_points']} pp"
    )
    print(
        "  disabled_main_work_status_gap_pct_points "
        f"(disabled as main work status): "
        f"{outputs['disabled_main_work_status_gap_pct_points']} pp"
    )

    print()
    print(
        "Note: these are self-reported, associational percentage-point gaps "
        "from a single self-selected patient registry (n=2170). They are not "
        "generalizable beyond this sample and do not represent costs, "
        "treatment effectiveness, or national prevalence."
    )