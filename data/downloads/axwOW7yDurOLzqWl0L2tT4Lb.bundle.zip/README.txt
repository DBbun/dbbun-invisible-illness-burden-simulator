================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : axwOW7yDurOLzqWl0L2tT4Lb
    Generated   : 2026-10-05 21:16:00 UTC
================================================================

TITLE
-----
Sex Differences in Diagnostic Delay, Misdiagnosis, and Disability in Persistent Lyme Disease (MyLymeData)

BOUNDARY
--------
This simulator models self-reported percentage-point differences between women and men in a single self-selected patient registry (MyLymeData, n=2170, dataset dated April 27, 2017) of US patients still ill six or more months after antibiotic treatment for Lyme disease. It covers only rates of diagnostic delay, clinician-seeking before diagnosis, misdiagnosis with chronic fatigue syndrome/fibromyalgia/psychiatric conditions, and self-identified disability. It does not model or include any dollar costs, caregiving hours, treatment effectiveness (which showed no significant sex difference in this document), or national prevalence - the document itself reports no cost data. Findings are associational, self-reported, and not generalizable beyond this registry sample.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed study using the MyLymeData patient registry (2170 US patients who remained ill six or more months after antibiotic treatment for Lyme disease) to compare men's and women's experiences of diagnosis, symptoms, functional impairment, and antibiotic treatment response. It also reviews other Lyme disease studies to see how the proportion of women enrolled varies by disease stage (acute vs. persistent) and by how restrictive the study's enrollment criteria are. The study finds women in this self-reported sample had more coinfections, longer diagnostic delays, more misdiagnosis (including with chronic fatigue syndrome, fibromyalgia, or psychiatric illness), worse symptom severity, and worse functional impairment than men, with no significant sex difference in antibiotic treatment effectiveness or side effects. The document does not report any dollar-denominated costs of Lyme disease care; its burden findings are entirely in terms of rates, delays, and self-reported functional limitations.

WHY THIS COULD BE USEFUL
------------------------
This document could inform patients/advocates by validating that women in persistent Lyme disease populations report longer diagnostic delays, more misdiagnosis, and worse functional impairment than men, supporting arguments for earlier, sex-aware clinical evaluation. Care delivery teams could use the sex-stratified misdiagnosis patterns (especially misattribution to CFS, fibromyalgia, or psychiatric illness) to inform differential-diagnosis checklists for patients with ambiguous multisystem symptoms. Research funders and policy audiences could use the documented pattern of restrictive RCT/PTLD enrollment criteria (excluding 89-99% of prospective patients) and the near-absence of sex-disaggregated research design to justify requiring sex-based reporting and broader eligibility criteria in future Lyme disease trials. No cost or financial-burden simulator can be built from this document alone since it reports no dollar figures.

WHAT YOU COULD DO WITH IT
-------------------------
- Clinicians or care-coordination teams could use the sex-stratified diagnostic-delay and misdiagnosis rates (e.g., women's higher rates of CFS/fibromyalgia/psychiatric misdiagnosis) to flag patients who may need earlier or repeated Lyme disease evaluation before those alternative diagnoses are settled on.
- Research funders or IRB/study-design reviewers could use the finding that restrictive RCT/PTLD entry criteria excluded 89-99% of prospective enrollees, and that few studies considered sex as a variable, to require broader eligibility criteria and mandatory sex-disaggregated reporting in future NIH-funded Lyme disease trials.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 111 Lyme-related terms (for example, "Lyme", "tick-borne", "Borrelia") and 3 Long COVID-related terms (for example, "long COVID"). The 3 term(s) about the other condition are 2.6% of all matched terms, so they are treated as incidental and the document is classified as Lyme disease.

SOURCE FILES
------------
Johnson 2023.pdf

PARAMETERS (8)
--------------
- Women: share with 3+ year diagnostic delay (%) (%), default 57, source: Table 3, p.6 of the uploaded document (IJGM 2023;16:2561); 0-100 range is an assumed exploration bound, not from the source
- Men: share with 3+ year diagnostic delay (%) (%), default 49, source: Table 3, p.6 of the uploaded document (IJGM 2023;16:2561); 0-100 range is an assumed exploration bound, not from the source
- Women: saw 10+ clinicians before diagnosis (%) (%), default 36, source: Table 3, p.6 of the uploaded document (IJGM 2023;16:2561); 0-100 range is an assumed exploration bound, not from the source
- Men: saw 10+ clinicians before diagnosis (%) (%), default 25, source: Table 3, p.6 of the uploaded document (IJGM 2023;16:2561); 0-100 range is an assumed exploration bound, not from the source
- Women: prior misdiagnosis with CFS, fibromyalgia, or psychiatric condition (%) (%), default 78, source: Table 4, p.6 of the uploaded document (IJGM 2023;16:2562); 0-100 range is an assumed exploration bound, not from the source
- Men: prior misdiagnosis with CFS, fibromyalgia, or psychiatric condition (%) (%), default 63, source: Table 4, p.6 of the uploaded document (IJGM 2023;16:2562); 0-100 range is an assumed exploration bound, not from the source
- Women: disabled as main work status due to Lyme disease (%) (%), default 36, source: Table 5, p.7 of the uploaded document (IJGM 2023;16:2563); 0-100 range is an assumed exploration bound, not from the source
- Men: disabled as main work status due to Lyme disease (%) (%), default 30, source: Table 5, p.7 of the uploaded document (IJGM 2023;16:2563); 0-100 range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Diagnostic delay (3+ years): women minus men, percentage points (positive = higher share of women delayed; negative = higher share of men delayed): 8 (percentage points) at default assumptions
- Saw 10+ clinicians before diagnosis: women minus men, percentage points (positive = higher share of women; negative = higher share of men): 11 (percentage points) at default assumptions
- Misdiagnosis with CFS/fibromyalgia/psychiatric condition: women minus men, percentage points (positive = higher share of women misdiagnosed this way; negative = higher share of men): 15 (percentage points) at default assumptions
- Disabled as main work status due to Lyme disease: women minus men, percentage points (positive = higher share of women; negative = higher share of men): 6 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2022_2023__cdc_9mtj-y2ba.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::1::ed2017.do, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::566::SAGDP11_WA_1998_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson L et al. Does Biological Sex Matter in Lyme Disease? The Need for Sex-Disaggregated Data in Persistent Illness. Int J Gen Med. 2023
  PubMed: https://pubmed.ncbi.nlm.nih.gov/37351009/
  DOI: https://doi.org/10.2147/IJGM.S406466

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.