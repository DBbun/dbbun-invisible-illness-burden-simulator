DEFAULTS = {
    "wait_time_over_1_month": 63,
    "out_of_state_patient_share": 38,
    "inadequate_education_reason": 86,
    "false_negative_lab_reason": 61,
    "insurance_network_nonparticipation": 74,
    "prior_authorization_burden": 77,
    "regulatory_investigation_rate": 39,
    "anecdotal_annual_oop_cost": 15000,
}

SCENARIOS = [
    {
        "id": "medicare_medicaid_nonparticipation_view",
        "label": "Medicare/Medicaid non-participation",
        "overrides": {"insurance_network_nonparticipation": 77},
    },
    {
        "id": "direct_billing_nonparticipation_view",
        "label": "Direct insurer billing non-participation",
        "overrides": {"insurance_network_nonparticipation": 76},
    },
    {
        "id": "medical_board_inquiry_only",
        "label": "Medical-board inquiry only",
        "overrides": {"regulatory_investigation_rate": 19},
    },
    {
        "id": "extended_wait_over_4_months",
        "label": "Extended wait (>4 months)",
        "overrides": {"wait_time_over_1_month": 8},
    },
    {
        "id": "low_end_oop_estimate",
        "label": "Low-end anecdotal OOP cost",
        "overrides": {"anecdotal_annual_oop_cost": 10000},
    },
    {
        "id": "high_end_oop_estimate",
        "label": "High-end anecdotal OOP cost",
        "overrides": {"anecdotal_annual_oop_cost": 20000},
    },
]


def compute_outputs(inputs):
    outputs = {}
    outputs["diagnostic_delay_reason_gap"] = (
        inputs["inadequate_education_reason"] - inputs["false_negative_lab_reason"]
    )
    outputs["wait_time_access_barrier"] = inputs["wait_time_over_1_month"]
    outputs["insurance_network_nonparticipation_output"] = inputs[
        "insurance_network_nonparticipation"
    ]
    outputs["regulatory_investigation_output"] = inputs["regulatory_investigation_rate"]
    outputs["anecdotal_annual_oop_cost_output"] = inputs["anecdotal_annual_oop_cost"]
    return outputs


def compute_trajectory(annual_value, periods):
    values = []
    prev = 0
    for _ in range(periods):
        prev = prev + annual_value
        values.append(prev)
    return values


def run_scenario(overrides):
    inputs = dict(DEFAULTS)
    inputs.update(overrides)
    return compute_outputs(inputs)


if __name__ == "__main__":
    print("=== Default inputs ===")
    for k, v in DEFAULTS.items():
        print(f"{k}: {v}")

    print("\n=== Default outputs ===")
    default_outputs = compute_outputs(DEFAULTS)
    for k, v in default_outputs.items():
        print(f"{k}: {v}")

    print("\n=== Trajectory: cumulative_oop_cost_per_patient (5 years) ===")
    traj = compute_trajectory(default_outputs["anecdotal_annual_oop_cost_output"], 5)
    for year, val in enumerate(traj, start=1):
        print(f"year {year}: {val}")

    print("\n=== Scenarios ===")
    for scenario in SCENARIOS:
        print(f"\n-- {scenario['label']} ({scenario['id']}) --")
        scenario_outputs = run_scenario(scenario["overrides"])
        for k, v in scenario_outputs.items():
            print(f"{k}: {v}")