================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : yisFG8DLi5aic4MQ8nrOaX8_
    Generated   : 2026-10-06 17:06:03 UTC
================================================================

TITLE
-----
Clinician-Reported Access Barriers in Persistent/Chronic Lyme Disease Care (2021 Survey)

BOUNDARY
--------
This simulator reflects a 2022 peer-reviewed survey of 155 self-selected U.S. clinicians who treat persistent/chronic Lyme disease (PLD/CLD), covering clinician-reported wait times, reasons for diagnostic delay, insurance-network participation, and professional/regulatory risk. It does not model total medical spending, indirect costs, or patient-level demographics; the single dollar figure available is one clinician's anecdotal estimate, not a survey-wide statistic. All percentages are clinician perceptions from a non-random sample, not direct patient-level measurements.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 2022 peer-reviewed survey study (Johnson & Maloney) of 155 U.S. clinicians who treat persistent or chronic Lyme disease (PLD/CLD), conducted by the patient advocacy organization LymeDisease.org between September and December 2021. It reports clinician-perceived reasons for diagnostic delay, wait times and travel patterns for patients, visit-length and billing burdens, insurance-network non-participation, professional stigma, and regulatory/medical-board investigations faced by treating clinicians. The paper also cites prior patient-survey findings (diagnostic delay, misdiagnosis, travel distance) and case-count estimates from other publications as background. It does not report a systematic accounting of total medical costs, indirect costs, or patient-level demographic breakdowns; one dollar figure ($10,000-$20,000/year out-of-pocket) comes from a single respondent's open-text comment rather than a survey-wide statistic.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would primarily inform access-to-care and workforce-supply questions for PLD/CLD rather than aggregate cost modeling, since the paper reports almost no direct-cost or indirect-cost dollar figures of its own. Patients/advocates could use the reported wait-time, travel-distance, and diagnostic-delay-reason statistics to set realistic expectations for care-seeking. Care delivery organizations could use the visit-duration, insurance-denial, and stigma/regulatory-investigation findings to understand why clinicians exit or avoid this practice area. Payers and policymakers could use the insurance-network non-participation and prior-authorization findings to evaluate reimbursement-model reform aimed at the access/supply bottleneck the authors describe.

WHAT YOU COULD DO WITH IT
-------------------------
- Model expected wait times and travel burden for patients seeking a PLD/CLD-treating clinician, using the clinician-reported wait-time distribution and out-of-state patient share as inputs, clearly labeled as clinician-perceived (not patient-measured) estimates.
- Illustrate for policymakers how insurance-network non-participation (74-77% across measures) and regulatory/medical-board investigation exposure (39%) may constrain the supply of PLD/CLD-treating clinicians, as a structural access-barrier scenario rather than a direct cost estimate.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 69 Lyme-related terms (for example, "Lyme", "Tick-Borne", "Borrelia"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2022.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Clinicians reporting patients wait >1 month for initial consult (%), default 63, source: Results 3.2 / Figure 2, p.4 of the document; 0-100 range is an assumed exploration bound, not from the source
- Clinicians with ≥25% out-of-state patients (%), default 38, source: Results 3.2, p.4 of the document; 0-100 range is an assumed exploration bound, not from the source
- Clinicians citing inadequate physician education as a delay reason (%), default 86, source: Results 3.2, p.4 of the document; 0-100 range is an assumed exploration bound, not from the source
- Clinicians citing false-negative lab tests as a delay reason (%), default 61, source: Results 3.2, p.4 of the document; 0-100 range is an assumed exploration bound, not from the source
- Clinicians not participating in insurance networks (%), default 74, source: Results 3.3 / Figure 3, p.5 of the document; 0-100 range is an assumed exploration bound, not from the source
- Clinicians citing prior-authorization burden (%), default 77, source: Results 3.3, p.5 of the document; 0-100 range is an assumed exploration bound, not from the source
- Clinicians reporting a medical-board, insurer, or QI investigation (%), default 39, source: Results 3.3, p.5-6 of the document; 0-100 range is an assumed exploration bound, not from the source
- Anecdotal annual out-of-pocket cost for off-network care (one clinician's estimate) (USD), default 15000, source: Results 3.3, open-text comment, p.5 of the document; the 10000-20000 range itself is the document's own stated range, not an assumed bound

OUTPUTS (5)
-----------
- Inadequate-education reason minus false-negative-lab reason (percentage points; positive = education cited more often, negative = lab false-negatives cited more often): 25 (percentage points) at default assumptions
- Clinicians reporting patients wait >1 month for initial consult: 63 (%) at default assumptions
- Clinicians not participating in insurance networks: 74 (%) at default assumptions
- Clinicians reporting a medical-board, insurer, or QI investigation: 39 (%) at default assumptions
- Anecdotal annual out-of-pocket cost for off-network care: 15000 (USD) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::3::readme2017-ed-stata.txt, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson LB et al. Access to Care in Lyme Disease: Clinician Barriers to Providing Care. Healthcare (Basel). 2022
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36292329/
  DOI: https://doi.org/10.3390/healthcare10101882

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.