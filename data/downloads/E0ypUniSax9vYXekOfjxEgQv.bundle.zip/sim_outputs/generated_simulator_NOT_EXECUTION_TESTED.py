#!/usr/bin/env python3
"""
Reference implementation (standard library only) of the arithmetic spec:
"Lyme Disease Retreatment Trials: Adverse Events and Efficacy Signals (2012 Review)"

This script performs only the arithmetic described in the spec's "outputs"
section, using the spec's default "inputs". It does not add patients,
costs, sampling, or any statistical modeling beyond the simple ratios
defined in the spec.
"""

# ---------------------------------------------------------------------------
# Default inputs (from spec["inputs"])
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "krupp_enrolled_total": 55,
    "krupp_significant_aes": 6,
    "krupp_serious_aes": 4,
    "fallon_enrolled_total": 37,
    "fallon_total_aes": 7,
    "fallon_ceftriaxone_arm_aes": 6,
}


def compute_outputs(inputs):
    """Compute the four spec outputs from a dict of inputs.

    Each expression mirrors the spec's expression tree exactly:
    (numerator / denominator) * 100
    """
    krupp_enrolled_total = inputs["krupp_enrolled_total"]
    krupp_significant_aes = inputs["krupp_significant_aes"]
    krupp_serious_aes = inputs["krupp_serious_aes"]
    fallon_enrolled_total = inputs["fallon_enrolled_total"]
    fallon_total_aes = inputs["fallon_total_aes"]
    fallon_ceftriaxone_arm_aes = inputs["fallon_ceftriaxone_arm_aes"]

    krupp_ae_rate = (krupp_significant_aes / krupp_enrolled_total) * 100

    krupp_serious_ae_share = (krupp_serious_aes / krupp_significant_aes) * 100

    fallon_ae_rate = (fallon_total_aes / fallon_enrolled_total) * 100

    fallon_ceftriaxone_ae_share = (
        fallon_ceftriaxone_arm_aes / fallon_total_aes
    ) * 100

    return {
        "krupp_ae_rate": krupp_ae_rate,
        "krupp_serious_ae_share": krupp_serious_ae_share,
        "fallon_ae_rate": fallon_ae_rate,
        "fallon_ceftriaxone_ae_share": fallon_ceftriaxone_ae_share,
    }


# ---------------------------------------------------------------------------
# Optional illustrative scenarios defined in the spec (overrides only)
# ---------------------------------------------------------------------------

SCENARIOS = {
    "fallon_events_in_placebo_arm": {"fallon_ceftriaxone_arm_aes": 1},
    "krupp_no_serious_aes": {"krupp_serious_aes": 0},
}


def apply_overrides(base_inputs, overrides):
    merged = dict(base_inputs)
    merged.update(overrides)
    return merged


if __name__ == "__main__":
    print("=== Default inputs ===")
    for key, value in DEFAULT_INPUTS.items():
        print(f"{key}: {value}")

    print("\n=== Default outputs ===")
    default_outputs = compute_outputs(DEFAULT_INPUTS)
    print(
        "krupp_ae_rate (%% of enrolled patients, both arms): "
        f"{default_outputs['krupp_ae_rate']:.4f}"
    )
    print(
        "krupp_serious_ae_share (%% of significant AEs that were serious): "
        f"{default_outputs['krupp_serious_ae_share']:.4f}"
    )
    print(
        "fallon_ae_rate (%% of enrolled patients, both arms): "
        f"{default_outputs['fallon_ae_rate']:.4f}"
    )
    print(
        "fallon_ceftriaxone_ae_share (%% of Fallon AEs in ceftriaxone arm): "
        f"{default_outputs['fallon_ceftriaxone_ae_share']:.4f}"
    )

    print("\n=== Illustrative scenarios (overrides applied to defaults) ===")
    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = apply_overrides(DEFAULT_INPUTS, overrides)
        scenario_outputs = compute_outputs(scenario_inputs)
        print(f"\nScenario: {scenario_id}")
        print(f"  overrides: {overrides}")
        for out_key, out_val in scenario_outputs.items():
            print(f"  {out_key}: {out_val:.4f}")