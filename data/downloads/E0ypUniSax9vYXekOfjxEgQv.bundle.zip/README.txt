================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : E0ypUniSax9vYXekOfjxEgQv
    Generated   : 2026-10-05 20:15:21 UTC
================================================================

TITLE
-----
Lyme Disease Retreatment Trials: Adverse Events and Efficacy Signals (2012 Review)

BOUNDARY
--------
This simulation reflects only the trial-level enrollment counts and adverse-event figures reported in a 2012 biostatistical review of two of the four NIH-funded Lyme disease retreatment RCTs it covers (Krupp et al. STOP-LD and Fallon et al.). It does not include any dollar costs, productivity loss, diagnostic-delay burden, or population prevalence figures, because the source document reports none of these. The four trials enrolled structurally different populations and used different follow-up windows, so their results are kept separate here and must not be pooled into one figure.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 2012 biostatistical re-analysis of the four NIH-funded randomized controlled trials (Klempner x2, Krupp/STOP-LD, Fallon) that underlie most guideline recommendations against antibiotic retreatment for patients with persistent symptoms after standard Lyme disease treatment. The authors argue the trials were often underpowered or used excessive design treatment effects, so their 'no significant benefit' conclusions do not prove retreatment is ineffective; they find that Krupp showed a statistically significant fatigue benefit and Fallon found a cognitive-function result at the margin of significance that was not sustained. The review also reports the adverse-event counts from these trials, including serious events such as sepsis and anaphylaxis. It does not report any dollar costs, productivity loss, insurance/access data, or Lyme disease case counts or prevalence figures - its focus is entirely on trial design, statistical power, and treatment-effect interpretation, not economic burden.

WHY THIS COULD BE USEFUL
------------------------
This document is a methodological critique of the RCT evidence base behind Lyme disease retreatment guidelines, not a cost-of-illness study, so a simulator built from it can only responsibly convey trial-level clinical outcomes and adverse-event risk, not dollar costs or productivity loss. Care delivery teams and guideline developers could use it to understand why the four foundational NIH-funded trials may have been under-powered or misinterpreted, informing how confidently 'no benefit' claims should be treated in clinical decision-making. Patients and advocates could use the adverse-event figures (e.g., 6/55 in Krupp, 18.9% in Fallon) alongside the reported efficacy findings to weigh retreatment risk-benefit discussions with clinicians. Payers/policy audiences would need to look elsewhere for actual cost, utilization, or productivity-loss data, since none appear in this document.

WHAT YOU COULD DO WITH IT
-------------------------
- A clinician or guideline-panel user could compare the trial-level adverse-event rates (Krupp: 6/55 AEs, 4 serious; Fallon: 18.9% AE rate) against the reported fatigue/cognition efficacy findings to weigh retreatment risk-benefit, while the simulator flags that no cost or productivity data exist in this source.
- A patient/advocate user could see, side by side but explicitly not pooled, how the four trials differed in enrolled population and follow-up window, to understand why 'the trials found no benefit' is a more limited and contested claim than commonly presented in guidelines.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 106 Lyme-related terms (for example, "Lyme", "borreliosis", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
DeLong 2012.pdf

PARAMETERS (6)
--------------
- Krupp STOP-LD trial: total enrolled patients (patients), default 55, source: Document Section 3.2.1 states 55 patients enrolled (28 ceftriaxone, 27 placebo); the 50-60 range is an assumed exploration bound, not from the source.
- Krupp trial: significant adverse events (both arms) (events), default 6, source: Document Section 3.2.1 reports 6 significant adverse events; the 4-8 range is an assumed exploration bound, not from the source.
- Krupp trial: serious adverse events (subset) (events), default 4, source: Document Section 3.2.1 reports 4 serious events (3 sepsis in placebo arm, 1 anaphylaxis in ceftriaxone arm); the 0-4 range is an assumed exploration bound, not from the source.
- Fallon trial: total enrolled patients (patients), default 37, source: Document Section 3.3.1 states 37 patients enrolled (23 ceftriaxone, 14 placebo); the 32-42 range is an assumed exploration bound, not from the source.
- Fallon trial: total adverse events (events), default 7, source: Document Section 3.3.1 reports 7 adverse events (18.9% of 37 patients); the 6-9 range is an assumed exploration bound, not from the source.
- Fallon trial: adverse events in ceftriaxone arm (events), default 6, source: Document Section 3.3.1 states 6 of the 7 adverse events occurred in the ceftriaxone arm; the 0-6 range is an assumed exploration bound, not from the source.

OUTPUTS (4)
-----------
- Krupp trial significant adverse-event rate (% of enrolled patients, both arms combined): 10.9091 (percent) at default assumptions
- Krupp trial: serious adverse events as share of significant adverse events: 66.6667 (percent) at default assumptions
- Fallon trial adverse-event rate (% of enrolled patients, both arms combined): 18.9189 (percent) at default assumptions
- Fallon trial: adverse events occurring in the ceftriaxone arm as share of all Fallon adverse events: 85.7143 (percent) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::30::Table 12 Dental Services Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::20::Table 05-3 Federal Government Sponsor Expenditures.xlsx, scope: general)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::7::Table 20 Private Health Insurance Benefits and  Non-Medical Insurance Expenditures.xlsx, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::0::Table 13 Other Health, Residential, and Personal Care Expenditures.xlsx, scope: general)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::4::Table 17 Durable Medical Equipment Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::22::Table 05-5 Medicare Spending by Sponsor.xlsx, scope: general)

ORIGINAL SOURCE
---------------
Delong AK et al. Antibiotic retreatment of Lyme disease in patients with persistent symptoms: a biostatistical review of randomized, placebo-controlled, clinical trials. Contemp Clin Trials. 2012
  PubMed: https://pubmed.ncbi.nlm.nih.gov/22922244/
  DOI: https://doi.org/10.1016/j.cct.2012.08.009

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.