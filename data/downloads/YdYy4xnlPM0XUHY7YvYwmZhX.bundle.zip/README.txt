================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : YdYy4xnlPM0XUHY7YvYwmZhX
    Generated   : 2026-10-05 20:15:38 UTC
================================================================

TITLE
-----
Long COVID at 36 Months: Work-Performance and Quality-of-Life Gaps (Japanese Hospitalized Cohort)

BOUNDARY
--------
This models three standardized-survey-score comparisons (WHO HPQ presenteeism, SF-36 quality of life, self-rated 'economic condition worsened' percentage) reported at 36 months in a single Japanese multicenter cohort of 515 patients hospitalized with COVID-19 during the first three pandemic waves (Jan 2020-Feb 2021). It does not include any dollar-denominated medical cost, caregiving cost, insurance, or long-term financial data, because none are reported anywhere in this document. Results are from one country, one hospitalized cohort, with no uninfected control group, and the authors state they should not be generalized to non-hospitalized patients, later pandemic periods, or other countries.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a Japanese multicenter study that followed 515 hospitalized COVID-19 patients for three years, asking them repeatedly about symptoms, quality of life, and work productivity. It found that while many symptoms faded over time, fatigue and breathlessness often persisted, and a subset of patients kept experiencing multiple symptoms throughout the three years. Patients whose symptoms were continuous or who had many symptoms reported worse self-rated economic conditions and lower work-productivity scores (presenteeism/absenteeism) than patients whose symptoms resolved. The study measures burden using standardized survey scores (SF-36 quality-of-life score, WHO presenteeism/absenteeism scores) and subjective economic-condition categories, not dollar costs. The authors say that large studies tracking long COVID's long-term socioeconomic impact remain scarce.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could let patients/advocates, clinicians, and policy audiences explore how long COVID's work-productivity and self-rated economic impact differ by symptom trajectory (continuous, relapsing, recovered) and by symptom burden (number/cluster of symptoms) over a 3-year horizon, using standardized, non-monetized survey scores. It cannot answer questions requiring dollar-denominated costs (medical spending, caregiving costs, insurance burden) because none are reported in this document. It is most useful for illustrating relative risk patterns - e.g., that patients with persistent, multi-symptom long COVID face disproportionately worse productivity and QOL outcomes - rather than for generating absolute cost estimates.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients/advocates could use a simulator built on these trajectory- and cluster-specific presenteeism/absenteeism/QOL patterns to understand how having persistent, multiple, versus relapsing symptoms is associated with worse self-reported productivity and economic condition, without implying a specific dollar cost.
- Care delivery teams could use the symptom-cluster-based outcome differences (e.g., the 'multiple symptoms' cluster showing the worst presenteeism, absenteeism, and SF-36 scores) to help flag patients at 3 months who may need closer longitudinal follow-up for socioeconomic as well as physical impact.
- Payers/policy audiences could use the demonstrated variation in self-rated economic worsening by symptom trajectory (continuous 43.6% vs recovered 14.9%) to argue for risk-stratified rather than uniform long COVID support policies, while recognizing the document provides no cost basis for benefit calculations.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 81 Long COVID-related terms (for example, "long COVID", "PASC", "Post-Covid"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Ozawa 2026.pdf

PARAMETERS (6)
--------------
- Long COVID group presenteeism score at 36 months (points (WHO HPQ absolute presenteeism score, 0-100 scale)), default 58.7, source: Default 58.7 is the document's reported mean presenteeism score for the long COVID group at 36 months (Table 1, p.3); the 0-63 range is an assumed exploration bound, narrowed from the full 0-100 scale so sliders cannot reverse the study's own reported direction relative to the asymptomatic group, not itself from the source.
- Asymptomatic group presenteeism score at 36 months (points (WHO HPQ absolute presenteeism score, 0-100 scale)), default 66.2, source: Default 66.2 is the document's reported mean presenteeism score for the asymptomatic (no long COVID) group at 36 months (Table 1, p.3); the 64-100 range is an assumed exploration bound chosen to preserve the study's own reported ordering versus the long COVID group, not itself from the source.
- Long COVID group SF-36 quality-of-life score at 36 months (points (SF-36 score, 0-100 scale)), default 48.0, source: Default 48.0 is the document's reported mean SF-36 score for the long COVID group at 36 months (Table 1, p.3); the 0-50 range is an assumed exploration bound, narrowed from the full 0-100 scale so sliders cannot reverse the study's own reported direction, not itself from the source.
- Asymptomatic group SF-36 quality-of-life score at 36 months (points (SF-36 score, 0-100 scale)), default 52.1, source: Default 52.1 is the document's reported mean SF-36 score for the asymptomatic group at 36 months (Table 1, p.3); the 51-100 range is an assumed exploration bound chosen to preserve the study's own reported ordering versus the long COVID group, not itself from the source.
- Percent reporting worsened economic condition, continuous-symptom group (percent), default 43.6, source: Default 43.6 is the document's reported percentage of patients with continuous symptoms through 36 months who said their economic condition had become worse (p.7, Fig. 5a description); the 20-70 range is an assumed exploration bound chosen so sliders cannot reverse the study's own reported ordering versus the recovered group, not itself from the source.
- Percent reporting worsened economic condition, recovered-symptom group (percent), default 14.9, source: Default 14.9 is the document's reported percentage of patients whose symptoms had resolved by 36 months who said their economic condition had become worse (p.7, Fig. 5a description); the 0-19 range is an assumed exploration bound chosen to preserve the study's own reported ordering versus the continuous group, not itself from the source.

OUTPUTS (3)
-----------
- Asymptomatic-group presenteeism score minus long-COVID-group presenteeism score (positive = long COVID group scored lower, i.e. reported worse work performance): 7.5 (points (WHO HPQ absolute presenteeism score, 0-100 scale)) at default assumptions
- Asymptomatic-group SF-36 score minus long-COVID-group SF-36 score (positive = long COVID group reported worse overall health-related quality of life): 4.1 (points (SF-36 score, 0-100 scale)) at default assumptions
- Percentage-point gap: continuous-symptom group minus recovered-symptom group reporting worsened economic condition (positive = continuous-symptom patients more likely to report worsening): 28.7 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::0::Table 13 Other Health, Residential, and Personal Care Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::4::Table 17 Durable Medical Equipment Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::30::Table 12 Dental Services Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::3::Table 16 Retail Prescription Drugs Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::1::Table 14 Home Health Care Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::2::Table 15 Nursing Care Facilities and Continuing Care Retirement Communities Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::7::Table 20 Private Health Insurance Benefits and  Non-Medical Insurance Expenditures.xlsx, scope: general)

ORIGINAL SOURCE
---------------
Ozawa T et al. Japanese nationwide survey to track the impact of long COVID over 3 years. Environ Health Prev Med. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41161755/
  DOI: https://doi.org/10.1265/ehpm.25-00293

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.