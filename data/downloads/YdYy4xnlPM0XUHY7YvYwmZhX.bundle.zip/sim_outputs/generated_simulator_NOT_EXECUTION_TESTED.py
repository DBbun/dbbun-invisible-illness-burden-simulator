#!/usr/bin/env python3
"""
Reference implementation (standard library only) of the spec:
"Long COVID at 36 Months: Work-Performance and Quality-of-Life Gaps
(Japanese Hospitalized Cohort)"

This script reproduces exactly the arithmetic defined in the spec's
`inputs` defaults and `outputs` expressions. It is a plain calculator,
not a statistical model, and does not simulate patients or costs.
"""

# ---------------------------------------------------------------------------
# Default inputs (from spec["inputs"])
# ---------------------------------------------------------------------------
DEFAULT_INPUTS = {
    "longcovid_presenteeism": 58.7,
    "asymptomatic_presenteeism": 66.2,
    "longcovid_sf36": 48.0,
    "asymptomatic_sf36": 52.1,
    "continuous_econ_worsen_pct": 43.6,
    "recovered_econ_worsen_pct": 14.9,
}

# ---------------------------------------------------------------------------
# Scenarios (from spec["scenarios"]) -- observational subgroup overrides,
# not interventions. Provided only as optional alternate input sets.
# ---------------------------------------------------------------------------
SCENARIOS = {
    "multiple_symptoms_cluster": {
        "longcovid_presenteeism": 48.8,
        "longcovid_sf36": 47.2,
    },
    "continuous_symptom_trajectory": {
        "longcovid_presenteeism": 60,
    },
    "relapsing_symptom_pattern_economic": {
        "continuous_econ_worsen_pct": 21.1,
    },
    "high_symptom_burden_qol": {
        "longcovid_sf36": 45.3,
    },
}


def compute_outputs(inputs):
    """Compute the three spec outputs from a given input dict, using
    exactly the subtract expressions defined in spec["outputs"]."""

    presenteeism_gap = (
        inputs["asymptomatic_presenteeism"] - inputs["longcovid_presenteeism"]
    )
    sf36_qol_gap = inputs["asymptomatic_sf36"] - inputs["longcovid_sf36"]
    econ_worsening_trajectory_gap = (
        inputs["continuous_econ_worsen_pct"] - inputs["recovered_econ_worsen_pct"]
    )

    return {
        "presenteeism_gap": presenteeism_gap,
        "sf36_qol_gap": sf36_qol_gap,
        "econ_worsening_trajectory_gap": econ_worsening_trajectory_gap,
    }


def apply_overrides(base_inputs, overrides):
    """Return a new input dict with the given overrides applied, leaving
    all other values at their defaults."""

    merged = dict(base_inputs)
    merged.update(overrides)
    return merged


def print_outputs(label, inputs, outputs):
    print(f"--- {label} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    print(
        "  presenteeism_gap (points, asymptomatic minus long-COVID): "
        f"{outputs['presenteeism_gap']:.2f}"
    )
    print(
        "  sf36_qol_gap (points, asymptomatic minus long-COVID): "
        f"{outputs['sf36_qol_gap']:.2f}"
    )
    print(
        "  econ_worsening_trajectory_gap (percentage points, "
        "continuous minus recovered): "
        f"{outputs['econ_worsening_trajectory_gap']:.2f}"
    )
    print()


if __name__ == "__main__":
    # Default scenario
    default_outputs = compute_outputs(DEFAULT_INPUTS)
    print_outputs("Default inputs", DEFAULT_INPUTS, default_outputs)

    # Named scenarios from the spec, each applied as overrides on defaults
    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = apply_overrides(DEFAULT_INPUTS, overrides)
        scenario_outputs = compute_outputs(scenario_inputs)
        print_outputs(scenario_id, scenario_inputs, scenario_outputs)