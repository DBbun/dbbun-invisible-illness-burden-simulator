================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : Q5Ml2-H9W7dHXMRqoUQhlngk
    Generated   : 2026-10-05 21:15:51 UTC
================================================================

TITLE
-----
Long COVID Case-Identification: Algorithm vs. U09.9 Diagnosis Code (Azhir et al. 2025)

BOUNDARY
--------
This simulation reproduces precision, prevalence, demographic-composition, and organ-system-symptom figures from a single peer-reviewed study (Azhir et al., 2025, Med) comparing a computational phenotyping algorithm against the U09.9 ICD-10 diagnosis code for identifying long COVID (PASC) in Mass General Brigham electronic health record data (14 hospitals, 20 community health centers), for COVID-19 infections from March 2020-June 2023 with 12-month follow-up. It does not include any dollar cost, insurance/access, lost-income, or caregiving-burden data, because the source document reports none of these. It does not address Lyme disease at all, since the uploaded document's entire subject is long COVID diagnostic/phenotyping methodology.

ABOUT THE SOURCE DOCUMENT
-------------------------
This peer-reviewed study (Azhir et al., 2025, Med) developed a computer algorithm to more accurately identify patients with long COVID (PASC) from electronic health records, comparing it to the standard U09.9 diagnosis code. Using data from over 295,000 patients across 14 hospitals and 20 community health centers in Massachusetts, the algorithm identified 24,360 long-haulers with 79.9% precision, versus 77.8% precision for the U09.9 code alone, and produced a less demographically biased cohort. The study reports how common different organ-system symptom clusters were among COVID-19 patients and documents that the U09.9 code undercounts and skews whom it identifies (toward White, female patients). It does not report any dollar costs, insurance/access burden, lost income, or caregiving time - its contribution is to diagnostic/phenotyping accuracy and demographic bias in identifying long COVID cases, not economic burden.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would primarily serve researchers and health-system teams designing or evaluating long COVID research cohorts, and secondarily inform care-delivery and policy audiences about how diagnostic method choice (ICD-10 code vs. computational phenotyping) changes both the apparent prevalence of long COVID and the demographic composition of who gets counted. It cannot inform questions about dollar costs, insurance burden, or household financial impact, because the document reports none. It is most useful for illustrating diagnostic/measurement uncertainty and demographic bias in long COVID case identification rather than economic burden per se.

WHAT YOU COULD DO WITH IT
-------------------------
- Researchers designing long COVID cohorts could use the simulator to compare how algorithm-based versus U09.9-code-based patient identification changes estimated prevalence (28.5%/22.8% vs. under 5,000 from 6,340 U09.9 cases) and the demographic composition of the resulting cohort (e.g., % female, % White/Black/Hispanic), before deciding how to define a study population.
- Care-delivery and policy audiences could use the organ-system burden breakdown (e.g., 41.2% of long-haulers with systemic symptoms, 16.4% with GI symptoms) to understand which clinical specialties are most frequently implicated in long COVID follow-up care, within the stated 12-month observation window.
- Because this document is specifically about curating research cohorts for downstream genetic/metabolomic/clinical studies, a simulator extension could flag that unscreened differences in patient population composition (e.g., the demographic skew documented between U09.9-coded and algorithm-identified cohorts) could confound future treatment-response comparisons if not accounted for in cohort selection - this is an assumption/extrapolation beyond what the document itself tests, since the document does not discuss environmental exposure confounding specifically.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 196 Long COVID-related terms (for example, "post-acute sequelae", "PASC", "long COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Azhir 2025 phenotyping.pdf

PARAMETERS (8)
--------------
- Raw algorithm-flagged PASC prevalence (% of COVID-19 cases), default 28.5, source: Azhir et al. 2025, Med, Results/Discussion, p.3; 15.0-40.0 range is an assumed exploration bound, not from the source
- Algorithm precision (PPV) (%), default 79.9, source: Azhir et al. 2025, Med, Results, p.3; 60.0-95.0 range is an assumed exploration bound, not from the source
- U09.9-coded patient count (patients), default 6340, source: Azhir et al. 2025, Med, Results, p.3; 3000-10000 range is an assumed exploration bound, not from the source
- U09.9 code precision (PPV) (%), default 77.8, source: Azhir et al. 2025, Med, Results, p.3; 60.0-95.0 range is an assumed exploration bound, not from the source
- Algorithm-identified long-hauler count (patients), default 24360, source: Azhir et al. 2025, Med, Results, p.3; 15000-35000 range is an assumed exploration bound, not from the source
- White-patient share, algorithm-identified cohort (%), default 71.4, source: Azhir et al. 2025, Med, Results, p.3; 50.0-90.0 range is an assumed exploration bound, not from the source
- White-patient share, U09.9-coded cohort (%), default 80.1, source: Azhir et al. 2025, Med, Results, p.3; 50.0-90.0 range is an assumed exploration bound, not from the source
- Systemic-symptom share among long-haulers (% of algorithm-identified long-haulers), default 41.2, source: Azhir et al. 2025, Med, Results, p.3; 20.0-60.0 range is an assumed exploration bound, not from the source

OUTPUTS (5)
-----------
- PPV-adjusted algorithm PASC prevalence: 22.7715 (% of COVID-19 cases) at default assumptions
- PPV-adjusted true-PASC estimate within U09.9-coded cohort: 4932.52 (patients) at default assumptions
- Algorithm-identified count minus PPV-adjusted U09.9 estimate (positive = algorithm identifies more confirmed patients; negative = U09.9 approach identifies more): 19427.5 (patients) at default assumptions
- White-patient share, algorithm cohort minus U09.9 cohort (negative = algorithm identifies a less White-skewed group; positive = algorithm identifies a more White-skewed group): -8.7 (percentage points) at default assumptions
- Algorithm-identified long-haulers with systemic symptoms: 10036.3 (patients) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 503 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::4::Code Descriptions/icd10cm_order_2026.txt, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::1::Code Descriptions/icd10cmCodesFile.pdf, scope: both)

ORIGINAL SOURCE
---------------
Azhir et al. Precision phenotyping for curating research cohorts of patients with unexplained post-acute sequelae of COVID-19. Med. 2025;6:100532
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39520983/
  DOI: https://doi.org/10.1016/j.medj.2024.10.009

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.