#!/usr/bin/env python3
"""
Reference implementation: Long COVID Case-Identification: Algorithm vs. U09.9
Diagnosis Code (Azhir et al. 2025, Med).

Standard-library-only reproduction of the arithmetic specified in the
interactive spec. This is a plain reference implementation of the
input/output expressions, not a reproduction of the source paper's full
statistical model.
"""

DEFAULT_INPUTS = {
    "raw_algorithm_prevalence": 28.5,   # % of COVID-19 cases
    "algorithm_ppv": 79.9,              # %
    "u09_9_raw_count": 6340,            # patients
    "u09_9_ppv": 77.8,                  # %
    "algorithm_identified_count": 24360,  # patients
    "white_share_algorithm": 71.4,      # %
    "white_share_u09_9": 80.1,          # %
    "systemic_pasc_share": 41.2,        # % of algorithm-identified long-haulers
}


def ppv_adjusted_prevalence(inputs):
    """% of COVID-19 cases: raw_algorithm_prevalence * algorithm_ppv / 100"""
    return (inputs["raw_algorithm_prevalence"] * inputs["algorithm_ppv"]) / 100


def u09_9_adjusted_count(inputs):
    """patients: u09_9_raw_count * u09_9_ppv / 100"""
    return (inputs["u09_9_raw_count"] * inputs["u09_9_ppv"]) / 100


def count_difference_algorithm_minus_u09_9(inputs):
    """patients: algorithm_identified_count - u09_9_adjusted_count"""
    return inputs["algorithm_identified_count"] - u09_9_adjusted_count(inputs)


def white_share_gap_algorithm_minus_u09_9(inputs):
    """percentage points: white_share_algorithm - white_share_u09_9"""
    return inputs["white_share_algorithm"] - inputs["white_share_u09_9"]


def systemic_pasc_patient_count(inputs):
    """patients: algorithm_identified_count * systemic_pasc_share / 100"""
    return (inputs["algorithm_identified_count"] * inputs["systemic_pasc_share"]) / 100


def compute_all_outputs(inputs=None):
    """Compute all spec outputs for the given inputs (defaults if None)."""
    if inputs is None:
        inputs = DEFAULT_INPUTS
    merged = dict(DEFAULT_INPUTS)
    merged.update(inputs)

    return {
        "ppv_adjusted_prevalence": ppv_adjusted_prevalence(merged),
        "u09_9_adjusted_count": u09_9_adjusted_count(merged),
        "count_difference_algorithm_minus_u09_9":
            count_difference_algorithm_minus_u09_9(merged),
        "white_share_gap_algorithm_minus_u09_9":
            white_share_gap_algorithm_minus_u09_9(merged),
        "systemic_pasc_patient_count": systemic_pasc_patient_count(merged),
    }


if __name__ == "__main__":
    results = compute_all_outputs(DEFAULT_INPUTS)

    print("Long COVID Case-Identification: Algorithm vs. U09.9 Diagnosis Code")
    print("(Azhir et al. 2025, Med) -- reference arithmetic, default inputs")
    print("=" * 70)

    print(
        "PPV-adjusted algorithm PASC prevalence (% of COVID-19 cases): "
        f"{results['ppv_adjusted_prevalence']:.4f}"
    )
    print(
        "PPV-adjusted true-PASC estimate within U09.9-coded cohort "
        f"(patients): {results['u09_9_adjusted_count']:.4f}"
    )
    print(
        "Algorithm-identified count minus PPV-adjusted U09.9 estimate "
        f"(patients): {results['count_difference_algorithm_minus_u09_9']:.4f}"
    )
    print(
        "White-patient share, algorithm cohort minus U09.9 cohort "
        f"(percentage points): {results['white_share_gap_algorithm_minus_u09_9']:.4f}"
    )
    print(
        "Algorithm-identified long-haulers with systemic symptoms "
        f"(patients): {results['systemic_pasc_patient_count']:.4f}"
    )