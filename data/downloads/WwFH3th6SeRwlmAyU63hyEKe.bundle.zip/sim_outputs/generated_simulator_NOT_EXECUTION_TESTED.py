#!/usr/bin/env python3
"""
Reference implementation: Long COVID and Employment - Cited Background Statistics
from a Qualitative Patient-Experience Study.

This script restates only the background percentages and the single national
dollar figure that the source study cites from OTHER external studies for
context. These are separate, non-poolable background figures from different
populations, time windows, and measurement methods - they must not be summed,
averaged, or pooled into a single burden estimate.

Standard library only. No synthetic patients, no sampling, no plots, no CLI.
"""


def compute_outputs(
    disability_pct=66,
    unable_work_6mo_pct=22,
    reduced_schedule_pct=45,
    unable_return_1yr_pct=18,
    national_lost_wages_usd=170000000000,
):
    """
    Compute the requested outputs. Each output is a direct restatement
    (pass-through) of the corresponding input, as specified. No arithmetic
    combination, summation, or pooling is performed across inputs.

    Returns a dict of output_id -> value.
    """

    # disability_share_output: cited disability share among Long COVID
    # patients (nationwide cohort). Direct restatement of disability_pct.
    disability_share_output = disability_pct

    # unable_work_6mo_output: cited share unable to work at ~6-7 months
    # (international cohort). Direct restatement of unable_work_6mo_pct.
    unable_work_6mo_output = unable_work_6mo_pct

    # reduced_schedule_output: cited share requiring reduced work schedule
    # (international cohort). Direct restatement of reduced_schedule_pct.
    reduced_schedule_output = reduced_schedule_pct

    # unable_return_1yr_output: cited share unable to return to work at
    # 1 year (NY workers' compensation claims). Direct restatement of
    # unable_return_1yr_pct.
    unable_return_1yr_output = unable_return_1yr_pct

    # national_lost_wages_output: cited U.S. national lost-wages estimate
    # (2022, external source). Direct restatement of national_lost_wages_usd.
    # NOTE: this is a productivity/wage-loss estimate, not a patient payment,
    # and must never be added to any patient-payment total.
    national_lost_wages_output = national_lost_wages_usd

    return {
        "disability_share_output": disability_share_output,
        "unable_work_6mo_output": unable_work_6mo_output,
        "reduced_schedule_output": reduced_schedule_output,
        "unable_return_1yr_output": unable_return_1yr_output,
        "national_lost_wages_output": national_lost_wages_output,
    }


if __name__ == "__main__":
    # Default inputs per spec
    disability_pct = 66
    unable_work_6mo_pct = 22
    reduced_schedule_pct = 45
    unable_return_1yr_pct = 18
    national_lost_wages_usd = 170000000000

    results = compute_outputs(
        disability_pct=disability_pct,
        unable_work_6mo_pct=unable_work_6mo_pct,
        reduced_schedule_pct=reduced_schedule_pct,
        unable_return_1yr_pct=unable_return_1yr_pct,
        national_lost_wages_usd=national_lost_wages_usd,
    )

    print("=== Long COVID and Employment: Cited Background Statistics ===")
    print("(Background figures cited from OTHER external studies; not this")
    print(" study's own qualitative findings. Not poolable into one estimate.)")
    print()

    print(
        "Cited disability share among Long COVID patients (nationwide cohort): "
        f"{results['disability_share_output']}%"
    )
    print(
        "Cited share unable to work at 6 months (international cohort): "
        f"{results['unable_work_6mo_output']}%"
    )
    print(
        "Cited share requiring reduced work schedule (international cohort): "
        f"{results['reduced_schedule_output']}%"
    )
    print(
        "Cited share unable to return to work at 1 year (NY workers' "
        f"compensation claims): {results['unable_return_1yr_output']}%"
    )
    print(
        "Cited U.S. national lost-wages estimate (2022, external source): "
        f"${results['national_lost_wages_output']:,}"
    )

    print()
    print(
        "Reminder: these figures come from different populations, time "
        "windows, and measurement methods (self-report cohorts vs. "
        "administrative claims data). Do not sum, average, or pool them "
        "into a single burden estimate, and never add the wage-loss figure "
        "to any patient-payment total."
    )