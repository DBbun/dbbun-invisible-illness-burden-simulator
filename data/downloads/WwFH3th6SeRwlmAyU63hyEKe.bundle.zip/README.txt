================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : WwFH3th6SeRwlmAyU63hyEKe
    Generated   : 2026-10-05 20:15:10 UTC
================================================================

TITLE
-----
Long COVID and Employment: Cited Background Statistics from a Qualitative Patient-Experience Study

BOUNDARY
--------
This simulation represents only the background percentages and the single national dollar figure that this qualitative interview study (21 patients, one post-COVID clinic, Aug-Sept 2022) cites from OTHER external studies for context. It does not represent this study's own data, which are entirely qualitative themes and quotations about job loss, insurance disruption, and emotional impact, with no dollar or productivity figures of its own. The cited figures come from different populations, time windows, and measurement methods and must not be summed, averaged, or pooled into a single burden estimate.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a qualitative interview study of 21 adults with Long COVID recruited from a single academic medical center's post-COVID recovery clinic, conducted in August-September 2022. It describes patients' lived experience of how Long COVID affected their ability to work, including job loss or change, reduced hours, difficulty balancing work with healthcare appointments, loss of income, changes in insurance (higher deductibles, costlier plans), emotional repercussions such as loss of identity and fear of workplace stigma, and barriers to accessing disability benefits or accommodations. The study does not generate its own cost or productivity-loss estimates; its introduction cites several external studies' percentages and a national wage-loss estimate for background context. The authors' own data are entirely qualitative themes and representative quotations, not quantified financial figures.

WHY THIS COULD BE USEFUL
------------------------
This qualitative study gives detailed, patient-voiced illustrations of how Long COVID disrupts employment, income, insurance access, and emotional well-being, which can help healthcare systems, employers, and policy audiences understand the lived mechanisms behind documented employment and wage-loss statistics rather than providing new quantified cost figures itself. Care delivery teams could use the identified themes (financial toxicity, insurance disruption, stigma, accommodation barriers) to design support pathways such as financial navigation, mental health screening, and accommodation-documentation assistance. Patients and advocates could use the thematic findings to validate and articulate their own experiences when seeking support or policy change. Payers and policy audiences should treat this document as qualitative context, not a source of new cost estimates, and should source actual dollar/percentage figures from the primary studies it cites rather than from this paper directly.

WHAT YOU COULD DO WITH IT
-------------------------
- Healthcare systems and clinicians could use the identified barriers (lack of diagnostic documentation for accommodations, insurance disruption, stigma) to design financial-navigation and workplace-accommodation support programs for Long COVID patients.
- Patient advocates could use the qualitative themes (loss of identity, fear of retaliation, insurance cost increases) to contextualize policy discussions about disability recognition and workplace protections for Long COVID, while being clear that the dollar and percentage figures in the simulator originate from the cited external studies, not from this qualitative study's own 21 participants.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 134 Long COVID-related terms (for example, "Long COVID", "post-COVID", "Long-COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
MacEwan 2025 employment.pdf

PARAMETERS (5)
--------------
- Disability prevalence among Long COVID patients (cited cohort, ref. 3) (%), default 66, source: Introduction, p.1070 (citing ref. 3); default is the document's cited 'nearly two-thirds' approximate figure. 0-100% range is an assumed exploration bound, not from the source.
- Unable to work at 6 months post-infection (cited international cohort, ref. 6) (%), default 22, source: Introduction, p.1070 (citing ref. 6, Davis et al. 2021 international online cohort at 7 months). 0-100% range is an assumed exploration bound, not from the source.
- Required reduced work schedule (cited international cohort, ref. 6) (%), default 45, source: Introduction, p.1070 (citing ref. 6, Davis et al. 2021). 0-100% range is an assumed exploration bound, not from the source.
- Unable to return to work at 1 year (cited NY workers' compensation claims, ref. 7) (%), default 18, source: Introduction, p.1070 (citing ref. 7, New York State Insurance Fund workers' compensation claims analysis). 0-100% range is an assumed exploration bound, not from the source.
- Estimated U.S. national lost wages attributable to Long COVID (cited, 2022, ref. 8) (USD), default 170000000000, source: Introduction, p.1070 (citing ref. 8, Suran 2023, JAMA). 100,000,000,000-300,000,000,000 range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- Cited disability share among Long COVID patients (nationwide cohort): 66 (%) at default assumptions
- Cited share unable to work at 6 months (international cohort): 22 (%) at default assumptions
- Cited share requiring reduced work schedule (international cohort): 45 (%) at default assumptions
- Cited share unable to return to work at 1 year (NY workers' compensation claims): 18 (%) at default assumptions
- Cited U.S. national lost-wages estimate (2022, external source): 1.7e+11 (USD) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week58_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_58.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week59_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_59.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week60_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_60.xlsx, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::42::CAEMP25N_OH_2001_2022.csv, scope: general)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week61_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_61.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week62_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_62.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week63_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_63.xlsx, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)

ORIGINAL SOURCE
---------------
MacEwan et al. The Impact of Long COVID on Employment and Well-Being. J Gen Intern Med. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39379779/
  DOI: https://doi.org/10.1007/s11606-024-09062-5

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.