#!/usr/bin/env python3
"""
ED Management Strategies for Primary Spontaneous Pneumothorax
Reference implementation of the decision-analytic model's arithmetic.

This script is a plain reference implementation of the interactive spec.
It does not add synthetic patients, sampling, or plots.
"""

DEFAULT_INPUTS = {
    "cost_observation_only": 5332,
    "cost_continuous_suction": 33728,
    "qaly_observation_only": 49.82,
    "qaly_continuous_suction": 48.76,
    "reported_nmb_observation": 41910,
    "reported_nmb_suction": 12831,
}

SCENARIOS = {
    "abstract_reported_nmb_observation": {"reported_nmb_observation": 43696},
    "real_world_cost_drift_observation": {"cost_observation_only": 10000},
    "thin_evidence_qaly_observation": {"qaly_observation_only": 49.1},
}


def compute_outputs(inputs):
    cost_observation_only = inputs["cost_observation_only"]
    cost_continuous_suction = inputs["cost_continuous_suction"]
    qaly_observation_only = inputs["qaly_observation_only"]
    qaly_continuous_suction = inputs["qaly_continuous_suction"]
    reported_nmb_observation = inputs["reported_nmb_observation"]
    reported_nmb_suction = inputs["reported_nmb_suction"]

    cost_difference_suction_minus_observation = (
        cost_continuous_suction - cost_observation_only
    )

    qaly_difference_observation_minus_suction = (
        qaly_observation_only - qaly_continuous_suction
    )

    reported_incremental_nmb_observation_vs_suction = (
        reported_nmb_observation - reported_nmb_suction
    )

    cost_avoided_per_qaly_gained = (
        cost_difference_suction_minus_observation
        / qaly_difference_observation_minus_suction
    )

    return {
        "cost_difference_suction_minus_observation": cost_difference_suction_minus_observation,
        "qaly_difference_observation_minus_suction": qaly_difference_observation_minus_suction,
        "reported_incremental_nmb_observation_vs_suction": reported_incremental_nmb_observation_vs_suction,
        "cost_avoided_per_qaly_gained": cost_avoided_per_qaly_gained,
    }


def make_scenario_inputs(overrides):
    merged = dict(DEFAULT_INPUTS)
    merged.update(overrides)
    return merged


def print_outputs(label, inputs, outputs):
    print(f"--- {label} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    print(
        "  cost_difference_suction_minus_observation (USD): "
        f"{outputs['cost_difference_suction_minus_observation']:.2f}"
    )
    print(
        "  qaly_difference_observation_minus_suction (QALY): "
        f"{outputs['qaly_difference_observation_minus_suction']:.4f}"
    )
    print(
        "  reported_incremental_nmb_observation_vs_suction (USD): "
        f"{outputs['reported_incremental_nmb_observation_vs_suction']:.2f}"
    )
    print(
        "  cost_avoided_per_qaly_gained (USD per QALY): "
        f"{outputs['cost_avoided_per_qaly_gained']:.2f}"
    )
    print()


if __name__ == "__main__":
    base_inputs = dict(DEFAULT_INPUTS)
    base_outputs = compute_outputs(base_inputs)
    print_outputs("Base case (default inputs)", base_inputs, base_outputs)

    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = make_scenario_inputs(overrides)
        scenario_outputs = compute_outputs(scenario_inputs)
        print_outputs(scenario_id, scenario_inputs, scenario_outputs)