================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : B8RzotP15G9BgVCqIl3lCbOd
    Generated   : 2026-10-10 15:22:15 UTC
================================================================

TITLE
-----
ED Management Strategies for Primary Spontaneous Pneumothorax: Modeled Cost and Value Comparison

BOUNDARY
--------
This simulator reflects one peer-reviewed decision-analytic model comparing four emergency department (ED) strategies for stable, moderate-to-large primary spontaneous pneumothorax (PSP) in a hypothetical 25-year-old US patient, modeled over a lifetime horizon at a 3% discount rate in 2022 US dollars, from a healthcare-organization perspective. It excludes patient out-of-pocket costs, productivity loss, caregiving burden, insurance/access barriers, complication-specific costs, and follow-up costs beyond the index ED encounter, none of which the document quantifies. It does not represent any individual patient's actual bill and should not be scaled to population totals, since the document reports no national case counts or aggregate spending figures.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed decision-analytic cost-effectiveness analysis comparing four emergency department strategies for managing stable, moderate-to-large primary spontaneous pneumothorax (PSP) in adults: observation only, needle aspiration, small-bore chest tube with a 1-way valve, and small-bore chest tube with continuous suction. Using published RCT data and CMS-based costs (2022 USD), the authors built a lifetime-horizon model and found all four strategies cost-effective at a $50,000/QALY threshold, with observation only producing the highest net monetary benefit, followed by the 1-way valve, needle aspiration, and continuous suction (lowest value). The analysis is limited strictly to a US healthcare-organization cost perspective; it does not address patient out-of-pocket costs, productivity loss, caregiving burden, insurance/access barriers, or long-term financial consequences, none of which are quantified here. The document also contains an internal inconsistency between the net-monetary-benefit figure for observation-only reported in the abstract/results text ($43,696 and a $30,865 advantage over suction) and the figure in Table 4 ($41,910 and a $29,079 incremental advantage).

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document's figures would primarily serve emergency medicine clinicians, hospital health-economics/finance teams, and payers or guideline committees who are weighing which ED management strategy to adopt or recommend for stable, moderate-to-large PSP. Because all figures reflect a US healthcare-organization cost perspective with a lifetime-horizon decision model (not direct real-world billing or patient-level spending), the simulator is best suited to protocol-design and budget-impact discussions rather than individual patient cost estimation. The document's own internal inconsistency between its abstract-reported and Table 4-reported NMB values for observation only, and the thin evidence base (single RCT) for that strategy, should be surfaced to users rather than resolved silently.

WHAT YOU COULD DO WITH IT
-------------------------
- A hospital health-economics or clinical-protocol team could compare the per-strategy total modeled costs, QALYs, and NMB figures to estimate the budget impact of shifting large-PSP ED protocols toward observation-only or 1-way-valve chest tubes instead of continuous-suction chest tubes.
- A payer or guideline committee could use the reported probability-of-success ranges (Table 1) and the one-way/probabilistic sensitivity results to explore how much the cost-effectiveness ranking would shift if real-world observation-only success rates differ from the single included RCT's 84.6%.

DETECTED FOCUS
--------------
other: Labeled reuse demonstration chosen by the owner; no federal evidence pack was curated for this condition.

SOURCE FILES
------------
Davis et al 2025.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Lifetime cost - observation only (USD), default 5332, source: Default $5,332 is the document's Table 4 base-case lifetime cost for observation only (p.6); the 0-15000 range is an assumed exploration bound chosen to preserve the document's reported cost ordering (observation cheaper than suction), not from the source.
- Lifetime cost - continuous suction chest tube (USD), default 33728, source: Default $33,728 is the document's Table 4 base-case lifetime cost for continuous suction (p.6); the 20000-45000 range is an assumed exploration bound chosen to preserve the document's reported cost ordering, not from the source.
- Lifetime QALYs - observation only (QALY), default 49.82, source: Default 49.82 QALYs is the document's Table 4 value for observation only (p.6); the 49.1-50.5 range is an assumed exploration bound chosen to preserve the document's reported effectiveness ordering (observation at least as effective as suction), not from the source.
- Lifetime QALYs - continuous suction chest tube (QALY), default 48.76, source: Default 48.76 QALYs is the document's Table 4 value for continuous suction (p.6); the 47.0-49.0 range is an assumed exploration bound chosen to preserve the document's reported effectiveness ordering, not from the source.
- Reported net monetary benefit - observation only (USD), default 41910, source: Default $41,910 is the document's Table 4 reported net monetary benefit for observation only (p.6); the Abstract (p.1) separately states $43,696 for the same quantity, an internal inconsistency the document does not reconcile. The 25000-50000 range is an assumed exploration bound chosen to preserve the document's reported value ordering (observation's NMB exceeding suction's), not from the source.
- Reported net monetary benefit - continuous suction (USD), default 12831, source: Default $12,831 is the document's reported net monetary benefit for continuous suction, consistent between the Abstract (p.1) and Table 4 (p.6). The 0-20000 range is an assumed exploration bound chosen to preserve the document's reported value ordering, not from the source.

OUTPUTS (4)
-----------
- Lifetime cost difference: suction minus observation (positive = suction costs more): 28,396 (USD) at default assumptions
- QALY difference: observation minus suction (positive = observation more effective): 1.06 (QALY) at default assumptions
- Observation's reported net-monetary-benefit advantage over suction: 29,079 (USD) at default assumptions
- Modeled cost avoided per QALY gained, observation vs. suction: 26,788.7 (USD per QALY) at default assumptions

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.