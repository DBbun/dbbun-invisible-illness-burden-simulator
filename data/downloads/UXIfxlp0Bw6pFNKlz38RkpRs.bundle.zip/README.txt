================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : UXIfxlp0Bw6pFNKlz38RkpRs
    Generated   : 2026-10-05 21:16:08 UTC
================================================================

TITLE
-----
Belgian Lyme Disease (Borreliosis) Cost Burden Simulator

BOUNDARY
--------
Models the Geebelen et al. 2022 Belgian cost-of-illness estimate for Lyme borreliosis, comparing early-stage (erythema migrans) and disseminated/late-stage disease costs, covering direct medical, direct non-medical, and productivity-loss costs captured within roughly 6-12 months of diagnosis, in 2019 euros. It does not capture costs beyond that follow-up window, prophylactic treatment, non-reimbursed hospital supplements, pediatric at-home caregiving, or costs specific to post-treatment Lyme disease syndrome (PTLDS), all of which the source study flags as likely underestimated. Figures apply specifically to the Belgian health system and should not be converted directly to other countries' costs.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a Belgian cost-of-illness study that estimates how much Lyme borreliosis (Lyme disease) costs the country each year, using a prospective patient cohort (HUMTICK, 2016-2020) for outpatient costs and national hospital registries for hospitalization costs, all expressed in 2019 euros. It finds a total estimated annual national cost of about €5.59 million, with disseminated/late-stage Lyme disease driving 62% of that cost despite being far less common than the early-stage rash (erythema migrans), because each disseminated/late case costs roughly 26 times more (€5,148 vs €193 per patient). Costs are split across direct medical care, direct non-medical costs (travel, paid help), and indirect costs from missed work, with productivity loss and direct medical care each accounting for roughly half the total. The study explicitly flags major gaps: costs beyond 6-12 months after diagnosis, post-treatment Lyme disease syndrome (PTLDS)-specific costs (based on very small subgroups), prophylactic treatment, and many non-reimbursed hospital costs were not captured, so the true economic burden could be higher than reported.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would be most useful to Belgian/European public-health policymakers and payers weighing budget allocation, surveillance investment, or the cost-effectiveness of prevention measures (e.g., a future tick-bite or Lyme vaccine) against a modeled national cost baseline, since the study explicitly frames its estimate as useful input to future cost-effectiveness and budget-impact analyses. Care delivery teams could use the per-manifestation cost split (EM vs. disseminated/late LB) to understand why early diagnosis and treatment of EM matters economically, given disseminated/late LB costs ~26 times more per patient. Patient/advocate audiences could use the patient-borne cost figures (out-of-pocket medical costs, all direct non-medical costs, and lost income) to illustrate that even in a largely reimbursed system, patients still carry a meaningful share of the burden. All of this applies specifically to the Belgian health system and 2019 euro price year and should not be transposed directly to other countries' dollar costs without explicit conversion and adjustment for differing case-mix and pricing, as the document itself flags when discussing non-comparability with US and other European cost studies.

WHAT YOU COULD DO WITH IT
-------------------------
- Policy analysts comparing the estimated €5.59 million/year Belgian national LB cost baseline against the projected cost of a prevention intervention (e.g., tick-bite prevention campaigns or a future vaccine) in a cost-effectiveness or budget-impact scenario.
- Care delivery teams and clinicians using the EM-vs-disseminated/late-LB per-patient cost contrast (€193 vs €5,148) to motivate faster recognition and treatment of early-stage Lyme disease as an economically high-value early intervention point.
- Patient advocates or payers illustrating that despite 75.5% of direct medical costs being reimbursed, patients still bear out-of-pocket medical costs, all direct non-medical costs (travel, paid help), and potential lost income, to inform discussions about remaining financial burden on patients.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 81 Lyme-related terms (for example, "Lyme", "borreliosis", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Geebelen 2022.pdf

PARAMETERS (7)
--------------
- Mean total cost per early-stage (erythema migrans) patient (EUR/patient), default 193, source: Table 4, p.7; the 0-500 range is an assumed exploration bound, not from the source
- Mean total cost per disseminated/late-stage Lyme patient (EUR/patient), default 5148, source: Table 4, p.7; the 1000-10000 range is an assumed exploration bound chosen to keep this value above the early-stage cost, not from the source
- Patient out-of-pocket cost, early-stage patient (EUR/patient), default 43.9, source: Discussion, p.8; the 0-100 range is an assumed exploration bound, not from the source
- Patient out-of-pocket cost, disseminated/late-stage patient (EUR/patient), default 286, source: Discussion, p.8; the 150-600 range is an assumed exploration bound chosen to keep this value above the early-stage out-of-pocket cost, not from the source
- Total annual Belgian national Lyme disease cost (EUR/year), default 5592056, source: Abstract; Table 4, p.7; the 3,000,000-8,000,000 range is an assumed exploration bound, not from the source
- Share of total national cost from disseminated/late-stage disease (%), default 62, source: Abstract; Results, p.7; the 50-75 range is an assumed exploration bound, not from the source
- Direct medical costs reimbursed by health insurance (%), default 75.5, source: Results/Discussion, p.7-8; the 50-100 range is an assumed exploration bound, not from the source

OUTPUTS (5)
-----------
- Disseminated/late-stage cost as a multiple of early-stage cost: 26.6736 (ratio (x)) at default assumptions
- Early-stage patient out-of-pocket share of total per-patient cost: 22.7461 (%) at default assumptions
- Disseminated/late-stage patient out-of-pocket share of total per-patient cost: 5.55556 (%) at default assumptions
- National annual cost attributable to disseminated/late-stage disease: 3.46707e+06 (EUR/year) at default assumptions
- Non-reimbursed share of direct medical costs (positive = share not covered by insurance): 24.5 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 371 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.json, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Geebelen L et al. Lyme borreliosis in Belgium: a cost-of-illness analysis. BMC Public Health. 2022
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36443755/
  DOI: https://doi.org/10.1186/s12889-022-14380-6

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.