def compute_outputs(inputs):
    em_per_patient_cost = inputs["em_per_patient_cost"]
    disseminated_per_patient_cost = inputs["disseminated_per_patient_cost"]
    em_patient_oop_cost = inputs["em_patient_oop_cost"]
    disseminated_patient_oop_cost = inputs["disseminated_patient_oop_cost"]
    national_total_annual_cost = inputs["national_total_annual_cost"]
    share_disseminated_cost_pct = inputs["share_disseminated_cost_pct"]
    reimbursement_rate_pct = inputs["reimbursement_rate_pct"]

    cost_ratio_disseminated_vs_em = disseminated_per_patient_cost / em_per_patient_cost

    em_patient_oop_share_of_total = (em_patient_oop_cost / em_per_patient_cost) * 100

    disseminated_patient_oop_share_of_total = (
        disseminated_patient_oop_cost / disseminated_per_patient_cost
    ) * 100

    disseminated_share_of_national_cost = national_total_annual_cost * (
        share_disseminated_cost_pct / 100
    )

    non_reimbursed_medical_share_pct = 100 - reimbursement_rate_pct

    return {
        "cost_ratio_disseminated_vs_em": cost_ratio_disseminated_vs_em,
        "em_patient_oop_share_of_total": em_patient_oop_share_of_total,
        "disseminated_patient_oop_share_of_total": disseminated_patient_oop_share_of_total,
        "disseminated_share_of_national_cost": disseminated_share_of_national_cost,
        "non_reimbursed_medical_share_pct": non_reimbursed_medical_share_pct,
    }


def default_inputs():
    return {
        "em_per_patient_cost": 193,
        "disseminated_per_patient_cost": 5148,
        "em_patient_oop_cost": 43.9,
        "disseminated_patient_oop_cost": 286,
        "national_total_annual_cost": 5592056,
        "share_disseminated_cost_pct": 62,
        "reimbursement_rate_pct": 75.5,
    }


if __name__ == "__main__":
    inputs = default_inputs()
    outputs = compute_outputs(inputs)

    print("Belgian Lyme Disease (Borreliosis) Cost Burden Simulator")
    print("=========================================================")
    print()
    print("Inputs (defaults):")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print()
    print("Outputs:")
    print(
        "  cost_ratio_disseminated_vs_em (x): "
        f"{outputs['cost_ratio_disseminated_vs_em']}"
    )
    print(
        "  em_patient_oop_share_of_total (%): "
        f"{outputs['em_patient_oop_share_of_total']}"
    )
    print(
        "  disseminated_patient_oop_share_of_total (%): "
        f"{outputs['disseminated_patient_oop_share_of_total']}"
    )
    print(
        "  disseminated_share_of_national_cost (EUR/year): "
        f"{outputs['disseminated_share_of_national_cost']}"
    )
    print(
        "  non_reimbursed_medical_share_pct (percentage points): "
        f"{outputs['non_reimbursed_medical_share_pct']}"
    )