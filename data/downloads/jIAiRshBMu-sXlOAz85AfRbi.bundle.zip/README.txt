================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : jIAiRshBMu-sXlOAz85AfRbi
    Generated   : 2026-10-10 04:34:41 UTC
================================================================

TITLE
-----
BOLD Study: Lyme Borreliosis Diagnostic Delay, Severity Mix, and Antibiotic Duration (6 European Countries, 2021-2022)

BOUNDARY
--------
This simulator reproduces only the clinical and treatment-pattern measures the BOLD study reports for medically attended Lyme borreliosis cases in the Czech Republic, Germany, Poland, Slovakia, Slovenia, and Sweden (April 2021-December 2022): time to diagnosis by presentation type, hospitalization rate, disseminated-disease proportion, and country-level antibiotic treatment duration. It contains no dollar cost, insurance, caregiving, or productivity-loss data, because the source document reports none.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is the BOLD (Burden of Lyme Disease) study, a prospective, descriptive surveillance study run at 14 primary-care practices in Lyme-endemic areas of the Czech Republic, Germany, Poland, Slovakia, Slovenia, and Sweden between April 2021 and December 2022. It documents how Lyme borreliosis presents clinically (erythema migrans vs. disseminated forms like Lyme arthritis, neuroborreliosis, and carditis), how long it takes patients to be diagnosed, how they are treated with antibiotics, and how much manifestation patterns differ between countries (most strikingly in Slovakia, where Lyme arthritis rather than the classic rash was the dominant presentation). The study reports clinical and treatment-pattern data (diagnostic delay, hospitalization, antibiotic duration/type, prior-episode history) but contains no cost, insurance, caregiving, or productivity-loss data of any kind. The authors note that patient-reported outcomes, laboratory diagnostics, and post-treatment Lyme disease syndrome (PTLDS)/persistent-symptom findings from this same cohort will be published in separate manuscripts not included here.

WHY THIS COULD BE USEFUL
------------------------
This document is a European clinical-epidemiology study, not a costed burden-of-illness analysis, so a simulator built from it can only responsibly model clinical/practical burden parameters (diagnostic delay, manifestation mix, hospitalization rate, antibiotic duration/choice, prior-episode history) by country and cannot generate dollar costs, insurance-access barriers, or productivity-loss estimates without importing external, clearly labeled cost data. Care delivery teams and public health planners in the 6 BOLD countries could use the country-level manifestation and treatment-duration patterns to anticipate caseload composition and diagnostic-delay variation. Vaccine developers or policy analysts (the study's own funders co-develop a Lyme vaccine) could use the disseminated-disease proportions and manifestation mix as an epidemiological input for vaccine-impact scenarios, separate from any economic modeling.

WHAT YOU COULD DO WITH IT
-------------------------
- A care-delivery or public-health planning user could explore how expected diagnostic delay and hospitalization risk differ if a case presents with disseminated disease versus EM, using the document's own observed means/rates, to anticipate clinical workload by country - without inferring any dollar cost from this document.
- A vaccine-impact or policy-planning user could explore how the mix of disseminated vs. EM presentations (and its marked country-to-country variation, especially Slovakia's outlier pattern) might shift under a hypothetical reduction in delayed diagnosis, while explicitly flagging that the document itself cannot separate how much of Slovakia's pattern reflects true biological/epidemiological difference versus diagnostic/classification practice.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 122 Lyme-related terms (for example, "Lyme", "Borreliosis", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Halsby 2026.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Mean diagnostic delay, erythema-migrans-only cases (days), default 13.4, source: Section 3.4, p.8; Table S4. A 5-20 day range is an assumed exploration bound, not from the source, chosen to stay below the disseminated-delay input's range.
- Mean diagnostic delay, disseminated-disease cases (days), default 24.9, source: Section 3.4, p.8; Table S4. A 21-35 day range is an assumed exploration bound, not from the source, chosen to stay above the EM-only delay input's range so the ordering the study reports cannot be reversed by exploration.
- Hospitalization rate among enrolled cases (percent), default 1.3, source: Section 3.5, p.8 (4/315 enrolled cases). A 0-5 percent range is an assumed exploration bound, not from the source.
- Disseminated-disease proportion, all medically attended cases (percent), default 22.8, source: Abstract; Section 3.2, p.4 (182/797 medically attended cases). A 0-80 percent range is an assumed exploration bound, not from the source, chosen to span the country-level variation (1.1 to 78.0 percent) the document itself reports.
- Median antibiotic treatment duration, Slovakia (days), default 9, source: Table 2, pp.9-10 (n=100 enrolled Slovakian cases). A 5-15 day range is an assumed exploration bound, not from the source, chosen to stay below the Poland duration input's range.
- Median antibiotic treatment duration, Poland (days), default 23.5, source: Table 2, pp.9-10 (n=8 enrolled Polish cases). A 16-30 day range is an assumed exploration bound, not from the source, chosen to stay above the Slovakia duration input's range so the study's reported ordering cannot be reversed by exploration.

OUTPUTS (4)
-----------
- Diagnostic delay gap, disseminated minus EM-only (positive = disseminated diagnosed later): 11.5 (days) at default assumptions
- Antibiotic duration gap, Poland minus Slovakia (positive = Poland's typical course longer): 14.5 (days) at default assumptions
- Hospitalization rate, enrolled cases: 1.3 (percent) at default assumptions
- Disseminated-disease proportion, all medically attended cases: 22.8 (percent) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 371 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_d_lyme_antibiotics_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicaid_lyme_antibiotics_2024.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Halsby K et al. Clinical Manifestations of Lyme Borreliosis in Europe: Burden of Lyme Disease Study (BOLD), 2021-2022. Pathogens. 2026
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41901780/
  DOI: https://doi.org/10.3390/pathogens15030327

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.