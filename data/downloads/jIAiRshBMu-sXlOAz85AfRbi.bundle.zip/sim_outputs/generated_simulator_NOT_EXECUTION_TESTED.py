#!/usr/bin/env python3
"""
BOLD Study: Lyme Borreliosis Diagnostic Delay, Severity Mix, and
Antibiotic Duration (6 European Countries, 2021-2022)

Plain reference implementation of the interactive spec's arithmetic.
Standard library only. Not a reproduction of the source paper's full
statistical model; no synthetic patients, sampling, or plotting.
"""

# ---------------------------------------------------------------------------
# Inputs (id -> default value), per spec defaults
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "em_diagnostic_delay_days": 13.4,
    "disseminated_diagnostic_delay_days": 24.9,
    "hospitalization_rate_pct": 1.3,
    "disseminated_proportion_pct": 22.8,
    "slovakia_antibiotic_duration_days": 9,
    "poland_antibiotic_duration_days": 23.5,
}

INPUT_UNITS = {
    "em_diagnostic_delay_days": "days",
    "disseminated_diagnostic_delay_days": "days",
    "hospitalization_rate_pct": "percent",
    "disseminated_proportion_pct": "percent",
    "slovakia_antibiotic_duration_days": "days",
    "poland_antibiotic_duration_days": "days",
}


def compute_outputs(inputs):
    """Compute the spec's output expressions exactly as defined."""

    diagnostic_delay_gap_days = (
        inputs["disseminated_diagnostic_delay_days"]
        - inputs["em_diagnostic_delay_days"]
    )

    antibiotic_duration_gap_days = (
        inputs["poland_antibiotic_duration_days"]
        - inputs["slovakia_antibiotic_duration_days"]
    )

    hospitalization_rate_output = inputs["hospitalization_rate_pct"] + 0

    disseminated_proportion_output = inputs["disseminated_proportion_pct"] + 0

    return {
        "diagnostic_delay_gap_days": diagnostic_delay_gap_days,
        "antibiotic_duration_gap_days": antibiotic_duration_gap_days,
        "hospitalization_rate_output": hospitalization_rate_output,
        "disseminated_proportion_output": disseminated_proportion_output,
    }


OUTPUT_UNITS = {
    "diagnostic_delay_gap_days": "days",
    "antibiotic_duration_gap_days": "days",
    "hospitalization_rate_output": "percent",
    "disseminated_proportion_output": "percent",
}

OUTPUT_LABELS = {
    "diagnostic_delay_gap_days": (
        "Diagnostic delay gap, disseminated minus EM-only "
        "(positive = disseminated diagnosed later)"
    ),
    "antibiotic_duration_gap_days": (
        "Antibiotic duration gap, Poland minus Slovakia "
        "(positive = Poland's typical course longer)"
    ),
    "hospitalization_rate_output": "Hospitalization rate, enrolled cases",
    "disseminated_proportion_output": (
        "Disseminated-disease proportion, all medically attended cases"
    ),
}


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)

    print("Inputs (defaults):")
    for key, value in inputs.items():
        unit = INPUT_UNITS[key]
        print(f"  {key}: {value} {unit}")

    outputs = compute_outputs(inputs)

    print("\nOutputs:")
    for key, value in outputs.items():
        unit = OUTPUT_UNITS[key]
        label = OUTPUT_LABELS[key]
        print(f"  {key} ({label}): {value} {unit}")