def compute_outputs(inputs):
    step1_yield_pct = inputs["step1_yield_pct"]
    cfs_fms_retention_fraction = inputs["cfs_fms_retention_fraction"]
    coinfection_retention_fraction = inputs["coinfection_retention_fraction"]
    comparator_other_disease_yield_pct = inputs["comparator_other_disease_yield_pct"]
    pld_misdiagnosis_pct = inputs["pld_misdiagnosis_pct"]
    ald_misdiagnosis_pct = inputs["ald_misdiagnosis_pct"]
    pld_disabled_pct = inputs["pld_disabled_pct"]
    ald_disabled_pct = inputs["ald_disabled_pct"]

    final_pld_trial_yield_pct = (
        step1_yield_pct * cfs_fms_retention_fraction
    ) * coinfection_retention_fraction

    misdiagnosis_gap_pct = pld_misdiagnosis_pct - ald_misdiagnosis_pct

    disability_gap_pct = pld_disabled_pct - ald_disabled_pct

    yield_vs_benchmark_gap_pct = (
        final_pld_trial_yield_pct - comparator_other_disease_yield_pct
    )

    return {
        "final_pld_trial_yield_pct": final_pld_trial_yield_pct,
        "misdiagnosis_gap_pct": misdiagnosis_gap_pct,
        "disability_gap_pct": disability_gap_pct,
        "yield_vs_benchmark_gap_pct": yield_vs_benchmark_gap_pct,
    }


def default_inputs():
    return {
        "step1_yield_pct": 64,
        "cfs_fms_retention_fraction": 0.61,
        "coinfection_retention_fraction": 0.26,
        "comparator_other_disease_yield_pct": 65,
        "pld_misdiagnosis_pct": 74,
        "ald_misdiagnosis_pct": 43,
        "pld_disabled_pct": 28,
        "ald_disabled_pct": 6,
    }


if __name__ == "__main__":
    inputs = default_inputs()
    outputs = compute_outputs(inputs)

    print("Persistent Lyme Disease Trial-Eligibility and Diagnostic-Burden Explorer")
    print("Default inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")

    print("\nOutputs:")
    print(
        "  final_pld_trial_yield_pct: "
        f"{outputs['final_pld_trial_yield_pct']:.4f}"
    )
    print(
        "  misdiagnosis_gap_pct: "
        f"{outputs['misdiagnosis_gap_pct']:.4f}"
    )
    print(
        "  disability_gap_pct: "
        f"{outputs['disability_gap_pct']:.4f}"
    )
    print(
        "  yield_vs_benchmark_gap_pct: "
        f"{outputs['yield_vs_benchmark_gap_pct']:.4f}"
    )