================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : eNaB4wjgekjmRLzc8_lcuTqi
    Generated   : 2026-10-10 17:16:03 UTC
================================================================

TITLE
-----
Persistent Lyme Disease Trial-Eligibility and Diagnostic-Burden Explorer

BOUNDARY
--------
This simulator reproduces stepwise clinical-trial eligibility yields and diagnostic/functional burden comparisons reported in a 2025 peer-reviewed analysis of the MyLymeData patient registry (persistent Lyme disease [PLD] vs acute Lyme disease [ALD] patients). It contains no medical cost, income-loss, or dollar-denominated data of any kind - the document itself reports none. PLD and ALD are self-identified, cross-sectional labels from the same survey, not matched longitudinal cohorts, and the registry is a self-selected, patient-reported sample not independently chart-confirmed.

ABOUT THE SOURCE DOCUMENT
-------------------------
This peer-reviewed study uses a 4,183-patient Lyme disease registry (MyLymeData) to show that commonly used clinical-trial eligibility criteria exclude roughly 9 out of 10 persistent Lyme disease (PLD) patients, far more than the ~35% typical exclusion seen in other diseases cited by the authors. It documents very high rates of prior misdiagnosis (especially chronic fatigue syndrome, fibromyalgia, and psychiatric conditions), coinfections, work disability, and poor self-rated health in the PLD group compared with the acute Lyme disease (ALD) group. The authors argue that loosening exclusion criteria around coinfections and prior misdiagnoses could raise the recruitable sample yield from about 10% to 64%. This document does not report direct medical costs, non-medical costs, or dollar-denominated indirect costs; its 'burden' evidence is about diagnostic, functional, and research-recruitment burden, not expenditures.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would primarily serve clinical researchers and trial sponsors designing persistent Lyme disease (PLD) studies, by letting them see how specific eligibility criteria (CDC surveillance definition, Rash/Western-blot requirement, exclusion of prior CFS/FMS or psychiatric misdiagnosis, exclusion of coinfections, functional-impairment thresholds) each reduce recruitable sample size and how combinations compound that reduction. Patient advocates could use the same figures to explain, in plain terms, why trials often fail to represent ~90% of people like them. It would have limited direct relevance to payers/policy audiences since the document contains no cost, insurance-claims, or expenditure data - only recruitment-yield and clinical/functional burden figures.

WHAT YOU COULD DO WITH IT
-------------------------
- Trial designers and sponsors could use a simulator built from this document's stepwise eligibility-criteria data to estimate how adding or removing specific exclusion criteria (CFS/FMS misdiagnosis exclusion, coinfection exclusion, CDC surveillance definition requirement) changes projected PLD trial sample yield and recruitment timeline, before finalizing a trial protocol.
- Because this document is itself about clinical trial/cohort eligibility design, a simulator built from it could prompt researchers to screen enrolled PLD/ALD participants for home environmental exposures (mold, mildew, pet dander) before attributing observed treatment-response variance to the studied drug, since unscreened exposure differences between cohort members could otherwise confound drug-response comparisons.
- Patient advocacy groups could use the misdiagnosis and disability figures (e.g., 40% PLD CFS/FMS misdiagnosis, 28% PLD work disability) to illustrate, to clinicians or policymakers, the gap between the clinical PLD population and the narrow population actually studied in RCTs.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 79 Lyme-related terms (for example, "Lyme", "Borrelia", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2025.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Trial-eligible yield after diagnosis+symptom+lab criteria (%), default 64, source: Section 3.3, page 6 (Attrition Sample); 40-70 range is an assumed exploration bound, not from the source
- Retention fraction after excluding prior CFS/fibromyalgia misdiagnosis (fraction), default 0.61, source: Derived by dividing the document's own reported Section 3.3 cumulative yields (39%/64%), page 6; not stated directly by the document as a fraction; 0.3-1.0 range is an assumed exploration bound
- Retention fraction after excluding diagnosed coinfections (fraction), default 0.26, source: Derived by dividing the document's own reported Section 3.3 cumulative yields (10%/39%), page 6; not stated directly by the document as a fraction; 0.1-1.0 range is an assumed exploration bound
- Benchmark trial yield cited from other disease areas (%), default 65, source: Sections 3.3 and 5, pages 6-7 and 9-10, citing Hill et al. 2008 (pulmonary arterial hypertension trials, not Lyme-specific); 50-80 range is an assumed exploration bound
- PLD patients misdiagnosed before Lyme diagnosis (%), default 74, source: Table 2, page 6; 55-90 range is an assumed exploration bound chosen to preserve the study's reported PLD-higher-than-ALD ordering
- ALD patients misdiagnosed before Lyme diagnosis (%), default 43, source: Table 2, page 6; 20-54 range is an assumed exploration bound chosen to preserve the study's reported PLD-higher-than-ALD ordering
- PLD patients self-reporting disabled work status (%), default 28, source: Table 2, page 6; 15-40 range is an assumed exploration bound chosen to preserve the study's reported PLD-higher-than-ALD ordering
- ALD patients self-reporting disabled work status (%), default 6, source: Table 2, page 6; 0-14 range is an assumed exploration bound chosen to preserve the study's reported PLD-higher-than-ALD ordering

OUTPUTS (4)
-----------
- Compounded PLD trial-eligible yield: 10.15 (%) at default assumptions
- Prior-misdiagnosis gap, PLD minus ALD (positive = PLD higher): 31 (percentage points) at default assumptions
- Work-disability share gap, PLD minus ALD (positive = PLD higher): 22 (percentage points) at default assumptions
- PLD trial yield minus other-disease benchmark yield (negative = PLD yield lower): -54.85 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 384 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2022_2023__cdc_9mtj-y2ba.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Johnson L et al. Optimizing Exclusion Criteria for Clinical Trials of Persistent Lyme Disease Using Real-World Data. Healthcare (Basel). 2024
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39791627/
  DOI: https://doi.org/10.3390/healthcare13010020

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.