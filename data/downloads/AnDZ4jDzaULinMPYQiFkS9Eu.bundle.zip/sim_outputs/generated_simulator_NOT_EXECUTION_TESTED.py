#!/usr/bin/env python3
"""
Long COVID Incidence and Risk-Factor Explorer (RECOVER EHR Networks Study)
Reference implementation of the interactive spec's arithmetic only.
Standard library only.
"""

DEFAULT_INPUTS = {
    "n3c_adult_crude_incidence": 10.2,
    "pcornet_adult_crude_incidence": 25.9,
    "pedsnet_child_crude_incidence": 4.0,
    "n3c_adult_excess_incidence": 5.3,
    "pcornet_adult_excess_incidence": 6.3,
    "pedsnet_child_excess_incidence": 1.4,
    "female_hazard_ratio_n3c": 1.41,
    "female_hazard_ratio_pcornet": 1.14,
}

SCENARIOS = {
    "harmonized_270_day_definition": {
        "n3c_adult_crude_incidence": 12.6,
        "pcornet_adult_crude_incidence": 9.6,
    },
    "pediatric_crossover_female_risk": {
        "female_hazard_ratio_n3c": 1.17,
    },
    "pcornet_matches_n3c_female_risk": {
        "female_hazard_ratio_pcornet": 1.41,
    },
}


def compute_outputs(inputs):
    """Compute all defined outputs from a given set of inputs."""
    adult_incidence_network_gap = (
        inputs["pcornet_adult_crude_incidence"] - inputs["n3c_adult_crude_incidence"]
    )

    n3c_adult_excess_incidence_output = inputs["n3c_adult_excess_incidence"]
    pcornet_adult_excess_incidence_output = inputs["pcornet_adult_excess_incidence"]
    pedsnet_child_excess_incidence_output = inputs["pedsnet_child_excess_incidence"]

    female_hazard_ratio_gap = (
        inputs["female_hazard_ratio_n3c"] - inputs["female_hazard_ratio_pcornet"]
    )

    return {
        "adult_incidence_network_gap": adult_incidence_network_gap,
        "n3c_adult_excess_incidence_output": n3c_adult_excess_incidence_output,
        "pcornet_adult_excess_incidence_output": pcornet_adult_excess_incidence_output,
        "pedsnet_child_excess_incidence_output": pedsnet_child_excess_incidence_output,
        "female_hazard_ratio_gap": female_hazard_ratio_gap,
    }


def apply_overrides(base_inputs, overrides):
    """Return a new inputs dict with overrides applied on top of base_inputs."""
    merged = dict(base_inputs)
    merged.update(overrides)
    return merged


def print_outputs(title, outputs):
    print(f"\n--- {title} ---")
    print(
        "adult_incidence_network_gap (PCORnet minus N3C adult crude incidence, "
        f"percentage points): {outputs['adult_incidence_network_gap']:.2f}"
    )
    print(
        "n3c_adult_excess_incidence_output (percentage points): "
        f"{outputs['n3c_adult_excess_incidence_output']:.2f}"
    )
    print(
        "pcornet_adult_excess_incidence_output (percentage points): "
        f"{outputs['pcornet_adult_excess_incidence_output']:.2f}"
    )
    print(
        "pedsnet_child_excess_incidence_output (percentage points): "
        f"{outputs['pedsnet_child_excess_incidence_output']:.2f}"
    )
    print(
        "female_hazard_ratio_gap (N3C minus PCORnet hazard ratio): "
        f"{outputs['female_hazard_ratio_gap']:.2f}"
    )


if __name__ == "__main__":
    print("Long COVID Incidence and Risk-Factor Explorer")
    print("Default inputs:")
    for key, value in DEFAULT_INPUTS.items():
        print(f"  {key}: {value}")

    default_outputs = compute_outputs(DEFAULT_INPUTS)
    print_outputs("Default scenario", default_outputs)

    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = apply_overrides(DEFAULT_INPUTS, overrides)
        scenario_outputs = compute_outputs(scenario_inputs)
        print_outputs(scenario_id, scenario_outputs)