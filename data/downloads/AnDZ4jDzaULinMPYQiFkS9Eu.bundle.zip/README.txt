================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : AnDZ4jDzaULinMPYQiFkS9Eu
    Generated   : 2026-10-07 20:53:11 UTC
================================================================

TITLE
-----
Long COVID Incidence and Risk-Factor Explorer (RECOVER EHR Networks Study)

BOUNDARY
--------
This simulator represents only incidence proportions, background-adjusted ('excess') incidence estimates, and sex-based risk-factor hazard ratios for Long COVID reported from three U.S. electronic health record (EHR) research networks (N3C, PCORnet, PEDSnet), measured within 180 days (or 270 days for a harmonized definition) of a documented COVID-19 infection, 2020-2023. It omits all direct medical costs, non-medical costs, lost income, caregiving time, long-term (beyond 180-270 day) trajectories, and patient-reported validation, none of which this document reports.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed epidemiological study, not a cost study, that used electronic health record (EHR) data from three large U.S. research networks to estimate how often people who had COVID-19 went on to develop Long COVID, using several different computable 'definitions' (algorithms) of the condition. Overall, 10.2%-25.9% of adults and 4.0% of children who tested positive for COVID-19 were identified as having Long COVID within 180 days, depending on which network's algorithm was used; after subtracting a background rate seen in COVID-negative comparison groups, the 'excess' incidence attributable to COVID-19 was estimated at about 5%-6% in adults and 1.4% in children. The study found Long COVID risk was consistently higher in older adults, women, and people with more severe acute COVID-19 or more pre-existing health conditions. The document does not report any direct medical costs, non-medical costs, productivity loss, or caregiving burden - its contribution is solely to the question of how many people are affected and who is at higher risk, not what it costs them.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would be useful to public health surveillance planners, researchers, and clinical care teams interested in the scale and demographic/clinical risk pattern of Long COVID, not to parties needing cost figures, since none are reported here. Patients/advocates could use the risk-factor findings (older age, female sex, severity of acute illness, pre-existing conditions) to understand who is more likely to be affected. Payers/policy audiences could use the range of incidence estimates to gauge potential population scale, but would need to source cost data elsewhere since this document contains none, and should not treat the different networks' and definitions' estimates as a single confidence interval.

WHAT YOU COULD DO WITH IT
-------------------------
- Public health and health-system planners could use the range of crude vs. excess incidence proportions (by network and by definition) as alternate scenario inputs for estimating the population scale of Long COVID needing follow-up care capacity, while keeping clear that each network's point estimate reflects a different computable phenotype, population, and (for the harmonized analysis) a different follow-up window.
- Clinicians and care-delivery teams could use the reported risk factors (age 65+, female sex, acute COVID-19 severity including ICU-level hospitalization, and pre-existing comorbidity burden) to identify which patient subgroups most warrant closer post-COVID-19 follow-up for possible Long COVID.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 161 Long COVID-related terms (for example, "Long COVID", "post-acute sequelae", "U09.9"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Mandel 2025 incidence.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- N3C adult crude incidence (% of COVID-positive adults) (percent), default 10.2, source: Abstract and Results, p.1252 (N3C network, machine-learning-based computable phenotype, index infections within 180 days); 0-50 range is an assumed exploration bound, not from the source
- PCORnet adult crude incidence (% of COVID-positive adults) (percent), default 25.9, source: Abstract and Results, p.1252 (PCORnet network, rules-based ICD-10-category computable phenotype, index infections within 180 days); 0-50 range is an assumed exploration bound, not from the source
- PEDSnet child crude incidence (% of COVID-positive children) (percent), default 4.0, source: Abstract and Results, p.1252 (PEDSnet network, pediatric phenotype requiring 2 diagnoses 28+ days apart, index infections within 180 days); 0-20 range is an assumed exploration bound, not from the source
- N3C adult excess incidence (percentage points) (percentage points), default 5.3, source: Control Group Analysis, Results, p.1257 (N3C, contemporary 2021 COVID-negative control baseline); 0-15 range is an assumed exploration bound, not from the source
- PCORnet adult excess incidence (percentage points) (percentage points), default 6.3, source: Control Group Analysis, Results, p.1257 (PCORnet, contemporary 2021 COVID-negative control baseline); 0-15 range is an assumed exploration bound, not from the source
- PEDSnet child excess incidence (percentage points) (percentage points), default 1.4, source: Control Group Analysis, Results, p.1257 (PEDSnet, contemporary 2021 COVID-negative control baseline); 0-10 range is an assumed exploration bound, not from the source
- N3C adjusted hazard ratio, female vs male (hazard ratio), default 1.41, source: Multivariable Analysis, Results, p.1253 and Table 3 (N3C network); 1.0-2.0 range is an assumed exploration bound, not from the source
- PCORnet adjusted hazard ratio, female vs male (hazard ratio), default 1.14, source: Multivariable Analysis, Results, p.1253 and Table 3 (PCORnet network); 1.0-2.0 range is an assumed exploration bound, not from the source

OUTPUTS (5)
-----------
- PCORnet minus N3C adult crude incidence (positive = PCORnet estimate higher; negative = N3C estimate higher): 15.7 (percentage points) at default assumptions
- N3C adult excess incidence attributable to COVID-19: 5.3 (percentage points) at default assumptions
- PCORnet adult excess incidence attributable to COVID-19: 6.3 (percentage points) at default assumptions
- PEDSnet child excess incidence attributable to COVID-19: 1.4 (percentage points) at default assumptions
- N3C minus PCORnet adjusted hazard ratio for female sex (positive = N3C found a larger female-vs-male risk difference; negative = PCORnet found a larger difference): 0.27 (hazard ratio difference) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 646 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::12::Table and Index/icd10cm_index_2026.pdf, scope: both)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::414::SAGDP8_NC_1997_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)

ORIGINAL SOURCE
---------------
Mandel H et al. Long COVID Incidence Proportion in Adults and Children Between 2020 and 2024: An EHR-Based Study From the RECOVER Initiative. Clin Infect Dis. 2025;80(6):1247-1261
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39907495/
  DOI: https://doi.org/10.1093/cid/ciaf046

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.