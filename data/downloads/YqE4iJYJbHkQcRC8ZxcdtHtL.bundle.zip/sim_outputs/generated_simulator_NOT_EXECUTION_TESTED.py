#!/usr/bin/env python3
"""
Reference implementation of: Long COVID Incidence After SARS-CoV-2 Infection -
Comparing EHR Case-Definition Estimates (RECOVER N3C/PCORnet/PEDSnet)

Standard library only. Plain arithmetic reproduction of the spec's
inputs/outputs for default values. No synthetic patients, no sampling,
no plotting, no CLI.
"""


def compute_outputs(inputs):
    """Compute all defined outputs from the given inputs dict."""
    n3c_adult_crude = inputs["n3c_adult_crude_incidence"]
    pcornet_adult_crude = inputs["pcornet_adult_crude_incidence"]
    n3c_adult_excess = inputs["n3c_adult_excess_incidence"]
    pcornet_adult_excess = inputs["pcornet_adult_excess_incidence"]
    pediatric_crude = inputs["pediatric_crude_incidence"]
    pediatric_excess = inputs["pediatric_excess_incidence"]
    icu_hr = inputs["icu_hospitalization_hazard_ratio"]

    n3c_adult_incidence_gap = n3c_adult_crude - n3c_adult_excess
    pcornet_adult_incidence_gap = pcornet_adult_crude - pcornet_adult_excess
    pediatric_incidence_gap = pediatric_crude - pediatric_excess
    definitional_spread_adults = pcornet_adult_crude - n3c_adult_crude
    icu_hazard_ratio_display = icu_hr * 1

    return {
        "n3c_adult_incidence_gap": n3c_adult_incidence_gap,
        "pcornet_adult_incidence_gap": pcornet_adult_incidence_gap,
        "pediatric_incidence_gap": pediatric_incidence_gap,
        "definitional_spread_adults": definitional_spread_adults,
        "icu_hazard_ratio_display": icu_hazard_ratio_display,
    }


def default_inputs():
    """Default input values per the spec."""
    return {
        "n3c_adult_crude_incidence": 10.2,
        "pcornet_adult_crude_incidence": 25.9,
        "n3c_adult_excess_incidence": 5.3,
        "pcornet_adult_excess_incidence": 6.3,
        "pediatric_crude_incidence": 4.0,
        "pediatric_excess_incidence": 1.4,
        "icu_hospitalization_hazard_ratio": 2.04,
    }


if __name__ == "__main__":
    inputs = default_inputs()
    outputs = compute_outputs(inputs)

    print("Long COVID Incidence After SARS-CoV-2 Infection")
    print("EHR Case-Definition Estimates (RECOVER N3C/PCORnet/PEDSnet)")
    print("=" * 60)
    print()
    print("Default Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print()
    print("Computed Outputs:")
    print(f"  n3c_adult_incidence_gap (percentage points): "
          f"{outputs['n3c_adult_incidence_gap']:.4f}")
    print(f"  pcornet_adult_incidence_gap (percentage points): "
          f"{outputs['pcornet_adult_incidence_gap']:.4f}")
    print(f"  pediatric_incidence_gap (percentage points): "
          f"{outputs['pediatric_incidence_gap']:.4f}")
    print(f"  definitional_spread_adults (percentage points): "
          f"{outputs['definitional_spread_adults']:.4f}")
    print(f"  icu_hazard_ratio_display (hazard ratio): "
          f"{outputs['icu_hazard_ratio_display']:.4f}")