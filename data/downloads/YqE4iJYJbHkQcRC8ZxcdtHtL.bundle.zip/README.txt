================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : YqE4iJYJbHkQcRC8ZxcdtHtL
    Generated   : 2026-10-06 17:05:57 UTC
================================================================

TITLE
-----
Long COVID Incidence After SARS-CoV-2 Infection: Comparing EHR Case-Definition Estimates (RECOVER N3C/PCORnet/PEDSnet)

BOUNDARY
--------
This simulator reproduces only the incidence-proportion estimates and adjusted hazard ratios reported in this EHR-based RECOVER cohort study (N3C, PCORnet, PEDSnet networks; COVID-19-positive patients with index events 2020-2023; outcomes assessed within 180 days of infection, except harmonized analyses which used 270 days and are not modeled here). It does not include any dollar cost, caregiving-time, insurance/access-barrier, or diagnostic-delay data, because the document reports none of these. It must not be used to infer Lyme disease burden, since Lyme disease is never discussed in the source. Crude incidence (not background-adjusted) and excess incidence (background-subtracted, labeled a 'lower bound' by the authors) are two structurally different quantities measured by two structurally different computable phenotypes (N3C: machine-learning model; PCORnet/PEDSnet: rules-based ICD-10 diagnosis-cluster algorithms); this simulator keeps them separate rather than pooling or averaging.

ABOUT THE SOURCE DOCUMENT
-------------------------
This peer-reviewed study used electronic health record data from three large U.S. research networks (N3C, PCORnet, PEDSnet) covering over 6.3 million COVID-19-positive adults and children to estimate how many developed long COVID within 180 days of infection, using each network's own computer-based case definition. It found that 10.2%-25.9% of adults and 4.0% of children were identified as having probable long COVID, with lower 'excess incidence' estimates (5%-6% in adults, 1.4% in children) after subtracting background rates seen in COVID-negative control groups. The study reports who bears higher risk (older adults, women, people with more severe acute COVID-19 or more pre-existing conditions) and finds no decline in incidence through January 2024. The paper does not report any dollar costs, direct or indirect financial burden, insurance/access barriers, or caregiving-time measures - it is purely an epidemiological incidence study.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help care-delivery systems and payer/policy audiences bound the plausible range of how many SARS-CoV-2 survivors go on to develop long COVID, and identify which patient subgroups (older adults, women, those hospitalized or with more pre-existing conditions) carry higher risk - useful for capacity planning and population-level burden estimation. It cannot inform patient/advocate audiences about dollar costs, insurance barriers, or caregiving burden, because the document reports no such figures; any economic layer built on top of these incidence numbers would need to be sourced and labeled separately. Because the paper itself demonstrates a 2.5x spread in incidence (10.2%-25.9%) driven purely by case-definition choice, a simulator must preserve that definitional sensitivity rather than presenting a single point estimate.

WHAT YOU COULD DO WITH IT
-------------------------
- Policy/payer modelers could use the crude (10.2%-25.9%) versus excess (5.3%-6.3%) adult incidence figures as explicitly labeled, non-interchangeable low/high scenario inputs for estimating the share of COVID-19 survivors likely to need ongoing post-COVID evaluation, rather than averaging them into one number.
- Care delivery systems could use the hospitalization/ICU-severity risk gradient (adjusted hazard ratios of roughly 2x-2.8x across networks) to help prioritize structured post-COVID follow-up outreach for previously hospitalized patients, while noting the authors' own caveat that closer clinical follow-up of inpatients may itself inflate detection rates.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 161 Long COVID-related terms (for example, "Long COVID", "post-acute sequelae", "U09.9"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Mandel 2025 incidence.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- N3C adult long COVID crude incidence proportion (percent), default 10.2, source: Results, p.1252; Table 2 (N3C machine-learning-based computable phenotype). 5-15 range is an assumed exploration bound chosen to preserve the document's reported ordering relative to PCORnet's higher estimate, not from the source.
- PCORnet adult long COVID crude incidence proportion (percent), default 25.9, source: Results, p.1252; Table 2 (PCORnet rules-based computable phenotype). 16-35 range is an assumed exploration bound chosen to preserve the document's reported ordering relative to N3C's lower estimate, not from the source.
- N3C adult excess (background-adjusted) long COVID incidence (percent), default 5.3, source: Control Group Analysis, p.1257. 2-10 range is an assumed exploration bound, not from the source.
- PCORnet adult excess (background-adjusted) long COVID incidence (percent), default 6.3, source: Control Group Analysis, p.1257. 3-12 range is an assumed exploration bound, not from the source.
- PEDSnet pediatric long COVID crude incidence proportion (percent), default 4.0, source: Results, p.1252; Table 2. 1-10 range is an assumed exploration bound, not from the source.
- PEDSnet pediatric excess (background-adjusted) long COVID incidence (percent), default 1.4, source: Control Group Analysis, p.1257. 0.5-5 range is an assumed exploration bound, not from the source.
- Adjusted hazard ratio for long COVID after ICU-level hospitalization vs. no hospitalization (N3C) (hazard ratio (no units)), default 2.04, source: Multivariable Analysis, p.1255; Table 3 (N3C). 1-3.5 range is an assumed exploration bound, not from the source; comparable adjusted hazard ratios reported for PCORnet (2.19) and PEDSnet (2.83) are not modeled separately here.

OUTPUTS (5)
-----------
- N3C crude minus excess adult incidence (positive = crude estimate exceeds the excess/background-adjusted estimate; negative = excess exceeds crude, not expected under the study's method but shown for exploration): 4.9 (percentage points) at default assumptions
- PCORnet crude minus excess adult incidence (positive = crude estimate exceeds the excess/background-adjusted estimate; negative = excess exceeds crude, not expected under the study's method but shown for exploration): 19.6 (percentage points) at default assumptions
- PEDSnet crude minus excess pediatric incidence (positive = crude estimate exceeds the excess/background-adjusted estimate; negative = excess exceeds crude, not expected under the study's method but shown for exploration): 2.6 (percentage points) at default assumptions
- PCORnet crude adult incidence minus N3C crude adult incidence (positive = PCORnet's rules-based definition identifies a higher share of patients as long COVID than N3C's ML-based definition; negative would mean the reverse): 15.7 (percentage points) at default assumptions
- Adjusted hazard ratio for long COVID after ICU-level hospitalization vs. no hospitalization (N3C), shown directly: 2.04 (hazard ratio (no units)) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 646 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::12::Table and Index/icd10cm_index_2026.pdf, scope: both)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::414::SAGDP8_NC_1997_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)

ORIGINAL SOURCE
---------------
Mandel et al. Long COVID Incidence Proportion in Adults and Children Between 2020 and 2024: An EHR-Based Study From the RECOVER Initiative. Clin Infect Dis. 2025;80(6):1247-1261
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39907495/
  DOI: https://doi.org/10.1093/cid/ciaf046

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.