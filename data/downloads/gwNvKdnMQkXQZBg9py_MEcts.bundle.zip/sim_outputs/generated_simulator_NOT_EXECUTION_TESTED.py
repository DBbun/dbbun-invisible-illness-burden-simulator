#!/usr/bin/env python3
"""
Reference implementation of the spec:
"Long COVID and Financial Hardship: Income, Education, and
Employment-Loss Channels (BRFSS 2022)"

Standard library only. Plain arithmetic reference implementation of the
interactive spec's default inputs and output expressions. Not a
reproduction of the source paper's statistical model.
"""

DEFAULT_INPUTS = {
    "ame_bills_lowest_income": 11,
    "ame_bills_highest_income": 1,
    "ame_bills_lowest_education": 7,
    "ame_bills_highest_education": 4,
    "pooled_ame_bills_income": 5,
    "mediation_share_bills": 15,
    "employment_loss_prevalence_longcovid": 19.15,
    "employment_loss_prevalence_nolongcovid": 12,
}


def compute_income_group_bill_hardship_gap(inputs):
    return inputs["ame_bills_lowest_income"] - inputs["ame_bills_highest_income"]


def compute_education_group_bill_hardship_gap(inputs):
    return inputs["ame_bills_lowest_education"] - inputs["ame_bills_highest_education"]


def compute_employer_mediated_bill_hardship_pp(inputs):
    return inputs["pooled_ame_bills_income"] * (inputs["mediation_share_bills"] / 100.0)


def compute_employment_loss_prevalence_gap(inputs):
    return (
        inputs["employment_loss_prevalence_longcovid"]
        - inputs["employment_loss_prevalence_nolongcovid"]
    )


def run(inputs=None):
    if inputs is None:
        inputs = dict(DEFAULT_INPUTS)
    else:
        merged = dict(DEFAULT_INPUTS)
        merged.update(inputs)
        inputs = merged

    outputs = {
        "income_group_bill_hardship_gap": compute_income_group_bill_hardship_gap(inputs),
        "education_group_bill_hardship_gap": compute_education_group_bill_hardship_gap(inputs),
        "employer_mediated_bill_hardship_pp": compute_employer_mediated_bill_hardship_pp(inputs),
        "employment_loss_prevalence_gap": compute_employment_loss_prevalence_gap(inputs),
    }
    return inputs, outputs


if __name__ == "__main__":
    inputs, outputs = run()

    print("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        print(f"{k}: {v}")

    print()
    print("=== Outputs ===")
    print(
        "income_group_bill_hardship_gap (percentage points): "
        f"{outputs['income_group_bill_hardship_gap']}"
    )
    print(
        "education_group_bill_hardship_gap (percentage points): "
        f"{outputs['education_group_bill_hardship_gap']}"
    )
    print(
        "employer_mediated_bill_hardship_pp (percentage points): "
        f"{outputs['employer_mediated_bill_hardship_pp']}"
    )
    print(
        "employment_loss_prevalence_gap (percentage points): "
        f"{outputs['employment_loss_prevalence_gap']}"
    )