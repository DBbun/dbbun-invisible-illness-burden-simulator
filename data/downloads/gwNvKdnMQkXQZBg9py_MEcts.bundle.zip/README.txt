================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : gwNvKdnMQkXQZBg9py_MEcts
    Generated   : 2026-10-05 21:16:15 UTC
================================================================

TITLE
-----
Long COVID and Financial Hardship: Income, Education, and Employment-Loss Channels (BRFSS 2022)

BOUNDARY
--------
This simulation represents cross-sectional, survey-weighted associations between long COVID (symptoms lasting 3+ months) and three binary financial-hardship outcomes (food insecurity, inability to pay bills, threat of losing utility service) from 2022 BRFSS data across 40 states plus DC, broken out by income and education subgroups, plus the share of these associations statistically mediated by job loss or reduced work hours. It does NOT represent any dollar-denominated cost, out-of-pocket healthcare spending, caregiving burden, or causal/longitudinal effect - the study's own design cannot establish whether long COVID preceded the hardship. The three hardship outcomes are not summed into a composite burden figure.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed research brief (Datta, Fazlul, and Khan, 2024/2025, Health Services Research) using 2022 BRFSS survey data from 271,076 US adults across 40 states plus DC to study whether long COVID (defined as symptoms lasting 3+ months) is linked to financial hardship - specifically food insecurity, inability to pay bills, and threat of losing utility service. The study found long COVID was associated with higher odds of all three hardships across nearly all income and education levels, with the largest effects among the lowest-income groups, and that 6%-20% of this association (varying by hardship type and subgroup) was explained by job loss or reduced work hours. The paper reports only percentage-point changes in these binary hardship outcomes and a mediation share - it does not report any dollar-denominated cost figures, and it explicitly states it cannot examine other possible channels such as increased out-of-pocket healthcare costs. The authors call for income/education-targeted and broader policy responses to long COVID-related financial hardship.

WHY THIS COULD BE USEFUL
------------------------
This document's disaggregated percentage-point and mediation estimates could inform payers/policymakers designing income- or education-targeted financial-assistance or employment-protection programs for long COVID patients, since it shows hardship risk is elevated across nearly all socioeconomic groups but most acute below 200% of the federal poverty level. Patient advocates could use the employment-loss mediation findings (6%-20% of the hardship association) to support arguments for workplace accommodations, paid leave, or disability protections. Care-delivery teams could use the cancer-financial-toxicity-navigation analogy raised in the Discussion to motivate adoption of similar screening/referral pathways for long COVID patients, though the document itself does not provide a care-delivery protocol.

WHAT YOU COULD DO WITH IT
-------------------------
- A policy/payer-facing module could let users compare the reported percentage-point increases in food insecurity, bill non-payment, and utility-shutoff threat across the document's seven income and four education subgroups to prioritize which populations most need targeted assistance programs (e.g., utility protections, SNAP outreach) - consistent with, but not exceeding, what the document itself measured.
- A patient/advocate-facing module could use the mediation findings (6%-20%, with outcome-specific sub-ranges) to illustrate how much of the long COVID financial-hardship burden traces to employment loss/reduced hours versus other unmeasured channels (e.g., healthcare costs), making clear that the majority of the association remains unexplained by this one mediator in the document's own analysis.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 80 Long COVID-related terms (for example, "Long COVID", "post-COVID", "long-covid"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Datta 2024.pdf

PARAMETERS (8)
--------------
- Bill-nonpayment effect, lowest income group (percentage points), default 11, source: Table 2, p.6 (observed default of 11 percentage points, 95% CI 7-14, p<0.001); 7.0-14.0 range reflects the document's own reported 95% confidence interval, not an assumed exploration bound.
- Bill-nonpayment effect, highest income group (percentage points), default 1, source: Table 2, p.6 (observed default of 1 percentage point, 95% CI 0-2, p<0.05); 0.0-2.0 range reflects the document's own reported 95% confidence interval, not an assumed exploration bound.
- Bill-nonpayment effect, lowest education group (percentage points), default 7, source: Table 2, p.6 (observed default of 7 percentage points, 95% CI 3-12, p<0.001); 5.0-10.0 range is an assumed exploration bound chosen to stay within the document's reported interval while keeping ordering versus the highest-education input.
- Bill-nonpayment effect, highest education group (percentage points), default 4, source: Table 2, p.6 (observed default of 4 percentage points, 95% CI 3-5, p<0.001); 2.0-4.0 range is an assumed exploration bound chosen to keep this input's maximum below the lowest-education input's minimum, preserving the document's reported ordering.
- Pooled bill-nonpayment effect across income subgroups (percentage points), default 5, source: Results p.6, referencing Appendix S1 Figures A2-A7 (observed default of 5 percentage points; 2.0-8.0 range matches the document's own reported 95% CI).
- Share of bill-nonpayment association mediated by job loss/reduced hours (percent), default 15, source: Results p.6 (document reports a range of 10%-20% across subgroups for this specific outcome, not a single point estimate); default of 15 is an assumed midpoint of that reported range, and the 10.0-20.0 range matches the document's own reported subgroup range.
- Share with job loss/reduced hours, adults with long COVID (percent), default 19.15, source: Table 1, p.3 (observed default of 19.15%); 15.0-25.0 range is an assumed exploration bound chosen to keep this input's minimum above the no-long-COVID input's maximum, preserving the document's reported ordering.
- Share with job loss/reduced hours, adults without long COVID (percent), default 12, source: Table 1, p.3 (observed default of 12.00%); 8.0-12.0 range is an assumed exploration bound chosen to keep this input's maximum at or below the long-COVID input's minimum, preserving the document's reported ordering.

OUTPUTS (4)
-----------
- Lowest-income minus highest-income bill-nonpayment effect (positive = lowest-income group shows a larger increase in risk of being unable to pay bills; ranges are set so this cannot go negative): 10 (percentage points) at default assumptions
- Lowest-education minus highest-education bill-nonpayment effect (positive = lowest-education group shows a larger increase in risk of being unable to pay bills; ranges are set so this cannot go negative): 3 (percentage points) at default assumptions
- Portion of pooled bill-nonpayment effect attributable to job loss/reduced hours: 0.75 (percentage points) at default assumptions
- Long-COVID minus non-long-COVID share with job loss/reduced hours (positive = long COVID group had a higher rate; ranges are set so this cannot go negative): 7.15 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::521::SAGDP11_GA_1998_2025.csv, scope: general)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::14::CAEMP25N_GA_2001_2022.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::436::SAGDP8_US_1997_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::247::SAGDP5_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/CAINC1.zip::47::CAINC1_US_1969_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::373::SAGDP7_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Datta BK et al. Long COVID and financial hardship: A disaggregated analysis at income and education levels. Health Serv Res. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39618261/
  DOI: https://doi.org/10.1111/1475-6773.14413

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.