#!/usr/bin/env python3
"""
Lyme Disease Cost Burden Explorer
(Zhang et al. 2006, Maryland Eastern Shore)

Standard-library-only reference implementation of the interactive spec.
This is a plain arithmetic reproduction of the document's own reported
cost figures and the illustrative nationwide scaling exercise described
in the spec. It is NOT a reproduction of the source paper's full
statistical model, and it adds no synthetic patients or sampling.
"""

# ---------------------------------------------------------------------------
# Inputs (defaults as specified)
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "early_stage_direct_cost_1997": 1609,
    "late_stage_direct_cost_1997": 4240,
    "combined_direct_medical_cost_per_patient": 2970,
    "combined_indirect_nonmedical_productivity_cost_per_patient": 5202,
    "national_ld_cases_reported": 23763,
    "mean_total_cost_per_patient": 1965,
    "median_total_cost_per_patient": 281,
}


# ---------------------------------------------------------------------------
# Output computations (expressions exactly as specified)
# ---------------------------------------------------------------------------

def stage_cost_gap_1997(inputs):
    """late_stage_direct_cost_1997 - early_stage_direct_cost_1997"""
    return inputs["late_stage_direct_cost_1997"] - inputs["early_stage_direct_cost_1997"]


def combined_total_cost_per_patient(inputs):
    """combined_direct_medical_cost_per_patient + combined_indirect_nonmedical_productivity_cost_per_patient"""
    return (
        inputs["combined_direct_medical_cost_per_patient"]
        + inputs["combined_indirect_nonmedical_productivity_cost_per_patient"]
    )


def mean_minus_median_gap(inputs):
    """mean_total_cost_per_patient - median_total_cost_per_patient"""
    return inputs["mean_total_cost_per_patient"] - inputs["median_total_cost_per_patient"]


def estimated_nationwide_cost(inputs):
    """combined_total_cost_per_patient * national_ld_cases_reported"""
    return combined_total_cost_per_patient(inputs) * inputs["national_ld_cases_reported"]


# ---------------------------------------------------------------------------
# Output metadata (labels/units for display)
# ---------------------------------------------------------------------------

OUTPUTS = [
    (
        "stage_cost_gap_1997",
        "Late-stage minus early-stage direct medical cost, 1997 cohort",
        "USD",
        stage_cost_gap_1997,
    ),
    (
        "combined_total_cost_per_patient",
        "Combined direct medical plus indirect/nonmedical/productivity-loss cost per patient",
        "USD",
        combined_total_cost_per_patient,
    ),
    (
        "mean_minus_median_gap",
        "Mean minus median total cost per patient, all diagnosis groups",
        "USD",
        mean_minus_median_gap,
    ),
    (
        "estimated_nationwide_cost",
        "Projected nationwide annual economic impact of LD and related complaints (illustrative extrapolation)",
        "USD/year",
        estimated_nationwide_cost,
    ),
]


def compute_all_outputs(inputs):
    results = {}
    for output_id, _label, _unit, func in OUTPUTS:
        results[output_id] = func(inputs)
    return results


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)

    print("Lyme Disease Cost Burden Explorer")
    print("(Zhang et al. 2006, Maryland Eastern Shore) - default inputs")
    print()

    print("Inputs:")
    for key, value in inputs.items():
        print(f"  {key} = {value}")
    print()

    print("Outputs:")
    results = compute_all_outputs(inputs)
    for output_id, label, unit, _func in OUTPUTS:
        value = results[output_id]
        print(f"  {output_id}: {value} {unit}")
        print(f"    ({label})")