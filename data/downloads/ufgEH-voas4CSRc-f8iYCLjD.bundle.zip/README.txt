================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : ufgEH-voas4CSRc-f8iYCLjD
    Generated   : 2026-10-05 20:15:24 UTC
================================================================

TITLE
-----
Lyme Disease Cost Burden Explorer (Zhang et al. 2006, Maryland Eastern Shore)

BOUNDARY
--------
This simulation represents direct medical, indirect medical, nonmedical, and productivity-loss costs documented for one Maryland Eastern Shore cohort of Lyme disease (LD) patients, 1997-2000, as reported in a peer-reviewed CDC-authored study. It omits costs beyond the 2000 study window, intangible pain-and-suffering costs, public-health surveillance/administration costs, and any breakdown by age, race/ethnicity, disability, or income (the document did not report these). The nationwide projection is an illustrative scaling exercise, not a validated national estimate.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed CDC-authored study (Zhang et al. 2006, Emerging Infectious Diseases) that measured the economic impact of Lyme disease on the Maryland Eastern Shore from 1997 to 2000, using medical-record charge data plus a patient-mailed cost/risk questionnaire (reproduced in the appendix). It found that mean direct medical costs per patient fell over the study period for both early-stage (from $1,609 to $464) and late-stage disease (from $4,240 to $1,380), and it computed an overall expected mean cost of $1,965 and median cost of $281 per patient (2000 dollars) across all diagnosis groups, combining direct medical costs with indirect medical costs, nonmedical costs (travel, paid help), and productivity losses. The authors extrapolated their regional per-case cost data to the 23,763 Lyme disease cases reported nationally to CDC in 2002, estimating a nationwide economic impact of about $203 million (2002 dollars), while explicitly noting this is likely an underestimate because surveillance-based national case counts are believed to be underreported. The study has substantial acknowledged limitations: a low survey response rate (~22%), indirect/nonmedical/productivity cost data drawn from only ~8% of the total patient population and restricted to 1997-1998, exclusion of intangible costs (pain and suffering) and costs beyond the study window, and use of a clinical rather than surveillance case definition that the authors say may have overestimated case counts.

WHY THIS COULD BE USEFUL
------------------------
This 2006 CDC-authored peer-reviewed study and its appended patient cost questionnaire provide a field-collected, multi-component (direct medical, indirect medical, nonmedical, and productivity-loss) cost estimate for Lyme disease in one U.S. endemic region, broken out by disease stage. A simulator built on it could let patients/advocates, clinicians/care-delivery teams, and payers/policymakers explore how documented per-patient costs differ between early- and late-stage disease, how skewed (mean vs. median) the cost distribution is, and how a regional per-case cost might be scaled - with explicit caveats about case-definition and extrapolation uncertainty - to a national reported case count. It cannot support any Long COVID modeling, lifetime/chronic post-treatment cost estimation beyond the 1997-2000 window, or cost breakdowns by age, race, disability, or other protected subgroup categories, since the document does not provide these.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients/advocates could use the stage-specific median and mean cost figures (e.g., $397 median for early-stage vs. $923 median for late-stage LD, 2000 dollars) to illustrate how documented out-of-pocket and productivity costs differ when diagnosis/treatment occurs at an earlier vs. later disease stage in this cohort.
- Payers/policymakers could use the combined per-patient direct medical cost ($2,970) plus indirect/nonmedical/productivity-loss cost ($5,202) figures, scaled against a selectable annual reported Lyme case count, to produce an order-of-magnitude cost projection - while the simulator must flag that the $203 million national figure in the source document is an extrapolation from one regional, clinically defined cohort, not a nationally representative claims- or surveillance-matched estimate.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 45 Lyme-related terms (for example, "Lyme", "Borrelia"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Zhang 2006 supplement.pdf
Zhang 2006.pdf

PARAMETERS (7)
--------------
- Early-stage direct medical cost per patient, 1997 cohort (USD), default 1609, source: Results, p.657; default is the document's own reported 1997-cohort mean; 1200-2000 range is an assumed exploration bound, not from the source
- Late-stage direct medical cost per patient, 1997 cohort (USD), default 4240, source: Results, p.657; default is the document's own reported 1997-cohort mean; 3500-5000 range is an assumed exploration bound, not from the source
- Combined direct medical cost per patient (early/late-stage) (USD), default 2970, source: Discussion, p.658 (derived by the document from $1,455,081 total charges across 490 cases); 2000-4000 range is an assumed exploration bound, not from the source
- Combined indirect/nonmedical/productivity-loss cost per patient (USD), default 5202, source: Discussion, p.658 (derived by the document from $436,949 total across 84 survey-responding cases); 3000-7000 range is an assumed exploration bound, not from the source
- National LD cases reported to CDC (cases/year), default 23763, source: Introduction, p.653 (2002 reported case count); 15000-35000 range is an assumed exploration bound, not from the source
- Mean total cost per patient, all diagnosis groups (USD), default 1965, source: Results, p.657, Figure 3; 1000-3000 range is an assumed exploration bound, not from the source
- Median total cost per patient, all diagnosis groups (USD), default 281, source: Abstract; Results, p.657, Figure 3; 100-500 range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Late-stage minus early-stage direct medical cost, 1997 cohort (positive = late-stage costs more; cannot be negative given the chosen input ranges): 2631 (USD) at default assumptions
- Combined direct medical plus indirect/nonmedical/productivity-loss cost per patient: 8172 (USD) at default assumptions
- Mean minus median total cost per patient, all diagnosis groups (positive = distribution is right-skewed by a small number of high-cost patients; cannot be negative given the chosen input ranges, consistent with the document's reported values): 1684 (USD) at default assumptions
- Projected nationwide annual economic impact of LD and related complaints (illustrative extrapolation): 1.94191e+08 (USD/year) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 553 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::1::ed2017.do, scope: both)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::310::SAGDP6_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Zhang X et al. Economic impact of Lyme disease. Emerg Infect Dis. 2006
  PubMed: https://pubmed.ncbi.nlm.nih.gov/16704815/
  DOI: https://doi.org/10.3201/eid1204.050602

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.