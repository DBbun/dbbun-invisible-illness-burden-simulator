#!/usr/bin/env python3
"""
Reference implementation of the Lyme Disease Direct Health Care Costs
by Disease Severity simulation spec (Optum Claims, 2016-2022).

Standard library only. Plain arithmetic reference implementation of
the interactive spec's inputs and output expressions.
"""

# ---------------------------------------------------------------------------
# Default inputs (editable in spirit, but this script just uses defaults)
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "localized_episode_cost": 695,
    "disseminated_episode_cost": 6833,
    "oop_overall_episode_cost": 188,
    "oop_disseminated_episode_cost": 401,
    "disseminated_cost_share_pct": 68.9,
    "extrapolated_lower_bound": 591254945,
    "extrapolated_upper_bound": 1053957192,
}


def compute_outputs(inputs):
    """Compute the spec's output expressions from the given inputs dict."""

    localized_episode_cost = inputs["localized_episode_cost"]
    disseminated_episode_cost = inputs["disseminated_episode_cost"]
    oop_overall_episode_cost = inputs["oop_overall_episode_cost"]
    oop_disseminated_episode_cost = inputs["oop_disseminated_episode_cost"]
    disseminated_cost_share_pct = inputs["disseminated_cost_share_pct"]
    extrapolated_lower_bound = inputs["extrapolated_lower_bound"]
    extrapolated_upper_bound = inputs["extrapolated_upper_bound"]

    episode_cost_difference_disseminated_vs_localized = (
        disseminated_episode_cost - localized_episode_cost
    )

    oop_cost_difference_disseminated_vs_overall = (
        oop_disseminated_episode_cost - oop_overall_episode_cost
    )

    # multiply by const 1 per spec expression
    disseminated_cost_share_output = disseminated_cost_share_pct * 1

    extrapolation_range_width = (
        extrapolated_upper_bound - extrapolated_lower_bound
    )

    return {
        "episode_cost_difference_disseminated_vs_localized": episode_cost_difference_disseminated_vs_localized,
        "oop_cost_difference_disseminated_vs_overall": oop_cost_difference_disseminated_vs_overall,
        "disseminated_cost_share_output": disseminated_cost_share_output,
        "extrapolation_range_width": extrapolation_range_width,
    }


if __name__ == "__main__":
    inputs = DEFAULT_INPUTS
    outputs = compute_outputs(inputs)

    print("Lyme Disease Direct Health Care Costs by Disease Severity")
    print("(Optum Claims, 2016-2022) - Reference Arithmetic Output")
    print("=" * 70)

    print("\nInputs (defaults):")
    for k, v in inputs.items():
        print(f"  {k}: {v}")

    print("\nOutputs:")
    print(
        "  episode_cost_difference_disseminated_vs_localized (USD): "
        f"{outputs['episode_cost_difference_disseminated_vs_localized']}"
    )
    print(
        "  oop_cost_difference_disseminated_vs_overall (USD): "
        f"{outputs['oop_cost_difference_disseminated_vs_overall']}"
    )
    print(
        "  disseminated_cost_share_output (percent of total LD-specific "
        f"direct episode costs): {outputs['disseminated_cost_share_output']}"
    )
    print(
        "  extrapolation_range_width (USD): "
        f"{outputs['extrapolation_range_width']}"
    )