================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : QOvKi9zPFLTSAkpN44VCVOuI
    Generated   : 2026-10-06 17:06:11 UTC
================================================================

TITLE
-----
Lyme Disease Direct Health Care Costs by Disease Severity (Optum Claims, 2016-2022)

BOUNDARY
--------
This simulation reflects claims/EHR-based direct (insurer-allowed) and out-of-pocket medical costs for insured Lyme disease patients in the Optum Market Clarity database, 2016-2022, stratified by localized vs disseminated disease, plus the study's own high-incidence-state annual cost extrapolation. It excludes indirect costs (lost wages, caregiver time), costs beyond a 6-month follow-up window, uninsured or discontinuously insured patients, and does not pool the study's four distinct cost-estimation methods or add out-of-pocket costs on top of direct costs.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a JAMA Network Open cohort study (plus its online supplement) that used a large US insurance claims and electronic health record database (Optum Market Clarity, 2016-2022) to estimate the health care costs of Lyme disease (LD) for 70,531 identified case patients, comparing localized, disseminated, and indeterminate disease. It reports direct (standardized, insurer-allowed) costs and the smaller subset of available patient out-of-pocket (OOP) costs, using four different cost-estimation methods (per-episode costs, before/after self-comparison, matched case-control, and multivariable-adjusted case-control). Costs were consistently higher for disseminated LD than localized LD across all methods, and the authors extrapolate from their sample to project that total annual LD health care costs in 16 high-incidence states plus DC could range from about $591 million to $1.05 billion (2022 dollars). The study explicitly excludes indirect costs (lost wages, caregiver time) and does not capture costs beyond a 6-month follow-up window, so it does not speak to longer-term persistent-symptom burden.

WHY THIS COULD BE USEFUL
------------------------
This study provides claims-based, per-episode and 6-month per-patient direct and out-of-pocket cost figures for Lyme disease, stratified by disease severity (localized/disseminated/indeterminate) and by state LD-incidence status, plus a high-incidence-state national cost extrapolation. Patients and advocates could use the per-episode and OOP figures to understand typical insured-patient cost exposure for localized versus disseminated LD, while care delivery teams could use the cost-ratio and cost-difference figures to anticipate the resource burden of disseminated disease relative to localized disease. Payers and policymakers could use the high-incidence-state extrapolation ($591M-$1.05B, 2022 USD) as one input into estimating the aggregate economic burden of LD, provided they preserve the stated population, time-window, and methodological boundaries rather than treating it as a single precise national total or as inclusive of indirect costs.

WHAT YOU COULD DO WITH IT
-------------------------
- A patient or advocate audience could compare expected 6-month OOP cost ranges ($107-$401 per episode depending on disease classification) against their own insurance cost-sharing structure to anticipate out-of-pocket exposure for localized versus disseminated LD, while recognizing these figures reflect only the 15.5% insured subset with OOP data available.
- A payer or policy audience could use the episode, self-controls, and case-control cost-difference estimates as separate (not averaged) inputs for high-incidence-state LD cost-burden modeling, explicitly excluding indirect costs and costs beyond 6 months, consistent with the study's own stated limitations.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 76 Lyme-related terms (for example, "Lyme", "borreliosis", "Borrelia"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Yu 2026 supplement.pdf
Yu 2026.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- Localized LD direct cost per episode (USD), default 695, source: Observed default ($695) from Table 2, p.6; the 400-1200 range is an assumed exploration bound chosen to keep this below the disseminated cost range, not from the source.
- Disseminated LD direct cost per episode (USD), default 6833, source: Observed default ($6833) from Table 2, p.6; the 5000-9000 range is an assumed exploration bound chosen so it cannot overlap with the localized input's range, preserving the document's reported ordering, not from the source.
- Overall out-of-pocket cost per episode (USD), default 188, source: Observed default ($188) from Table 2, p.6, based on the 15.5% subset of case patients with OOP claims data; the 50-290 range is an assumed exploration bound, not from the source.
- Disseminated LD out-of-pocket cost per episode (USD), default 401, source: Observed default ($401) from Table 2, p.6; the 300-650 range is an assumed exploration bound chosen so it cannot overlap with the overall-OOP input's range, preserving the document's reported ordering, not from the source.
- Share of total episode costs from disseminated disease (percent of total LD-specific direct episode costs), default 68.9, source: Observed default (68.9%) from Results text, p.5 and Discussion, p.10; the 50-85 range is an assumed exploration bound, not from the source.
- Extrapolated annual LD cost, high-incidence states (episode-based, lower) (USD), default 591254945, source: Observed default ($591,254,945) from eTable 12, p.2 (Supplement 1) and Abstract/Conclusion, p.1, p.11; the 400M-700M range is an assumed exploration bound chosen so it cannot overlap with the upper-bound input's range, preserving the document's reported ordering, not from the source.
- Extrapolated annual LD cost, high-incidence states (case-control-based, upper) (USD), default 1053957192, source: Observed default ($1,053,957,192) from eTable 12, p.2 (Supplement 1) and Abstract/Conclusion, p.1, p.11; the 900M-1200M range is an assumed exploration bound chosen so it cannot overlap with the lower-bound input's range, preserving the document's reported ordering, not from the source.

OUTPUTS (4)
-----------
- Disseminated minus localized LD episode cost (positive = disseminated costs more, per the document's consistent finding): 6138 (USD) at default assumptions
- Disseminated minus overall out-of-pocket LD episode cost (positive = disseminated patients pay more out of pocket): 213 (USD) at default assumptions
- Share of total LD-specific direct episode costs from disseminated disease: 68.9 (percent of total LD-specific direct episode costs) at default assumptions
- Extrapolated annual cost range width: upper bound minus lower bound: 4.62702e+08 (USD) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 722 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_d_lyme_antibiotics_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicaid_lyme_antibiotics_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_d_spending_by_drug_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicaid_spending_by_drug_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_b_ceftriaxone_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_b_spending_by_drug_2024.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Yu H et al. Lyme Disease and Health Care Costs. JAMA Netw Open. 2026
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41533379/
  DOI: https://doi.org/10.1001/jamanetworkopen.2025.52518

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.