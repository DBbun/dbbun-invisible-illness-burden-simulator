def get_default_inputs():
    """Default input values for the Long COVID employment scenario tool."""
    return {
        "annual_wage_assumed": 55000,
        "pct_unable_return_1yr": 18,
        "pct_reduced_schedule_6mo": 45,
        "reduced_schedule_income_fraction_assumed": 0.5,
        "national_lost_wages_2022": 170000000000,
    }


def compute_outputs(inputs):
    """Compute the illustrative income-loss outputs from the given inputs."""
    annual_wage = inputs["annual_wage_assumed"]
    pct_unable = inputs["pct_unable_return_1yr"]
    pct_reduced = inputs["pct_reduced_schedule_6mo"]
    reduced_fraction = inputs["reduced_schedule_income_fraction_assumed"]
    national_wages = inputs["national_lost_wages_2022"]

    illustrative_income_loss_unable_to_work = annual_wage * (pct_unable / 100)

    illustrative_income_loss_reduced_schedule = (
        annual_wage * (pct_reduced / 100)
    ) * reduced_fraction

    income_loss_gap_unable_vs_reduced = (
        illustrative_income_loss_unable_to_work
        - illustrative_income_loss_reduced_schedule
    )

    national_lost_wages_cited_output = national_wages

    return {
        "illustrative_income_loss_unable_to_work": illustrative_income_loss_unable_to_work,
        "illustrative_income_loss_reduced_schedule": illustrative_income_loss_reduced_schedule,
        "income_loss_gap_unable_vs_reduced": income_loss_gap_unable_vs_reduced,
        "national_lost_wages_cited_output": national_lost_wages_cited_output,
    }


def compute_trajectories(outputs, periods=3):
    """Compute flat cumulative trajectories over the given number of periods."""
    unable_annual = outputs["illustrative_income_loss_unable_to_work"]
    reduced_annual = outputs["illustrative_income_loss_reduced_schedule"]

    cumulative_unable = []
    prev = 0
    for _ in range(periods):
        prev = prev + unable_annual
        cumulative_unable.append(prev)

    cumulative_reduced = []
    prev = 0
    for _ in range(periods):
        prev = prev + reduced_annual
        cumulative_reduced.append(prev)

    return {
        "cumulative_income_loss_unable_to_work": cumulative_unable,
        "cumulative_income_loss_reduced_schedule": cumulative_reduced,
    }


if __name__ == "__main__":
    inputs = get_default_inputs()
    outputs = compute_outputs(inputs)
    trajectories = compute_trajectories(outputs, periods=3)

    print("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        print(f"{k}: {v}")

    print()
    print("=== Outputs ===")
    print(
        "illustrative_income_loss_unable_to_work (USD): "
        f"{outputs['illustrative_income_loss_unable_to_work']:.2f}"
    )
    print(
        "illustrative_income_loss_reduced_schedule (USD): "
        f"{outputs['illustrative_income_loss_reduced_schedule']:.2f}"
    )
    print(
        "income_loss_gap_unable_vs_reduced (USD): "
        f"{outputs['income_loss_gap_unable_vs_reduced']:.2f}"
    )
    print(
        "national_lost_wages_cited_output (USD): "
        f"{outputs['national_lost_wages_cited_output']:.2f}"
    )

    print()
    print("=== Trajectories (3 illustrative years, flat annual figure) ===")
    print("cumulative_income_loss_unable_to_work (USD/patient):")
    for year, value in enumerate(
        trajectories["cumulative_income_loss_unable_to_work"], start=1
    ):
        print(f"  year {year}: {value:.2f}")

    print("cumulative_income_loss_reduced_schedule (USD/patient):")
    for year, value in enumerate(
        trajectories["cumulative_income_loss_reduced_schedule"], start=1
    ):
        print(f"  year {year}: {value:.2f}")