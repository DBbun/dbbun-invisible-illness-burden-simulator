# Lyme Disease Direct Health Care Cost Explorer (Claims-Based, 2016-2022)
# Reference implementation: standard library only, no plotting, no CLI, no sampling.
# Reproduces the input defaults and output expressions exactly as specified.

# ----------------------------
# Inputs (defaults as specified)
# ----------------------------

DEFAULT_INPUTS = {
    "localized_episode_direct_cost": 695,
    "disseminated_episode_direct_cost": 6833,
    "multivariable_adjusted_cost_diff_overall": 5571,
    "multivariable_adjusted_cost_diff_disseminated": 15834,
    "annual_us_ld_cases": 476000,
    "high_incidence_state_share": 0.81,
    "case_identification_ppv": 0.766,
    "oop_cost_overall": 188,
}


# ----------------------------
# Output expressions
# ----------------------------

def severity_cost_gap(inputs):
    """Disseminated minus localized direct cost per episode."""
    return inputs["disseminated_episode_direct_cost"] - inputs["localized_episode_direct_cost"]


def severity_cost_ratio(inputs):
    """Disseminated divided by localized direct cost per episode."""
    return inputs["disseminated_episode_direct_cost"] / inputs["localized_episode_direct_cost"]


def adjusted_severity_cost_gap(inputs):
    """Adjusted disseminated minus adjusted overall 6-month cost difference."""
    return (
        inputs["multivariable_adjusted_cost_diff_disseminated"]
        - inputs["multivariable_adjusted_cost_diff_overall"]
    )


def estimated_annual_high_incidence_cases(inputs):
    """Estimated annual Lyme disease cases, high-incidence states."""
    return (
        inputs["annual_us_ld_cases"]
        * inputs["high_incidence_state_share"]
        * inputs["case_identification_ppv"]
    )


def patient_oop_cost_per_episode(inputs):
    """Patient out-of-pocket cost per episode (not combined with direct costs)."""
    return inputs["oop_cost_overall"]


def compute_outputs(inputs):
    return {
        "severity_cost_gap": severity_cost_gap(inputs),
        "severity_cost_ratio": severity_cost_ratio(inputs),
        "adjusted_severity_cost_gap": adjusted_severity_cost_gap(inputs),
        "estimated_annual_high_incidence_cases": estimated_annual_high_incidence_cases(inputs),
        "patient_oop_cost_per_episode": patient_oop_cost_per_episode(inputs),
    }


if __name__ == "__main__":
    inputs = DEFAULT_INPUTS
    outputs = compute_outputs(inputs)

    print("Lyme Disease Direct Health Care Cost Explorer (Claims-Based, 2016-2022)")
    print("=" * 75)
    print("\nInputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key}: {value}")

    print("\nOutputs:")
    print(
        f"  severity_cost_gap "
        f"(disseminated - localized, USD/episode): {outputs['severity_cost_gap']:.2f}"
    )
    print(
        f"  severity_cost_ratio "
        f"(disseminated / localized): {outputs['severity_cost_ratio']:.4f}"
    )
    print(
        f"  adjusted_severity_cost_gap "
        f"(adjusted disseminated - adjusted overall, USD/6mo): "
        f"{outputs['adjusted_severity_cost_gap']:.2f}"
    )
    print(
        f"  estimated_annual_high_incidence_cases "
        f"(cases/year): {outputs['estimated_annual_high_incidence_cases']:.2f}"
    )
    print(
        f"  patient_oop_cost_per_episode "
        f"(USD/episode, not combined with direct costs): "
        f"{outputs['patient_oop_cost_per_episode']:.2f}"
    )