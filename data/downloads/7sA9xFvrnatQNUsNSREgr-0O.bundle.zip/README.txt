================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 7sA9xFvrnatQNUsNSREgr-0O
    Generated   : 2026-10-09 00:24:05 UTC
================================================================

TITLE
-----
Lyme Disease Direct Health Care Cost Explorer (Claims-Based, 2016-2022)

BOUNDARY
--------
This simulator models only direct health care cost figures reported in a claims/EHR-based cohort study (Optum Market Clarity, 2016-2022, 2022 dollars). It does not add indirect costs (lost income, caregiving time), does not extend beyond the study's own 6-month or variable-length episode windows, and does not combine out-of-pocket costs with direct costs, per the study's own stated limitation that out-of-pocket amounts were not standardized. The episode-based cost method and the multivariable-adjusted 6-month method are kept as separate, non-interchangeable groups rather than pooled into one figure.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a retrospective cohort study using a large US claims/EHR dataset (Optum Market Clarity, 2016-2022) of 70,531 patients diagnosed with Lyme disease, comparing their health care costs to matched controls using four different analytic methods. It finds that Lyme disease is associated with substantial direct medical costs per episode ($2,227 average, much higher for disseminated disease at $6,833) and smaller but non-trivial patient out-of-pocket costs ($188 average). Using multiple methods, the study estimates Lyme disease adds roughly $3,300-$5,600 in all-cause 6-month health care costs compared to similar people without Lyme disease, and extrapolates this to $591 million-$1.05 billion in annual costs across high-incidence states (2022 dollars). The study explicitly does not address indirect costs (lost income, caregiving) or costs beyond 6 months.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could let payers/policy analysts explore how projected national or state-level Lyme disease cost burden changes under different assumed case counts or disease-severity mixes (localized vs disseminated vs indeterminate), using the study's own per-episode and per-patient cost inputs. Care delivery teams could use the localized-vs-disseminated cost gap (e.g., $695 vs $6,833 per episode) to motivate earlier diagnosis and treatment pathways aimed at preventing progression to disseminated disease. Patients/advocates could use the OOP cost ranges ($107-$401 per episode depending on disease stage) to set expectations for out-of-pocket exposure, while being reminded that these figures only reflect claims-insured populations and exclude indirect costs like lost income or caregiving time.

WHAT YOU COULD DO WITH IT
-------------------------
- Payers/policy users could adjust the extrapolation model's input case count (e.g., varying around the 476,000 estimated annual US cases or the 81% high-incidence-state share) to see how projected annual high-incidence-state cost burden shifts between the $591M-$1.05B range the study reports.
- Care delivery teams could compare projected per-patient direct cost burden across LD classification subgroups (localized $695 vs disseminated $6,833 per episode) to prioritize early detection and treatment investments aimed at preventing progression to disseminated disease.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 76 Lyme-related terms (for example, "Lyme", "borreliosis", "Borrelia"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Yu 2026 supplement.pdf
Yu 2026.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Localized disease direct cost per episode (USD/episode), default 695, source: Document Results 'LD Episode Analysis' and Table 2; 400-900 range is an assumed exploration bound, not from the source.
- Disseminated disease direct cost per episode (USD/episode), default 6833, source: Document Results 'LD Episode Analysis' and Table 2; 5000-9000 range is an assumed exploration bound, not from the source.
- Adjusted all-cause 6-month cost difference, overall (USD difference per patient (6 months)), default 5571, source: Document Results 'Multivariable Analysis' and Table 5; 3000-6000 range is an assumed exploration bound, not from the source.
- Adjusted all-cause 6-month cost difference, disseminated disease (USD difference per patient (6 months)), default 15834, source: Document Results 'Multivariable Analysis' and Table 5; 10000-20000 range is an assumed exploration bound, not from the source.
- Estimated annual U.S. Lyme disease cases (cited) (cases/year), default 476000, source: Document Results 'Extrapolation to High-Incidence States', p.10 and eTable 12, citing Kugeler et al. 2021; 300000-600000 range is an assumed exploration bound, not from the source.
- Share of U.S. cases in high-incidence states (fraction), default 0.81, source: Document Results 'Extrapolation to High-Incidence States', p.10 and eTable 12; 0.7-0.9 range is an assumed exploration bound, not from the source.
- Case-definition positive predictive value (cited) (fraction), default 0.766, source: Document Results 'Extrapolation to High-Incidence States', p.10 and eTable 12, citing Kluberg et al. 2025; 0.6-0.9 range is an assumed exploration bound, not from the source.
- Patient out-of-pocket cost per episode, overall (USD/episode), default 188, source: Document Results 'LD Episode Analysis' and Table 2; 100-400 range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- Disseminated minus localized direct cost per episode (positive = disseminated costs more): 6,138 (USD difference per episode) at default assumptions
- Disseminated divided by localized direct cost per episode: 9.83 (ratio) at default assumptions
- Adjusted disseminated minus adjusted overall 6-month cost difference (positive = disseminated patients' adjusted cost increase exceeds the overall average): 10,263 (USD difference per patient (6 months)) at default assumptions
- Estimated annual Lyme disease cases, high-incidence states: 295,339 (cases/year) at default assumptions
- Patient out-of-pocket cost per episode: 188 (USD/episode) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 722 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_d_lyme_antibiotics_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicaid_lyme_antibiotics_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_d_spending_by_drug_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicaid_spending_by_drug_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_b_ceftriaxone_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_b_spending_by_drug_2024.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Yu H et al. Lyme Disease and Health Care Costs. JAMA Netw Open. 2026
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41533379/
  DOI: https://doi.org/10.1001/jamanetworkopen.2025.52518

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.