================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : zN0DFP0HIPUM6_HemyDc8gq6
    Generated   : 2026-10-10 12:36:57 UTC
================================================================

TITLE
-----
Belgian Lyme Borreliosis Cost-of-Illness Explorer (Geebelen et al. 2022)

BOUNDARY
--------
This simulation reproduces the per-patient and national annual cost figures reported by a Belgian prospective cohort and hospital-registry cost-of-illness study of erythema migrans (EM, early Lyme rash) versus disseminated/late Lyme borreliosis (including post-treatment Lyme disease syndrome, PTLDS). All figures are in 2019 euros, societal perspective, Belgium only, and capture costs only up to 6 months post-diagnosis (12 months for PTLDS patients). It omits informal/unpaid caregiving value, pediatric-specific costs, non-reimbursed hospital supplements (single room, food, ambulance), tick-bite prophylaxis costs, and any costs beyond the study's follow-up window. It does not model other countries, other currencies, or longer time horizons.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed Belgian cost-of-illness study that estimates the yearly economic burden of Lyme borreliosis (LB) using a prospective patient cohort (HUMTICK) and national hospital registries. It separately values direct medical costs, direct non-medical costs (travel, paid help), and indirect productivity losses for patients with erythema migrans (EM, the early rash stage) versus disseminated/late LB, including those who developed post-treatment Lyme disease syndrome (PTLDS). The total annual national cost is estimated at about €5.59 million (2019 euros), with disseminated/late LB - though far less common than EM - accounting for 62% of that cost because its per-patient cost (€5,148) is about 26 times higher than EM's (€193). The study is explicit about what it could and could not capture: costs more than 6-12 months after diagnosis, pediatric costs, non-reimbursed hospital supplements, and PTLDS-specific costs (small sample) are flagged as incomplete or uncertain.

WHY THIS COULD BE USEFUL
------------------------
This Belgian cost-of-illness study provides concrete, societal-perspective direct and indirect cost figures for erythema migrans versus disseminated/late Lyme borreliosis (including PTLDS), broken out by cost category (ambulatory, hospital, travel, paid help, productivity loss) and by reimbursed versus patient-paid shares, all in 2019 euros. Public health and policy audiences could use these per-patient and national cost multipliers to build the economic case for interventions that shift diagnosis earlier (since disseminated/late LB costs ~26x more per patient despite being far less common than EM). Payers could use the reimbursed/non-reimbursed cost split to understand patient cost-sharing exposure. Patients and advocates could see the scale of direct and indirect costs borne even for a nominally 'mild' EM diagnosis versus a late-stage one. All figures are Belgium-specific (2019 EUR, societal perspective, 6-12 month follow-up window) and should not be transposed to other healthcare systems, currencies, or longer time horizons without an explicitly labeled adjustment.

WHAT YOU COULD DO WITH IT
-------------------------
- Public health/budget-policy teams could use the per-patient cost multiplier (EM €193 vs. disseminated/late LB €5,148) together with the study's own 2015-2017 incidence basis to model the national cost that could be averted by interventions shifting patients from late to early diagnosis (e.g., tick-bite prevention campaigns or a future prophylactic vaccine), as an explicitly labeled projection beyond what the document itself computed.
- Payers/policy analysts could use the 75.5%-reimbursed vs. patient-paid cost split, together with the itemized travel and paid-help figures, to illustrate the out-of-pocket burden patients face for EM versus disseminated/late LB - taking care not to add these patient-paid amounts on top of the already-inclusive total cost figures.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 81 Lyme-related terms (for example, "Lyme", "borreliosis", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Geebelen 2022.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Annual EM case count (cases/year), default 11168, source: Document p.7, Table 4 basis; value from crosscheck candidate (2015-2017 average incidence). The 5000-20000 range is an assumed exploration bound, not from the source.
- Annual disseminated/late LB case count (cases/year), default 673, source: Document p.7, Table 4 basis; value from crosscheck candidate (2015-2017 average incidence). The 100-2000 range is an assumed exploration bound, not from the source.
- Mean cost per EM patient (EUR), default 193, source: Document p.7, Results/Table 4. The 50-500 range is an assumed exploration bound, chosen to keep EM costs below disseminated/late LB costs as the document's own data show; not from the source.
- Mean cost per disseminated/late LB patient (EUR), default 5148, source: Document p.7, Results/Table 4. The 1000-10000 range is an assumed exploration bound, chosen to keep disseminated/late LB costs above EM costs as the document's own data show; not from the source.
- Share of direct medical costs reimbursed (fraction), default 0.755, source: Document p.7-8, Results/Discussion. The 0.5-0.95 range is an assumed exploration bound, not from the source.

OUTPUTS (4)
-----------
- Total annual national LB cost (EM + disseminated/late LB): 5,620,028 (EUR/year) at default assumptions
- Disseminated/late LB minus EM per-patient cost (positive = disseminated/late LB costs more; cannot be negative given these input ranges): 4,955 (EUR) at default assumptions
- Disseminated/late LB cost divided by EM cost (per patient): 26.67 (ratio) at default assumptions
- Direct medical cost share not reimbursed by insurance: 24.5 (%) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 371 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.json, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Geebelen L et al. Lyme borreliosis in Belgium: a cost-of-illness analysis. BMC Public Health. 2022
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36443755/
  DOI: https://doi.org/10.1186/s12889-022-14380-6

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.