def compute_outputs(em_case_count, disseminated_case_count,
                      em_cost_per_patient, disseminated_cost_per_patient,
                      reimbursed_share_direct_medical):
    total_annual_lb_cost = (em_case_count * em_cost_per_patient) + \
        (disseminated_case_count * disseminated_cost_per_patient)

    disseminated_vs_em_cost_gap = disseminated_cost_per_patient - em_cost_per_patient

    cost_ratio_disseminated_to_em = disseminated_cost_per_patient / em_cost_per_patient

    non_reimbursed_share_direct_medical = (1 - reimbursed_share_direct_medical) * 100

    return {
        "total_annual_lb_cost": total_annual_lb_cost,
        "disseminated_vs_em_cost_gap": disseminated_vs_em_cost_gap,
        "cost_ratio_disseminated_to_em": cost_ratio_disseminated_to_em,
        "non_reimbursed_share_direct_medical": non_reimbursed_share_direct_medical,
    }


DEFAULT_INPUTS = {
    "em_case_count": 11168,
    "disseminated_case_count": 673,
    "em_cost_per_patient": 193,
    "disseminated_cost_per_patient": 5148,
    "reimbursed_share_direct_medical": 0.755,
}

SCENARIOS = {
    "higher_disseminated_case_mix": {
        "em_case_count": 10657,
        "disseminated_case_count": 1184,
    },
    "lower_disseminated_case_mix": {
        "em_case_count": 11486,
        "disseminated_case_count": 355,
    },
    "atypical_low_incidence_year": {
        "em_case_count": 7000,
        "disseminated_case_count": 400,
    },
    "higher_incidence_year": {
        "em_case_count": 15000,
        "disseminated_case_count": 1200,
    },
    "full_reimbursement_policy": {
        "reimbursed_share_direct_medical": 0.95,
    },
    "minimal_reimbursement_policy": {
        "reimbursed_share_direct_medical": 0.5,
    },
}


def run_scenario(overrides):
    inputs = dict(DEFAULT_INPUTS)
    inputs.update(overrides)
    return compute_outputs(**inputs)


if __name__ == "__main__":
    print("=== Default inputs ===")
    for k, v in DEFAULT_INPUTS.items():
        print(f"{k}: {v}")

    print("\n=== Default outputs ===")
    default_outputs = compute_outputs(**DEFAULT_INPUTS)
    print(f"total_annual_lb_cost (EUR/year): {default_outputs['total_annual_lb_cost']:.2f}")
    print(f"disseminated_vs_em_cost_gap (EUR): {default_outputs['disseminated_vs_em_cost_gap']:.2f}")
    print(f"cost_ratio_disseminated_to_em (ratio): {default_outputs['cost_ratio_disseminated_to_em']:.4f}")
    print(f"non_reimbursed_share_direct_medical (%): {default_outputs['non_reimbursed_share_direct_medical']:.2f}")

    print("\n=== Scenarios ===")
    for name, overrides in SCENARIOS.items():
        outputs = run_scenario(overrides)
        print(f"\nScenario: {name}")
        print(f"  overrides: {overrides}")
        print(f"  total_annual_lb_cost (EUR/year): {outputs['total_annual_lb_cost']:.2f}")
        print(f"  disseminated_vs_em_cost_gap (EUR): {outputs['disseminated_vs_em_cost_gap']:.2f}")
        print(f"  cost_ratio_disseminated_to_em (ratio): {outputs['cost_ratio_disseminated_to_em']:.4f}")
        print(f"  non_reimbursed_share_direct_medical (%): {outputs['non_reimbursed_share_direct_medical']:.2f}")