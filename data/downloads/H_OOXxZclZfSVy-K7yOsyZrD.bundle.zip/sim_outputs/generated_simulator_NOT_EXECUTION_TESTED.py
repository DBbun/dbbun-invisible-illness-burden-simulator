#!/usr/bin/env python3
"""
Persistent Lyme Disease Trial Eligibility and Patient Burden Explorer (MyLymeData)

Reference implementation of the interactive spec. Standard library only.
Represents percentage-based findings from a 2022 MyLymeData patient-registry
survey. No dollar costs, caregiving time, or income-loss figures are included
because the source document reports none of these for either group.
"""

# ---------------------------------------------------------------------------
# Default inputs
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "pld_attrition_yield": 10,
    "pld_modeled_loosened_yield": 64,
    "pld_misdiagnosis_prevalence": 74,
    "ald_misdiagnosis_prevalence": 43,
    "pld_disability_status": 28,
    "ald_disability_status": 6,
    "pld_poor_health_status": 74,
    "ald_poor_health_status": 36,
}


# ---------------------------------------------------------------------------
# Output computations
# ---------------------------------------------------------------------------

def compute_outputs(inputs):
    """Compute all defined outputs from the given input dictionary."""

    eligibility_yield_gain = (
        inputs["pld_modeled_loosened_yield"] - inputs["pld_attrition_yield"]
    )

    excluded_share_pld = 100 - inputs["pld_attrition_yield"]

    misdiagnosis_prevalence_gap = (
        inputs["pld_misdiagnosis_prevalence"] - inputs["ald_misdiagnosis_prevalence"]
    )

    disability_status_gap = (
        inputs["pld_disability_status"] - inputs["ald_disability_status"]
    )

    poor_health_status_gap = (
        inputs["pld_poor_health_status"] - inputs["ald_poor_health_status"]
    )

    return {
        "eligibility_yield_gain": eligibility_yield_gain,
        "excluded_share_pld": excluded_share_pld,
        "misdiagnosis_prevalence_gap": misdiagnosis_prevalence_gap,
        "disability_status_gap": disability_status_gap,
        "poor_health_status_gap": poor_health_status_gap,
    }


# ---------------------------------------------------------------------------
# Scenario overrides (optional helper, not run automatically)
# ---------------------------------------------------------------------------

SCENARIOS = {
    "historical_trial_era_yield": {"pld_attrition_yield": 4},
    "max_loosened_eligibility_ceiling": {"pld_modeled_loosened_yield": 100},
}


def apply_scenario(base_inputs, scenario_id):
    """Return a new input dict with the named scenario's overrides applied."""
    new_inputs = dict(base_inputs)
    overrides = SCENARIOS.get(scenario_id, {})
    new_inputs.update(overrides)
    return new_inputs


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("Persistent Lyme Disease Trial Eligibility and Patient Burden Explorer")
    print("(MyLymeData) - reference calculation for default inputs")
    print()

    print("Inputs:")
    for key, value in inputs.items():
        print(f"  {key}: {value}%")

    print()
    print("Outputs:")
    print(
        "  eligibility_yield_gain (modeled loosened minus current PLD eligible "
        f"share): {outputs['eligibility_yield_gain']} percentage points"
    )
    print(
        "  excluded_share_pld (share of PLD Attrition Sample excluded under "
        f"current criteria): {outputs['excluded_share_pld']}%"
    )
    print(
        "  misdiagnosis_prevalence_gap (PLD minus ALD prior-misdiagnosis "
        f"prevalence): {outputs['misdiagnosis_prevalence_gap']} percentage points"
    )
    print(
        "  disability_status_gap (PLD minus ALD unable-to-work share): "
        f"{outputs['disability_status_gap']} percentage points"
    )
    print(
        "  poor_health_status_gap (PLD minus ALD fair/poor self-rated health "
        f"share): {outputs['poor_health_status_gap']} percentage points"
    )