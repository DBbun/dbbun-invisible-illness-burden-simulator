================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : H_OOXxZclZfSVy-K7yOsyZrD
    Generated   : 2026-10-05 21:16:10 UTC
================================================================

TITLE
-----
Persistent Lyme Disease Trial Eligibility and Patient Burden Explorer (MyLymeData)

BOUNDARY
--------
This simulation represents percentage-based findings from a 2022 MyLymeData patient-registry survey: how commonly used clinical trial eligibility rules shrink the pool of eligible persistent Lyme disease (PLD) patients, and how PLD differs from acute Lyme disease (ALD) in prior-misdiagnosis, disability, and self-rated-health prevalence. It omits all dollar costs, caregiving time, and income-loss figures because the source document reports none of these for either group.

ABOUT THE SOURCE DOCUMENT
-------------------------
This peer-reviewed study analyzes survey data from 4,183 U.S. Lyme disease patients in the MyLymeData registry (3,589 with persistent Lyme disease/PLD, 594 with acute Lyme disease/ALD) to measure how commonly used clinical trial eligibility criteria affect who gets included in research. It finds that typical eligibility rules (requiring CDC surveillance-definition confirmation, excluding patients with coinfections or a prior misdiagnosis of chronic fatigue syndrome, fibromyalgia, or a psychiatric condition) would exclude about 90% of real-world PLD patients, and that loosening the misdiagnosis- and coinfection-related exclusions could raise the eligible sample from 10% to 64%. The study also reports large differences between PLD and ALD patients in misdiagnosis rates, coinfection diagnoses, disability status, and self-rated health, and situates its findings against historical NIH-funded PLD trials that excluded 88-99% of applicants and took 2.5-4 years to recruit. The paper does not report any dollar-denominated medical costs, out-of-pocket costs, lost income, or caregiving-time figures; its burden evidence is expressed in enrollment/eligibility percentages and self-reported health/disability status.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could let clinical trial designers, patient advocates, and research funders explore how specific eligibility criteria (CDC surveillance-definition requirement, rash/Western-blot requirement, prior CFS/FMS or psychiatric misdiagnosis exclusion, coinfection exclusion) individually and cumulatively shrink the pool of real-world persistent Lyme disease patients eligible for a trial. Patients and advocates could use it to understand why so few people like them qualify for research, and why treatment guidance remains limited. Care delivery teams could use it to see how the trial-eligible population diverges from the community-treated population. Payers/policy audiences could use it to weigh how restrictive eligibility criteria drive up recruitment time and study cost, though this document supplies no dollar figures to quantify that trade-off directly.

WHAT YOU COULD DO WITH IT
-------------------------
- Let a user toggle individual eligibility criteria (surveillance-case definition, rash/Western-blot requirement, CFS/FMS or psychiatric misdiagnosis exclusion, coinfection exclusion) on or off and see the resulting projected PLD or ALD sample yield, based on this document's reported prevalence and attrition figures.
- Compare the demographic composition (sex, income, region per Table 1) of PLD versus ALD trial-eligible subgroups to flag where a proposed trial's screened population may not represent the underlying patient population.
- As a general trial/cohort-design consideration extending beyond what this document itself reports: because the study is about clinical trial eligibility and cohort composition, a simulator could prompt researchers to also screen for unmeasured cohort-level confounders (e.g., home environmental exposures) before attributing treatment-response variance solely to the intervention being studied - this is a general methodological extrapolation, not a finding in this document.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 79 Lyme-related terms (for example, "Lyme", "Borrelia", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2025.pdf

PARAMETERS (8)
--------------
- PLD current trial-eligible share (Attrition Sample) (%), default 10, source: Figure 2 and Section 3.2, p.6-7; 0-15 range is an assumed exploration bound, not from the source
- PLD modeled trial-eligible share if coinfection and misdiagnosis exclusions removed (%), default 64, source: Abstract; Section 5 (Recommendations), p.9-10; 20-100 range is an assumed exploration bound, not from the source
- PLD prior-misdiagnosis prevalence (%), default 74, source: Table 2, p.6; 55-95 range is an assumed exploration bound, not from the source
- ALD prior-misdiagnosis prevalence (%), default 43, source: Table 2, p.6; 10-45 range is an assumed exploration bound, not from the source
- PLD self-reported unable-to-work share (%), default 28, source: Table 2, p.6; 15-40 range is an assumed exploration bound, not from the source
- ALD self-reported unable-to-work share (%), default 6, source: Table 2, p.6; 0-14 range is an assumed exploration bound, not from the source
- PLD fair/poor self-rated health share (%), default 74, source: Table 2, p.6; 55-90 range is an assumed exploration bound, not from the source
- ALD fair/poor self-rated health share (%), default 36, source: Table 2, p.6; 15-50 range is an assumed exploration bound, not from the source

OUTPUTS (5)
-----------
- Modeled loosened PLD eligible share minus current PLD eligible share (positive = loosening coinfection/misdiagnosis exclusions would raise the eligible share; cannot be negative given this model's ranges): 54 (percentage points) at default assumptions
- Share of PLD Attrition Sample excluded under current eligibility criteria: 90 (%) at default assumptions
- PLD prior-misdiagnosis prevalence minus ALD prior-misdiagnosis prevalence (percentage points; positive = PLD respondents report prior misdiagnosis more often than ALD respondents, as found throughout this study's ranges): 31 (percentage points) at default assumptions
- PLD unable-to-work share minus ALD unable-to-work share (percentage points; positive = PLD respondents report being unable to work more often than ALD respondents, as found throughout this study's ranges): 22 (percentage points) at default assumptions
- PLD fair/poor self-rated health share minus ALD fair/poor self-rated health share (percentage points; positive = PLD respondents rate their health as fair/poor more often than ALD respondents, as found throughout this study's ranges): 38 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 384 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2022_2023__cdc_9mtj-y2ba.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Johnson L et al. Optimizing Exclusion Criteria for Clinical Trials of Persistent Lyme Disease Using Real-World Data. Healthcare (Basel). 2024
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39791627/
  DOI: https://doi.org/10.3390/healthcare13010020

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.