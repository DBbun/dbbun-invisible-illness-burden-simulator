DEFAULT_INPUTS = {
    "early_diagnosed_pld_rate": 20,
    "late_diagnosed_pld_rate": 77,
    "pld_misdiagnosis_rate": 74,
    "ald_misdiagnosis_rate": 42,
    "pld_annual_doctor_visits": 19.4,
    "general_pop_annual_doctor_visits": 1.09,
    "physicians_not_accepting_insurance_rate": 50,
    "adrion_annual_healthcare_cost": 1000000000,
}


def compute_outputs(inputs):
    outputs = {}

    outputs["pld_risk_gap_late_minus_early"] = (
        inputs["late_diagnosed_pld_rate"] - inputs["early_diagnosed_pld_rate"]
    )

    outputs["misdiagnosis_gap_pld_minus_ald"] = (
        inputs["pld_misdiagnosis_rate"] - inputs["ald_misdiagnosis_rate"]
    )

    outputs["doctor_visit_ratio"] = (
        inputs["pld_annual_doctor_visits"] / inputs["general_pop_annual_doctor_visits"]
    )

    outputs["insurance_access_barrier_rate"] = inputs[
        "physicians_not_accepting_insurance_rate"
    ]

    outputs["adrion_annual_healthcare_cost_output"] = inputs[
        "adrion_annual_healthcare_cost"
    ]

    return outputs


def compute_trajectory(inputs, periods=5):
    values = []
    prev = 0
    for _ in range(periods):
        prev = prev + inputs["pld_annual_doctor_visits"]
        values.append(prev)
    return values


OUTPUT_LABELS = {
    "pld_risk_gap_late_minus_early": (
        "Persistent-disease rate gap: late-diagnosed minus early-diagnosed patients "
        "(percentage points)"
    ),
    "misdiagnosis_gap_pld_minus_ald": (
        "Misdiagnosis-rate gap: persistent Lyme disease minus acute Lyme disease "
        "patients (percentage points)"
    ),
    "doctor_visit_ratio": (
        "Ratio of persistent Lyme disease patients' annual doctor visits to the "
        "general-population comparator (ratio)"
    ),
    "insurance_access_barrier_rate": (
        "Persistent Lyme disease patients reporting their physician does not accept "
        "insurance (percent)"
    ),
    "adrion_annual_healthcare_cost_output": (
        "Estimated annual U.S. healthcare cost tied to Lyme disease retreatment "
        "(claims-based, cited) (USD/year)"
    ),
}


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("=== MyLymeData Chartbook Reference Simulator ===")
    print()
    print("Default inputs:")
    for key, value in inputs.items():
        print(f"  {key}: {value}")

    print()
    print("Outputs:")
    for key, label in OUTPUT_LABELS.items():
        print(f"  {label}: {outputs[key]}")

    print()
    print(
        "Trajectory - Cumulative doctor visits per PLD patient "
        "(flat annual-rate assumption, not a growth projection):"
    )
    trajectory = compute_trajectory(inputs, periods=5)
    for year_index, cumulative_value in enumerate(trajectory, start=1):
        print(f"  Year {year_index}: {cumulative_value} visits/patient")