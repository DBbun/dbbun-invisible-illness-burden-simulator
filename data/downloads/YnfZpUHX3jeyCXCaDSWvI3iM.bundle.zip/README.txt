================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : YnfZpUHX3jeyCXCaDSWvI3iM
    Generated   : 2026-10-09 15:02:36 UTC
================================================================

TITLE
-----
MyLymeData Chartbook: Diagnosis Timing, Misdiagnosis, Access Barriers, and Utilization in Persistent Lyme Disease

BOUNDARY
--------
This simulator reproduces self-reported percentages and one externally cited aggregate cost figure from LymeDisease.org's MyLymeData 10-year chartbook, a patient-registry advocacy publication (not an independent economic burden-of-illness study). All diagnosis-timing, misdiagnosis, and utilization comparisons are associations observed within a self-selected, clinically-diagnosed patient registry; the document does not test whether earlier diagnosis causes lower persistent-disease risk, and the simulator does not add new causal claims. It omits dollar-denominated patient out-of-pocket costs, lifetime cost projections, and any breakdown by age, race/ethnicity, or disability status, because the source does not report these.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 10-year anniversary research chartbook from LymeDisease.org's MyLymeData patient registry (19,000+ self-enrolled, clinically diagnosed Lyme disease patients). It reports patient-reported rates of diagnostic delay, misdiagnosis, co-infections, treatment approaches, insurance and access barriers, clinician-reported practice burdens, quality-of-life decline, and healthcare utilization, focused mainly on 'persistent Lyme disease' (PLD) patients who remain ill 6+ months after treatment. It presents these largely as percentages from registry surveys rather than as dollar-denominated cost estimates, with one externally cited claims-based study estimating roughly $1 billion/year in U.S. healthcare costs tied to retreatment of diagnosed Lyme patients. The chartbook explicitly frames itself as advocacy/research-prioritization material produced by a patient organization, not an independent economic burden-of-illness study.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would let patients/advocates, care delivery teams, and payers/policy audiences explore how diagnostic timing, misdiagnosis, co-infection status, and insurance-network barriers relate to self-reported quality of life, disability, and healthcare utilization among persistent Lyme disease (PLD) patients. Because the document's own figures are overwhelmingly percentages from a self-selected patient registry rather than linked dollar costs, the simulator's main value is illustrating burden patterns (delay-to-PLD-risk, access barriers, utilization intensity) rather than producing validated total-cost estimates. Payers/policy users could use the access-barrier and insurance-non-acceptance findings to examine network-adequacy questions; care teams could use the co-infection and symptom-severity findings to inform diagnostic workup prioritization; patients/advocates could see how registry-reported experiences compare to general-population and other chronic-disease benchmarks.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients/advocates could use the registry's early-vs-late diagnosis PLD-progression rates (20% of early-diagnosed vs 77% of late-diagnosed patients developing PLD) to illustrate, qualitatively, why earlier diagnosis is emphasized by the patient community - without implying a validated causal estimate.
- Payers/policy analysts could examine the gap between PLD patients' reported care intensity (19.4 annual doctor visits, 3.7 annual ER visits) and the clinician-reported insurance-access barriers (50% of patients' physicians do not accept insurance; ~75% of surveyed Lyme-treating clinicians do not participate in insurance networks) to inform network-adequacy or reimbursement policy discussions.
- Care delivery teams could use the co-infection prevalence difference (33% in acute patients vs 75% in PLD patients) to evaluate whether earlier co-infection testing protocols might be warranted, consistent with the document's own hedged framing ('may be a primary driver').

DETECTED FOCUS
--------------
lyme: The uploaded material contains 140 Lyme-related terms (for example, "Lyme", "Tick-Borne", "borreliosis") and 1 Long COVID-related term (for example, "long COVID"). The 1 term(s) about the other condition are 0.7% of all matched terms, so they are treated as incidental and the document is classified as Lyme disease.

SOURCE FILES
------------
MyLymeData 2025 Chartbook.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Early-diagnosed patients who later report persistent Lyme disease (percent), default 20, source: MyLymeData chartbook page 17 ('roughly 20%'); 5-30 range is an assumed exploration bound, not from the source, chosen so it cannot exceed the late-diagnosed rate below
- Late-diagnosed (6+ months) patients who later report persistent Lyme disease (percent), default 77, source: MyLymeData chartbook page 17; 50-90 range is an assumed exploration bound, not from the source, chosen so it cannot fall below the early-diagnosed rate above
- Persistent Lyme disease patients misdiagnosed before their Lyme diagnosis (percent), default 74, source: MyLymeData chartbook page 7 and page 17; 60-90 range is an assumed exploration bound, not from the source, chosen so it cannot fall below the acute-patient rate below
- Acute Lyme disease patients misdiagnosed before their Lyme diagnosis (percent), default 42, source: MyLymeData chartbook page 17; 20-50 range is an assumed exploration bound, not from the source, chosen so it cannot exceed the persistent-disease rate above
- Annual doctor visits reported by persistent Lyme disease patients (visits/year), default 19.4, source: MyLymeData chartbook page 23, self-reported via MEPS-style survey items; 5-30 range is an assumed exploration bound, not from the source
- Annual doctor visits, U.S. general population (comparator) (visits/year), default 1.09, source: MyLymeData chartbook page 23 (cited general-population comparator); 0.5-3 range is an assumed exploration bound, not from the source
- Persistent Lyme disease patients whose physician does not accept insurance (percent), default 50, source: MyLymeData chartbook page 15; 20-70 range is an assumed exploration bound, not from the source
- Claims-based annual U.S. healthcare cost tied to Lyme disease retreatment (Adrion et al. 2015, cited) (USD/year), default 1000000000, source: MyLymeData chartbook page 23, citing Adrion et al. 2015 (external claims-based study, not MyLymeData's own estimate); 500,000,000-1,500,000,000 range is an assumed exploration bound, not from the source

OUTPUTS (5)
-----------
- Persistent-disease rate gap: late-diagnosed minus early-diagnosed patients (positive = later diagnosis associated with higher reported persistent-disease rate): 57 (percentage points) at default assumptions
- Misdiagnosis-rate gap: persistent Lyme disease minus acute Lyme disease patients (positive = persistent-disease group reports more pre-Lyme misdiagnosis): 32 (percentage points) at default assumptions
- Ratio of persistent Lyme disease patients' annual doctor visits to the general-population comparator: 17.8 (ratio) at default assumptions
- Persistent Lyme disease patients reporting their physician does not accept insurance: 50 (percent) at default assumptions
- Estimated annual U.S. healthcare cost tied to Lyme disease retreatment (claims-based, cited): 1,000,000,000 (USD/year) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 423 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2022_2023__cdc_9mtj-y2ba.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Johnson L. MyLymeData 2025 Research Chartbook (patient-registry report, LymeDisease.org). 2025
  Report (PDF, LymeDisease.org): https://www.lymedisease.org/assets/MLD-2025-chartbook.pdf
  MyLymeData research page: https://www.lymedisease.org/mylymedata-lyme-disease-research/

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.