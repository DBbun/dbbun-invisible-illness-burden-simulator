================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : CjUCzrJc0bKxwlR1FSiRqyqP
    Generated   : 2026-10-08 02:01:24 UTC
================================================================

TITLE
-----
Chronic Lyme Disease Symptom Burden: Patient-Reported Utilization, Cost, and Employment Impact (Johnson et al. 2014, PeerJ)

BOUNDARY
--------
This simulator reproduces patient-reported survey percentages from a 2014 self-selected internet survey of 3,090 people clinically diagnosed with Lyme disease whose symptoms persisted more than six months after antibiotic treatment ('chronic Lyme disease' / post-treatment Lyme disease syndrome), compared against general-population reference figures the authors cite from separate federal and published sources. It does not calculate a total dollar cost of illness, a lost-productivity dollar value, or caregiver burden - the study authors explicitly state these were out of scope. All figures describe a self-selected, non-representative convenience sample (82.6% female, mean age 48.2), not a population-representative estimate.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a 2014 PeerJ study by Johnson et al. that surveyed 3,090 self-selected online respondents clinically diagnosed with Lyme disease whose symptoms persisted more than six months after antibiotic treatment ('chronic Lyme disease,' CLD). Using the CDC's 9-item health-related quality of life (HRQoL) metric and self-reported healthcare-utilization and employment questions, the authors compared CLD patients to the general U.S. population and to patients with other chronic diseases (drawn from separately published studies). CLD respondents reported markedly worse self-rated health, more bad physical/mental health days, higher healthcare utilization (doctor visits, ER visits, hospital stays, home care), higher out-of-pocket costs, and substantially reduced ability to work compared with the general population. The study explicitly did not attempt to calculate total medical expenditures or a dollar value for lost productivity, and the sample is a self-selected, non-representative internet cohort, which the authors themselves flag as a key limitation.

WHY THIS COULD BE USEFUL
------------------------
A simulator built on this document could help patients/advocates and clinicians anticipate the relative scale of out-of-pocket costs, healthcare utilization, and work/employment impact associated with persistent post-treatment Lyme symptoms, benchmarked against general-population reference data the authors cite. Payers/policy audiences could use the utilization and out-of-pocket figures to motivate discussion of insurance coverage restrictions for extended Lyme treatment and the potential value of earlier diagnosis. Because the sample is a self-selected, non-representative internet cohort and the study explicitly did not calculate total medical expenditures or a productivity-loss dollar figure, any simulator must present these as patient-reported relative-burden indicators from a convenience sample, not as validated population-level cost estimates.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients/advocates could compare their own reported symptom burden, utilization pattern, or out-of-pocket spending against this cohort's reported ranges (e.g., 69% exceeding $2,000, 43-46% exceeding $5,000 out-of-pocket per year) to contextualize their own experience, with clear labeling that this is a non-representative patient-survey sample, not a population estimate.
- Policy/payer users could use the utilization-ratio findings (e.g., ~5x more doctor visits, ~6x more homecare visits than general population) alongside the document's note on restrictive insurer coverage of extended antibiotic therapy to inform discussion of coverage policy gaps for post-treatment Lyme disease syndrome, without treating the figures as a national cost total.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 70 Lyme-related terms (for example, "Lyme", "Borrelia", "Tick-Borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2014.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- CLD respondents with >$2,000/year out-of-pocket Lyme costs (percent), default 69, source: Observed value (69%) from p.11, survey administered in early 2013 describing the preceding year; 40-90 range is an assumed exploration bound chosen to preserve the document's reported ordering (CLD respondents reporting higher out-of-pocket spending than the general-population comparator), not from the source.
- General population with >$2,000/year out-of-pocket health costs (percent), default 20, source: Observed value (20%, including dental costs) from p.11, NHIS comparator; 5-35 range is an assumed exploration bound chosen so it cannot exceed the CLD input's 40-90 range, preserving the document's reported ordering, not from the source.
- CLD respondents' doctor visits per year (visits/year), default 19.4, source: Observed value (19.4 visits/year) from p.10, Fig.4; 10-30 range is an assumed exploration bound chosen to preserve the document's reported ordering versus the general-population comparator, not from the source.
- General population doctor visits per year (visits/year), default 3.7, source: Observed value (3.7 visits/year) from p.10, NAMCS/NHAMCS comparator; 1-8 range is an assumed exploration bound chosen so it cannot exceed the CLD input's 10-30 range, preserving the document's reported ordering, not from the source.
- CLD employment rate, ages 25-54 (percent), default 45.9, source: Observed value (45.9%) from p.11-12; 20-60 range is an assumed exploration bound chosen to preserve the document's reported ordering (lower CLD employment than the general-population comparator), not from the source.
- General population employment rate, ages 25-54 (percent), default 81.0, source: Observed value (81.0%) from p.11-12, BLS comparator (March 2013); 65-95 range is an assumed exploration bound chosen so it cannot fall below the CLD input's 20-60 range, preserving the document's reported ordering, not from the source.
- Not diagnosed within 2 years of symptom onset (percent), default 61.7, source: Observed value (61.7%) from p.3; 30-90 range is an assumed exploration bound for general sensitivity testing, not from the source.

OUTPUTS (4)
-----------
- CLD minus general-population share exceeding $2,000/year out-of-pocket (percentage points; positive = CLD share higher): 49 (percentage points) at default assumptions
- CLD-to-general-population annual doctor-visit ratio: 5.24 (ratio (CLD visits per general-population visit)) at default assumptions
- General population minus CLD employment rate, ages 25-54 (percentage points; positive = CLD employment lower): 35.1 (percentage points) at default assumptions
- Share of sample not diagnosed within 2 years of symptom onset: 61.7 (percent) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 384 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::548::SAGDP11_NY_1998_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson L et al. Severity of chronic Lyme disease compared to other chronic conditions: a quality of life survey. PeerJ. 2014
  PubMed: https://pubmed.ncbi.nlm.nih.gov/24749006/
  DOI: https://doi.org/10.7717/peerj.322

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.