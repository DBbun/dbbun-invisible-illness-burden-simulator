#!/usr/bin/env python3
"""
Reference implementation of: Chronic Lyme Disease Symptom Burden -
Patient-Reported Utilization, Cost, and Employment Impact
(Johnson et al. 2014, PeerJ)

Standard-library-only arithmetic reproduction of the interactive spec.
This reproduces only the arithmetic defined in the spec; it is not a
reproduction of the source paper's full statistical model.
"""

DEFAULT_INPUTS = {
    "cld_oop_over_2000_pct": 69,
    "genpop_oop_over_2000_pct": 20,
    "cld_doctor_visits_per_year": 19.4,
    "genpop_doctor_visits_per_year": 3.7,
    "cld_employment_rate_25_54": 45.9,
    "genpop_employment_rate_25_54": 81.0,
    "diagnostic_delay_2yr_pct": 61.7,
}


def compute_outputs(inputs):
    """Compute all spec outputs from a dict of input values."""
    oop_2000_gap_pct_points = (
        inputs["cld_oop_over_2000_pct"] - inputs["genpop_oop_over_2000_pct"]
    )

    doctor_visit_ratio = (
        inputs["cld_doctor_visits_per_year"] / inputs["genpop_doctor_visits_per_year"]
    )

    employment_gap_pct_points = (
        inputs["genpop_employment_rate_25_54"] - inputs["cld_employment_rate_25_54"]
    )

    diagnostic_delay_2yr_display = inputs["diagnostic_delay_2yr_pct"] * 1

    return {
        "oop_2000_gap_pct_points": oop_2000_gap_pct_points,
        "doctor_visit_ratio": doctor_visit_ratio,
        "employment_gap_pct_points": employment_gap_pct_points,
        "diagnostic_delay_2yr_display": diagnostic_delay_2yr_display,
    }


def compute_trajectory(annual_rate, periods=5):
    """Cumulative flat (non-growth) trajectory: add the same annual rate each period."""
    values = []
    prev = 0
    for _ in range(periods):
        prev = prev + annual_rate
        values.append(prev)
    return values


def run_scenario(base_inputs, overrides):
    scenario_inputs = dict(base_inputs)
    scenario_inputs.update(overrides)
    return compute_outputs(scenario_inputs)


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        print(f"{k}: {v}")

    print("\n=== Outputs ===")
    print(
        "oop_2000_gap_pct_points "
        f"(CLD minus general-population >$2,000/yr out-of-pocket share, pct points): "
        f"{outputs['oop_2000_gap_pct_points']}"
    )
    print(
        "doctor_visit_ratio "
        f"(CLD-to-general-population annual doctor-visit ratio): "
        f"{outputs['doctor_visit_ratio']}"
    )
    print(
        "employment_gap_pct_points "
        f"(general population minus CLD employment rate, ages 25-54, pct points): "
        f"{outputs['employment_gap_pct_points']}"
    )
    print(
        "diagnostic_delay_2yr_display "
        f"(share of sample not diagnosed within 2 years of symptom onset, pct): "
        f"{outputs['diagnostic_delay_2yr_display']}"
    )

    print("\n=== Scenario: entire_adult_sample_employment ===")
    scenario_overrides = {"cld_employment_rate_25_54": 42.1}
    scenario_outputs = run_scenario(inputs, scenario_overrides)
    print(
        "employment_gap_pct_points (entire adult sample): "
        f"{scenario_outputs['employment_gap_pct_points']}"
    )

    print("\n=== Trajectory: cumulative_cld_doctor_visits (5 years, flat annual rate) ===")
    cld_traj = compute_trajectory(inputs["cld_doctor_visits_per_year"], periods=5)
    for year, val in enumerate(cld_traj, start=1):
        print(f"year {year}: {val}")

    print("\n=== Trajectory: cumulative_genpop_doctor_visits (5 years, flat annual rate) ===")
    genpop_traj = compute_trajectory(inputs["genpop_doctor_visits_per_year"], periods=5)
    for year, val in enumerate(genpop_traj, start=1):
        print(f"year {year}: {val}")