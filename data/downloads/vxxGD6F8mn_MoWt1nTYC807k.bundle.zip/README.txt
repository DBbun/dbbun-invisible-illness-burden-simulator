================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : vxxGD6F8mn_MoWt1nTYC807k
    Generated   : 2026-10-10 18:13:19 UTC
================================================================

TITLE
-----
Long COVID Quality-of-Life Burden Simulator (OpenPROMPT UK Cohort)

BOUNDARY
--------
This simulation reproduces health-related quality-of-life (HRQoL) and quality-adjusted life-month (QALM) findings from a UK cohort study (OpenPROMPT, N=6,070 adults, surveys linked to NHS records, late 2022-mid 2023, 0-3 month follow-up) comparing people who self-reported long COVID to those who did not. It does NOT contain any direct medical cost, non-medical cost, income-loss, or productivity figures - the source study reports none of its own. It cannot answer insurance, billing, or total-national-cost questions. All quality-of-life figures are specific to this self-selected smartphone-app cohort over a short follow-up window and should not be extrapolated to a full year or a lifetime without labeling that as an added assumption.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a UK cohort study (OpenPROMPT, published in The Lancet Regional Health - Europe, 2024) that linked smartphone-collected patient-reported outcome surveys to NHS electronic health records for 6,070 adults to measure how long COVID affects health-related quality of life (HRQoL) using the EQ-5D-5L questionnaire. It found that people who self-reported long COVID had substantially worse quality of life than those who did not, translating into measurable losses of quality-adjusted life-months (QALMs), and that these HRQoL scores were comparable to or worse than those reported elsewhere for heart failure, multiple sclerosis and end-stage renal disease. It also found a large gap between how many people self-reported long COVID (24.6%) and how many had a corresponding diagnosis code in their medical record (under 10%), highlighting a measurement and recognition gap. The study reports no direct medical costs, non-medical costs, or lost-income/productivity figures of its own; it discusses potential workforce and health-service cost implications only qualitatively and by citing other papers.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help clinicians, long COVID researchers, and UK/NHS-style health-service planners understand the magnitude of quality-of-life loss associated with self-reported long COVID relative to other chronic conditions (heart failure, MS, renal disease) using standardized EQ-5D/QALM metrics, and could illustrate the sizeable gap between patient-reported long COVID and what administrative diagnosis codes capture. It would NOT be able to answer direct cost, insurance, or income-loss questions, since this document reports no monetary figures of its own.

WHAT YOU COULD DO WITH IT
-------------------------
- Let a user compare the reported EQ-5D utility/QALM loss for self-reported long COVID against the document's cited comparator conditions (heart failure, multiple sclerosis, end-stage renal disease, COPD) to illustrate relative severity for health-service prioritization discussions - clearly labeling that the comparator values are drawn from other, separately cited studies rather than measured in this cohort.
- Let a user explore the documented gap between self-reported long COVID prevalence (24.6%) and EHR/diagnosis-code-recorded long COVID (6%) in this UK cohort, to inform discussion of surveillance and clinical-recognition gaps - without implying this gap quantifies the 'true' prevalence of long COVID.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 129 Long COVID-related terms (for example, "long COVID", "post COVID", "post-COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Carlile 2024.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Complete-case QALM loss, self-reported long COVID (QALMs (quality-adjusted life-months lost)), default 0.81, source: Results, 'Individual QALM losses' (p.9); Table 2 (p.12) - complete-case survey completers, N=510
- Complete-case QALM loss, non-long COVID (QALMs (quality-adjusted life-months lost)), default 0.44, source: Results, 'Individual QALM losses' (p.9); Table 2 (p.12) - complete-case survey completers, N=510
- Mean EQ-5D-5L utility score, self-reported long COVID (utility points (0-1 scale, 1 = full health)), default 0.49, source: Discussion, first paragraph (p.9)
- Mean EQ-5D-5L utility score, non-long COVID (utility points (0-1 scale, 1 = full health)), default 0.71, source: Discussion, first paragraph (p.9)
- Self-reported long COVID (percent of cohort) (percent), default 24.6, source: Results, 'Descriptive analysis', Table 1 (pp.6-7); Discussion (p.9)
- EHR-recorded long COVID diagnosis (percent of cohort) (percent), default 6, source: Results, 'Descriptive analysis', Table 1 (pp.6-7); Discussion (p.9)
- Odds ratio for HRQoL loss, unadjusted (odds ratio), default 4.7, source: Abstract (p.1); Results, 'Health-related quality-of-life' (p.7)
- Odds ratio for HRQoL loss, adjusted for fatigue/breathlessness (odds ratio), default 1.46, source: Results, PROMs model section (p.8)

OUTPUTS (4)
-----------
- Complete-case QALM loss difference, long COVID minus non-long COVID (positive = long COVID group had greater measured quality-adjusted life-month loss): 0.37 (QALMs lost) at default assumptions
- EQ-5D-5L utility score, long COVID minus non-long COVID (negative = lower quality of life among those reporting long COVID): -0.22 (utility points (0-1 scale)) at default assumptions
- Self-reported long COVID percent minus EHR-diagnosis-coded percent (positive = more people self-reported long COVID than had a diagnosis code on record): 18.6 (percentage points) at default assumptions
- Unadjusted minus PROMs-adjusted odds ratio for HRQoL loss (positive = odds ratio shrank after adjusting for fatigue and breathlessness scores): 3.24 (odds ratio points (difference in odds ratios)) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::310::SAGDP6_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle06_PUF_CSV.zip::0::hps_04_01_06_puf.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week52_PUF_CSV.zip::1::pulse2022_puf_52.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle04_PUF_CSV.zip::0::hps_04_01_04_puf.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week54_PUF_CSV.zip::1::pulse2023_puf_54.csv, scope: long_covid)

ORIGINAL SOURCE
---------------
Carlile O et al. Impact of long COVID on health-related quality-of-life: an OpenSAFELY population cohort study using patient-reported outcome measures (OpenPROMPT). Lancet Reg Health Eur. 2024
  PubMed: https://pubmed.ncbi.nlm.nih.gov/38689605/
  DOI: https://doi.org/10.1016/j.lanepe.2024.100908

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.