#!/usr/bin/env python3
"""
Long COVID Quality-of-Life Burden Simulator (OpenPROMPT UK Cohort)
Reference implementation - standard library only.

This reproduces specific HRQoL/QALM figures reported in a UK cohort study
(OpenPROMPT, N=6,070). It does NOT contain cost, income, or productivity
data. All outputs are specific to this self-selected cohort over a 0-3
month follow-up window; no extrapolation to a full year or lifetime is
performed here.
"""

DEFAULT_INPUTS = {
    "qalm_loss_long_covid": 0.81,
    "qalm_loss_non_long_covid": 0.44,
    "eq5d_long_covid": 0.49,
    "eq5d_non_long_covid": 0.71,
    "self_report_long_covid_percent": 24.6,
    "ehr_diagnosis_percent": 6,
    "odds_ratio_unadjusted": 4.7,
    "odds_ratio_adjusted": 1.46,
}

SCENARIOS = {
    "widest_qalm_gap": {
        "qalm_loss_long_covid": 1.0,
        "qalm_loss_non_long_covid": 0.2,
    },
    "narrowest_qalm_gap": {
        "qalm_loss_long_covid": 0.5,
        "qalm_loss_non_long_covid": 0.49,
    },
    "widest_utility_gap": {
        "eq5d_long_covid": 0.3,
        "eq5d_non_long_covid": 0.9,
    },
    "diagnosis_gap_upper_bound": {
        "ehr_diagnosis_percent": 10,
    },
    "wider_self_report_gap": {
        "self_report_long_covid_percent": 35,
    },
    "full_attenuation_to_null": {
        "odds_ratio_adjusted": 1.0,
    },
    "weak_attenuation_upper_bound": {
        "odds_ratio_adjusted": 2.5,
    },
}


def compute_outputs(inputs):
    """Compute all output expressions from a given input dict."""
    qalm_loss_difference = (
        inputs["qalm_loss_long_covid"] - inputs["qalm_loss_non_long_covid"]
    )
    eq5d_utility_gap = (
        inputs["eq5d_long_covid"] - inputs["eq5d_non_long_covid"]
    )
    self_report_vs_diagnosis_gap = (
        inputs["self_report_long_covid_percent"] - inputs["ehr_diagnosis_percent"]
    )
    odds_ratio_attenuation = (
        inputs["odds_ratio_unadjusted"] - inputs["odds_ratio_adjusted"]
    )
    return {
        "qalm_loss_difference": qalm_loss_difference,
        "eq5d_utility_gap": eq5d_utility_gap,
        "self_report_vs_diagnosis_gap": self_report_vs_diagnosis_gap,
        "odds_ratio_attenuation": odds_ratio_attenuation,
    }


def run_scenario(base_inputs, overrides):
    """Apply overrides on top of base inputs and compute outputs."""
    merged = dict(base_inputs)
    merged.update(overrides)
    return merged, compute_outputs(merged)


def print_outputs(inputs, outputs):
    print(f"  qalm_loss_long_covid              = {inputs['qalm_loss_long_covid']}")
    print(f"  qalm_loss_non_long_covid           = {inputs['qalm_loss_non_long_covid']}")
    print(f"  eq5d_long_covid                    = {inputs['eq5d_long_covid']}")
    print(f"  eq5d_non_long_covid                = {inputs['eq5d_non_long_covid']}")
    print(f"  self_report_long_covid_percent     = {inputs['self_report_long_covid_percent']}")
    print(f"  ehr_diagnosis_percent              = {inputs['ehr_diagnosis_percent']}")
    print(f"  odds_ratio_unadjusted              = {inputs['odds_ratio_unadjusted']}")
    print(f"  odds_ratio_adjusted                = {inputs['odds_ratio_adjusted']}")
    print(f"  -> qalm_loss_difference            = {outputs['qalm_loss_difference']:.4f}")
    print(f"  -> eq5d_utility_gap                 = {outputs['eq5d_utility_gap']:.4f}")
    print(f"  -> self_report_vs_diagnosis_gap    = {outputs['self_report_vs_diagnosis_gap']:.4f}")
    print(f"  -> odds_ratio_attenuation          = {outputs['odds_ratio_attenuation']:.4f}")


if __name__ == "__main__":
    print("=== Default inputs ===")
    default_outputs = compute_outputs(DEFAULT_INPUTS)
    print_outputs(DEFAULT_INPUTS, default_outputs)

    for scenario_id, overrides in SCENARIOS.items():
        print(f"\n=== Scenario: {scenario_id} ===")
        merged_inputs, outputs = run_scenario(DEFAULT_INPUTS, overrides)
        print_outputs(merged_inputs, outputs)