#!/usr/bin/env python3
"""
Reference implementation of the "Long COVID and Financial Hardship Risk
(2022 BRFSS)" interactive spec.

This script is a plain arithmetic reference implementation only. It models
associations (average marginal effects, in percentage points) reported in a
single cross-sectional 2022 BRFSS survey between self-reported long COVID
and three financial-hardship outcomes. It does not include dollar costs,
direct medical spending, or time trends, and cannot establish whether
hardship preceded or followed long COVID onset. Income- and education-group
estimates come from overlapping respondents, not independent populations,
and should not be summed across stratification types.

Standard library only. No synthetic patients, no sampling, no plotting,
no CLI.
"""

# ----------------------------------------------------------------------
# Default inputs (all editable in spirit, hardcoded here as defaults)
# ----------------------------------------------------------------------

DEFAULT_INPUTS = {
    "ame_food_insecurity_income": 4,
    "ame_bills_income": 5,
    "ame_utility_threat_income": 4,
    "ame_food_insecurity_education": 3,
    "ame_bills_education": 5,
    "ame_utility_threat_education": 3,
    "employment_mediation_share": 13,
}


def compute_income_hardship_sum(inputs):
    """Sum of the three income-stratified hardship AMEs (pp).
    Illustrative additive total only; not a true joint probability since
    the three outcomes are not mutually exclusive."""
    return (
        inputs["ame_food_insecurity_income"]
        + inputs["ame_bills_income"]
        + inputs["ame_utility_threat_income"]
    )


def compute_education_hardship_sum(inputs):
    """Sum of the three education-stratified hardship AMEs (pp).
    Illustrative additive total only; not a true joint probability since
    the three outcomes are not mutually exclusive."""
    return (
        inputs["ame_food_insecurity_education"]
        + inputs["ame_bills_education"]
        + inputs["ame_utility_threat_education"]
    )


def compute_employment_attributable_bills_pp(inputs):
    """Portion of income-group bill-payment AME (pp) attributed to lost
    or reduced work hours, per the assumed employment-mediation share."""
    return inputs["ame_bills_income"] * (
        inputs["employment_mediation_share"] / 100
    )


def compute_income_education_bills_gap(inputs):
    """Income-group minus education-group bill-payment AME (pp).
    Positive = income-based estimate larger; negative = education-based
    estimate larger. Both estimates come from overlapping respondents."""
    return inputs["ame_bills_income"] - inputs["ame_bills_education"]


def run(inputs=None):
    """Compute all outputs for a given (or default) set of inputs."""
    if inputs is None:
        inputs = dict(DEFAULT_INPUTS)
    else:
        merged = dict(DEFAULT_INPUTS)
        merged.update(inputs)
        inputs = merged

    outputs = {
        "income_hardship_sum": compute_income_hardship_sum(inputs),
        "education_hardship_sum": compute_education_hardship_sum(inputs),
        "employment_attributable_bills_pp": compute_employment_attributable_bills_pp(
            inputs
        ),
        "income_education_bills_gap": compute_income_education_bills_gap(
            inputs
        ),
    }
    return inputs, outputs


if __name__ == "__main__":
    inputs, outputs = run()

    print("Long COVID and Financial Hardship Risk (2022 BRFSS)")
    print("=" * 55)
    print("\nInputs (defaults):")
    for k, v in inputs.items():
        print(f"  {k}: {v}")

    print("\nOutputs:")
    print(
        "  income_hardship_sum (pp): "
        f"{outputs['income_hardship_sum']}"
    )
    print(
        "  education_hardship_sum (pp): "
        f"{outputs['education_hardship_sum']}"
    )
    print(
        "  employment_attributable_bills_pp (pp): "
        f"{outputs['employment_attributable_bills_pp']}"
    )
    print(
        "  income_education_bills_gap (pp): "
        f"{outputs['income_education_bills_gap']}"
    )

    print(
        "\nNote: These are illustrative additive combinations of "
        "non-mutually-exclusive AMEs from a single cross-sectional "
        "survey, not joint probabilities or causal estimates."
    )