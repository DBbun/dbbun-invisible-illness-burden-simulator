================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 46HWolqpfKfxmDjYl5vSdF_v
    Generated   : 2026-10-09 15:03:02 UTC
================================================================

TITLE
-----
Long COVID and Financial Hardship Risk (2022 BRFSS)

BOUNDARY
--------
This simulator models associations reported in a single cross-sectional 2022 BRFSS survey (271,076 US adults, 40 states + DC) between self-reported long COVID (CDC-based definition, symptoms ≥3 months) and three financial-hardship outcomes: food insecurity, inability to pay bills, and being threatened with loss of utility service. All values are average marginal effects (AMEs) in percentage points - the modeled increase in the probability of each hardship outcome associated with long COVID, within income or education subgroups. It does not include any dollar costs, direct medical spending, or time trends; the data cannot establish whether hardship preceded or followed long COVID onset. Income-group and education-group estimates come from overlapping respondents, not independent populations, so they should not be summed across the two stratification types.

ABOUT THE SOURCE DOCUMENT
-------------------------
This peer-reviewed research brief uses 2022 BRFSS survey data on 271,076 US adults (age 18+, 40 states plus DC) to ask whether long COVID is associated with financial hardship - specifically food insecurity, inability to pay bills, and threat of losing utility service - and whether this association differs by income and education level. It finds that long COVID was linked to a higher probability of experiencing these hardships across nearly all income and education groups, with the effect generally strongest for the lowest-income households. A meaningful but partial share of this association (roughly 6%-20%, varying by hardship type and subgroup) was explained by lost employment or reduced work hours. The study does not measure direct medical costs, out-of-pocket spending, or dollar amounts of any kind - its burden measures are all probabilities of experiencing a hardship event, not expenditures.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could let policy analysts, payers, and patient-advocacy groups explore how the probability of food insecurity, bill non-payment, or utility shut-off threat rises for a person with long COVID, stratified by income-to-poverty ratio or education level, and how much of that rise traces to lost or reduced work hours. It is useful for prioritizing income-targeted assistance programs and for framing conversations with patients about financial-hardship risk, but it cannot answer any question involving direct medical costs, dollar amounts, or time horizons beyond a single 2022 cross-sectional snapshot.

WHAT YOU COULD DO WITH IT
-------------------------
- Policy analysts could use the income/education-stratified AME estimates to identify which socioeconomic subgroups face the largest percentage-point increase in financial-hardship risk from long COVID, to prioritize targeted assistance programs (e.g., for households with income-to-poverty ratio <2.00).
- Clinical social workers or patient navigators could use the subgroup-specific probability increases (not dollar costs) to flag which long COVID patients - by income or education level - are at elevated risk of food insecurity or utility shutoff and may benefit from referral to financial-assistance or flexible-work resources.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 80 Long COVID-related terms (for example, "Long COVID", "post-COVID", "long-covid"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Datta 2024.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- Food insecurity AME, pooled across income groups (percentage points), default 4, source: Results, p.6; Appendix S1 Figures A2-A7 (pooled meta-summary AME, 95% CI 0.01-0.07 pp); 1-7 range reflects the document's own reported confidence interval, not an assumed bound
- Inability-to-pay-bills AME, pooled across income groups (percentage points), default 5, source: Results, p.6; Appendix S1 Figures A2-A7 (pooled meta-summary AME, 95% CI 2-8 pp)
- Utility-shutoff-threat AME, pooled across income groups (percentage points), default 4, source: Results, p.6; Appendix S1 Figures A2-A7 (pooled meta-summary AME, 95% CI 1-6 pp)
- Food insecurity AME, pooled across education groups (percentage points), default 3, source: Results, p.6; Appendix S1 Figures A2-A7 (pooled meta-summary AME, 95% CI 3-4 pp)
- Inability-to-pay-bills AME, pooled across education groups (percentage points), default 5, source: Results, p.6; Appendix S1 Figures A2-A7 (pooled meta-summary AME, 95% CI 4-6 pp)
- Utility-shutoff-threat AME, pooled across education groups (percentage points), default 3, source: Results, p.6; Appendix S1 Figures A2-A7 (pooled meta-summary AME, 95% CI 2-4 pp)
- Share of hardship association attributed to lost/reduced work hours (percent), default 13, source: Abstract, p.1; Discussion, p.7 - document reports an overall range of 6%-20% across hardship types and subgroups, not a single point estimate; default of 13 is the assumed midpoint of that reported range, chosen by us for exploration

OUTPUTS (4)
-----------
- Combined hardship-probability increase, income groups (sum of three outcomes): 13 (percentage points) at default assumptions
- Combined hardship-probability increase, education groups (sum of three outcomes): 11 (percentage points) at default assumptions
- Portion of bill-payment-hardship increase (income groups) linked to lost work hours: 0.65 (percentage points) at default assumptions
- Income-group minus education-group bill-payment AME (positive = income-based estimate larger; negative = education-based estimate larger): 0 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::521::SAGDP11_GA_1998_2025.csv, scope: general)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::14::CAEMP25N_GA_2001_2022.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::436::SAGDP8_US_1997_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::247::SAGDP5_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/CAINC1.zip::47::CAINC1_US_1969_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::373::SAGDP7_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Datta BK et al. Long COVID and financial hardship: A disaggregated analysis at income and education levels. Health Serv Res. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/39618261/
  DOI: https://doi.org/10.1111/1475-6773.14413

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.