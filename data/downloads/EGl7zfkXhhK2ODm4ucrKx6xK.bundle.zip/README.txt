================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : EGl7zfkXhhK2ODm4ucrKx6xK
    Generated   : 2026-10-05 20:15:06 UTC
================================================================

TITLE
-----
Long COVID (PASC) Prevalence and Chronic-Conversion Simulator

BOUNDARY
--------
This simulation represents prevalence, chronic-conversion, and surveillance-gap findings from a single 58-hospital, 4-region EHR cohort study (457,950 COVID-19 patients, 2017-2025) using an AI phenotyping algorithm (P2RC). It omits all direct medical costs, out-of-pocket spending, lost income, caregiver time, and health care utilization, none of which this document measures in its own cohort (those figures only appear as external citations for context). The national extrapolation output is explicitly flagged by the study authors as needing cautious interpretation, not a validated count.

ABOUT THE SOURCE DOCUMENT
-------------------------
This JAMA Network Open study used an AI phenotyping algorithm (P2RC) on electronic health record data from 58 hospitals in 4 US regions (2017-2025) to estimate how many COVID-19 patients actually develop Long COVID (PASC), compared with how many are captured by standard diagnostic codes. Among 457,950 COVID-19 patients, the algorithm identified PASC in 16.28% overall (ranging 13.64%-22.69% by region), more than double the <7% typically found using code-based surveillance. Of those with PASC, 89.31% had developed a chronic condition requiring ongoing management, equal to 14.54% of all COVID-19 patients in the cohort, and PASC prevalence was still increasing (not resolving) through mid-2024 in three of the four regions. The study reports no direct dollar costs, out-of-pocket spending, lost income, or caregiver-time figures of its own; it cites other studies' cost/utilization estimates for context only.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help health system planners and payers anticipate that the true chronic-disease burden following COVID-19 is likely several times larger than what their own diagnosis-code-based records show, informing capacity planning, reimbursement model design, and surveillance infrastructure investment decisions. Clinicians and care-delivery teams could use the regional organ-system heterogeneity findings (e.g., thyroid-predominant vs. metabolic-predominant patterns) to anticipate which specialty services may see increased demand in their region. Patient advocates could use the 89.31% chronic-conversion finding to support framing Long COVID as a sustained chronic-disease burden rather than a self-limiting illness when engaging policymakers or disability programs. The document provides no cost, income-loss, or out-of-pocket figures, so it cannot by itself answer financial 'what-if' questions for patients - it is primarily a burden-sizing and surveillance-gap resource standing alongside (not a substitute for) cost or productivity data.

WHAT YOU COULD DO WITH IT
-------------------------
- Health system or payer planners could use the >2-fold gap between phenotyping-identified PASC prevalence (16.28%) and code-based surveillance (<7%) to model how much under-recognized chronic-care demand and capacity/reimbursement adjustment may be needed beyond what current coded caseloads suggest.
- Care-delivery teams could use the region-specific organ-system heterogeneity findings (e.g., New England's thyroid-predominant endocrine pattern vs. metabolic-predominant patterns elsewhere) to anticipate which specialty clinics may face rising, uncoordinated referral volumes from unlabeled post-COVID chronic conditions.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 132 Long COVID-related terms (for example, "Long COVID", "PASC", "U09.9"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Tian 2026 surveillance gaps.pdf

PARAMETERS (6)
--------------
- Overall PASC prevalence (AI phenotyping) (% of COVID-19 patients), default 16.28, source: Abstract/Results 'PASC Prevalence', p.4; range set to the study's own reported 4-region range (13.64%-22.69%, Table 1, p.5)
- Code-based PASC surveillance estimate (external comparator) (% of COVID-19 survivors), default 7, source: Abstract, p.1; Discussion, p.8 (cited from external claims/ICD-10-code studies, refs 16-17, not measured in this cohort); 3-7 range is an assumed exploration bound, not from the source
- Share of PASC patients with a chronic condition (% of PASC patients), default 89.31, source: Abstract; Results 'Chronic Disease Burden', p.6; Table 2; 80-95 range is an assumed exploration bound around the reported 89.31% figure, not from the source
- PASC prevalence - Southern California region (% of COVID-19 patients), default 22.69, source: Table 1, p.5; Results 'PASC Prevalence', p.4; range set to the study's own reported 4-region range
- PASC prevalence - Western Pennsylvania region (% of COVID-19 patients), default 13.64, source: Table 1, p.5; Results 'PASC Prevalence', p.4; range set to the study's own reported 4-region range
- US documented COVID-19 case count (external CDC figure) (individuals), default 103000000, source: Discussion, p.7-8 (external CDC national case count cited by the authors, not from this study's cohort); 50-150 million range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Phenotyping-identified prevalence minus code-based surveillance estimate (positive = AI phenotyping found more PASC than code-based surveillance; negative = code-based surveillance found more): 9.28 (percentage points) at default assumptions
- Chronic PASC prevalence as a share of all COVID-19 patients: 14.5397 (% of all COVID-19 patients) at default assumptions
- Southern California prevalence minus Western Pennsylvania prevalence (positive = Southern California higher; negative = Western Pennsylvania higher): 9.05 (percentage points) at default assumptions
- Illustrative national extrapolation of chronic PASC individuals: 1.49759e+07 (individuals) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 490 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::4::Code Descriptions/icd10cm_order_2026.txt, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::1::Code Descriptions/icd10cmCodesFile.pdf, scope: both)

ORIGINAL SOURCE
---------------
Tian et al. Long COVID Persistence and Surveillance Gaps Across 58 US Hospitals. JAMA Netw Open. 2026;9(5):e2614909
  PubMed: https://pubmed.ncbi.nlm.nih.gov/42201733/
  DOI: https://doi.org/10.1001/jamanetworkopen.2026.14909

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.