#!/usr/bin/env python3
"""
Long COVID (PASC) Prevalence and Chronic-Conversion Simulator
Reference implementation (standard library only).

This script implements the arithmetic specified in the simulator spec,
using the same default inputs and the same output expressions.
"""

# ----------------------------
# Default inputs
# ----------------------------

DEFAULT_INPUTS = {
    "overall_pasc_prevalence": 16.28,          # % of COVID-19 patients
    "code_based_surveillance_estimate": 7,      # % of COVID-19 survivors
    "chronic_conversion_rate": 89.31,           # % of PASC patients
    "southern_california_prevalence": 22.69,    # % of COVID-19 patients
    "western_pennsylvania_prevalence": 13.64,   # % of COVID-19 patients
    "us_covid_case_count_cdc": 103000000,       # individuals
}


# ----------------------------
# Output computations
# ----------------------------

def compute_surveillance_gap_percentage_points(inputs):
    """Phenotyping-identified prevalence minus code-based surveillance estimate."""
    return inputs["overall_pasc_prevalence"] - inputs["code_based_surveillance_estimate"]


def compute_chronic_pasc_share_of_all_covid(inputs):
    """Chronic PASC prevalence as a share of all COVID-19 patients."""
    return (inputs["overall_pasc_prevalence"] * inputs["chronic_conversion_rate"]) / 100


def compute_regional_prevalence_gap(inputs):
    """Southern California prevalence minus Western Pennsylvania prevalence."""
    return inputs["southern_california_prevalence"] - inputs["western_pennsylvania_prevalence"]


def compute_national_chronic_pasc_extrapolation(inputs):
    """Illustrative national extrapolation of chronic PASC individuals."""
    chronic_pasc_share_of_all_covid = compute_chronic_pasc_share_of_all_covid(inputs)
    return (chronic_pasc_share_of_all_covid / 100) * inputs["us_covid_case_count_cdc"]


def compute_all_outputs(inputs):
    """Compute all outputs for a given input dictionary."""
    outputs = {}
    outputs["surveillance_gap_percentage_points"] = compute_surveillance_gap_percentage_points(inputs)
    outputs["chronic_pasc_share_of_all_covid"] = compute_chronic_pasc_share_of_all_covid(inputs)
    outputs["regional_prevalence_gap"] = compute_regional_prevalence_gap(inputs)
    outputs["national_chronic_pasc_extrapolation"] = compute_national_chronic_pasc_extrapolation(inputs)
    return outputs


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_all_outputs(inputs)

    print("=== Long COVID (PASC) Prevalence and Chronic-Conversion Simulator ===")
    print()
    print("Inputs (defaults):")
    print(f"  Overall PASC prevalence (AI phenotyping): {inputs['overall_pasc_prevalence']}% of COVID-19 patients")
    print(f"  Code-based PASC surveillance estimate:     {inputs['code_based_surveillance_estimate']}% of COVID-19 survivors")
    print(f"  Chronic-conversion rate:                   {inputs['chronic_conversion_rate']}% of PASC patients")
    print(f"  Southern California PASC prevalence:       {inputs['southern_california_prevalence']}% of COVID-19 patients")
    print(f"  Western Pennsylvania PASC prevalence:      {inputs['western_pennsylvania_prevalence']}% of COVID-19 patients")
    print(f"  US documented COVID-19 case count (CDC):   {inputs['us_covid_case_count_cdc']:,} individuals")
    print()
    print("Outputs:")
    print(f"  Surveillance gap (percentage points): {outputs['surveillance_gap_percentage_points']:.4f}")
    print(f"  Chronic PASC share of all COVID-19 patients (%): {outputs['chronic_pasc_share_of_all_covid']:.4f}")
    print(f"  Regional prevalence gap (percentage points): {outputs['regional_prevalence_gap']:.4f}")
    print(f"  National chronic PASC extrapolation (individuals): {outputs['national_chronic_pasc_extrapolation']:,.2f}")