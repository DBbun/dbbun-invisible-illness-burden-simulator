================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : QO36346YUEgzH3hazYuPC148
    Generated   : 2026-10-10 04:34:27 UTC
================================================================

TITLE
-----
Persistent Lyme Disease (PLD/CLD) Care-Access Barriers Simulator

BOUNDARY
--------
This models findings from a 2021 self-selected survey of 155 U.S. clinicians who treat persistent/chronic Lyme disease (PLD/CLD), covering insurance-network participation, regulatory/legal risk, and one clinician's anecdotal out-of-pocket cost range. It does not model total medical expenditure, income loss, caregiver burden, or any population-representative cost estimate, because the source document does not measure these.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed survey study of 155 U.S. clinicians who treat persistent or chronic Lyme disease (PLD/CLD), conducted by LymeDisease.org in late 2021. It reports clinician-side barriers to providing care: long wait times for initial consultations, lengthy and complex visits, widespread non-participation in insurance networks and government plans, insurance denials and prior-authorization burdens, professional stigma, and regulatory/legal risk (medical board complaints). It also cites prior patient surveys and clinical studies (not this study's own data) on diagnostic delay, misdiagnosis rates, treatment failure rates, and patient travel distances. The study does not measure total medical costs, patient income loss, or caregiver burden directly; it focuses on structural/systemic barriers reported by a self-selected sample of clinicians.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would primarily inform care-delivery and policy/payer audiences about structural barriers in the PLD/CLD care-delivery system - clinician wait times, visit duration, insurance-network withdrawal, regulatory risk, and stigma - rather than direct patient cost totals, since this document does not measure aggregate medical expenditure or income loss. Patients/advocates could use it to anticipate access barriers (long waits, travel, likely out-of-network billing) when seeking a PLD/CLD-treating clinician. Payers/policy audiences could use the insurance-participation and regulatory-burden findings to evaluate whether current reimbursement and oversight models discourage clinician participation and worsen access. All uses must preserve that this is a self-selected, non-random clinician sample (n=155) reporting on their own practices and patients, not a population-representative or formally priced economic dataset.

WHAT YOU COULD DO WITH IT
-------------------------
- Care-delivery capacity planners could model expected wait times and visit-length requirements (e.g., 60% of clinicians report >1 month wait; 25% report initial visits >2 hours) when estimating clinician workforce needs for PLD/CLD care.
- Policy/payer audiences could use the insurance-network non-participation rates (74-77%) and regulatory-inquiry rate (39%) as inputs for simulating how reimbursement reform or regulatory protections might affect clinician retention and patient access, while keeping the clinician-reported OOP cost figure ($10-20K/year) clearly flagged as a single anecdotal estimate, not a population mean.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 69 Lyme-related terms (for example, "Lyme", "Tick-Borne", "Borrelia"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2022.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Clinician-quoted low end of annual out-of-pocket patient cost (USD), default 10000, source: Page 5, Section 3.3, a single clinician's open-text comment (not a structured survey item). 5000-15000 range is an assumed exploration bound around this anecdote, not from the source.
- Clinician-quoted high end of annual out-of-pocket patient cost (USD), default 20000, source: Page 5, Section 3.3, the same single clinician's open-text comment. 16000-30000 range is an assumed exploration bound set above the low-end input's range, not from the source.
- Assumed years of ongoing out-of-pocket PLD/CLD treatment (years), default 3, source: Not reported in the document; assumed illustrative duration for projecting a multi-year cost from the single-year anecdote. 1-10 range is an assumed exploration bound.
- Surveyed clinicians not participating in insurance networks (percent), default 74, source: Page 5, Figure 3 / Section 3.3, this study's own survey of 155 PLD/CLD-treating clinicians. 0-100 range is a standard percent exploration bound.
- Surveyed clinicians reported to a medical board, insurer, or QI committee (percent), default 39, source: Page 5-6, Section 3.3, this study's own survey of 155 PLD/CLD-treating clinicians. 0-100 range is a standard percent exploration bound.

OUTPUTS (5)
-----------
- Midpoint of clinician-quoted annual out-of-pocket cost: 15,000 (USD) at default assumptions
- Gap between clinician-quoted high and low cost estimates (positive = high end exceeds low end): 10,000 (USD) at default assumptions
- Projected cumulative out-of-pocket cost over assumed years of care: 45,000 (USD) at default assumptions
- Share of surveyed clinicians outside insurance networks: 74 (percent) at default assumptions
- Share of surveyed clinicians reported to a medical board, insurer, or QI committee: 39 (percent) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::3::readme2017-ed-stata.txt, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson LB et al. Access to Care in Lyme Disease: Clinician Barriers to Providing Care. Healthcare (Basel). 2022
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36292329/
  DOI: https://doi.org/10.3390/healthcare10101882

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.