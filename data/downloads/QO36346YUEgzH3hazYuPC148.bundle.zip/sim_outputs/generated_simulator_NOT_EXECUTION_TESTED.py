DEFAULT_INPUTS = {
    "annual_oop_cost_low": 10000,
    "annual_oop_cost_high": 20000,
    "years_in_persistent_care": 3,
    "insurance_network_nonparticipation_pct": 74,
    "regulatory_inquiry_pct": 39,
}

SCENARIOS = {
    "minimal_cost_shorter_care": {
        "annual_oop_cost_low": 5000,
        "annual_oop_cost_high": 16000,
        "years_in_persistent_care": 1,
    },
    "higher_cost_longer_care": {
        "annual_oop_cost_low": 15000,
        "annual_oop_cost_high": 30000,
        "years_in_persistent_care": 10,
    },
    "government_plan_nonparticipation": {
        "insurance_network_nonparticipation_pct": 77,
    },
    "board_specific_inquiry": {
        "regulatory_inquiry_pct": 19,
    },
}


def compute_outputs(inputs):
    """Compute all spec outputs from an inputs dict."""
    low = inputs["annual_oop_cost_low"]
    high = inputs["annual_oop_cost_high"]
    years = inputs["years_in_persistent_care"]
    nonpart_pct = inputs["insurance_network_nonparticipation_pct"]
    reg_pct = inputs["regulatory_inquiry_pct"]

    annual_oop_cost_midpoint = (low + high) / 2
    annual_oop_cost_range = high - low
    projected_multiyear_oop_cost = annual_oop_cost_midpoint * years
    insurance_network_nonparticipation_display = nonpart_pct
    regulatory_inquiry_display = reg_pct

    return {
        "annual_oop_cost_midpoint": annual_oop_cost_midpoint,
        "annual_oop_cost_range": annual_oop_cost_range,
        "projected_multiyear_oop_cost": projected_multiyear_oop_cost,
        "insurance_network_nonparticipation_display": insurance_network_nonparticipation_display,
        "regulatory_inquiry_display": regulatory_inquiry_display,
    }


def compute_trajectory(inputs, periods=10):
    """Cumulative out-of-pocket cost per patient, flat annual midpoint repeated each year."""
    low = inputs["annual_oop_cost_low"]
    high = inputs["annual_oop_cost_high"]
    annual_oop_cost_midpoint = (low + high) / 2

    values = []
    prev = 0
    for _ in range(periods):
        prev = prev + annual_oop_cost_midpoint
        values.append(prev)
    return values


def apply_overrides(base_inputs, overrides):
    merged = dict(base_inputs)
    merged.update(overrides)
    return merged


def print_outputs(label, inputs):
    outputs = compute_outputs(inputs)
    print(f"--- {label} ---")
    print(f"Inputs: {inputs}")
    print(
        "annual_oop_cost_midpoint (USD): "
        f"{outputs['annual_oop_cost_midpoint']}"
    )
    print(
        "annual_oop_cost_range (USD, high - low): "
        f"{outputs['annual_oop_cost_range']}"
    )
    print(
        "projected_multiyear_oop_cost (USD): "
        f"{outputs['projected_multiyear_oop_cost']}"
    )
    print(
        "insurance_network_nonparticipation_display (%): "
        f"{outputs['insurance_network_nonparticipation_display']}"
    )
    print(
        "regulatory_inquiry_display (%): "
        f"{outputs['regulatory_inquiry_display']}"
    )
    trajectory = compute_trajectory(inputs, periods=10)
    print("cumulative_oop_cost trajectory (USD/patient, per year 1..10):")
    for year, value in enumerate(trajectory, start=1):
        print(f"  year {year}: {value}")
    print()


if __name__ == "__main__":
    # Default inputs
    print_outputs("Default inputs", DEFAULT_INPUTS)

    # Scenario explorations (not required by output spec, shown for transparency)
    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = apply_overrides(DEFAULT_INPUTS, overrides)
        print_outputs(f"Scenario: {scenario_id}", scenario_inputs)