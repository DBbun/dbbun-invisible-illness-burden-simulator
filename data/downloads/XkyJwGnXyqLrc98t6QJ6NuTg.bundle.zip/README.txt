================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : XkyJwGnXyqLrc98t6QJ6NuTg
    Generated   : 2026-10-05 21:15:45 UTC
================================================================

TITLE
-----
Long COVID Diagnosis Code (U09.9) Coding Delay and Representation Gaps (N3C Cohort, Oct 2021-May 2022)

BOUNDARY
--------
This simulator reproduces coding-uptake, demographic-representation, and clinical-encounter figures from a single N3C electronic-health-record study of the U09.9 long COVID diagnosis code at 34 US health systems (index dates Oct 1 2021-May 26 2022, n=33,782 coded patients). It does not include any medical cost, non-medical cost, income-loss, or caregiving-time data, because this document reports none. All demographic comparisons are against the SARS-CoV-2-positive population at the same 34 sites, not a national benchmark, and the cohort cannot be scaled to a national count without assumptions the document does not make.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed study using the National COVID Cohort Collaborative (N3C) electronic health record database to examine how the new U09.9 long COVID diagnosis code was used by 34 US health systems between October 2021 and May 2022, in a base cohort of 33,782 patients. It reports who received the code (skewed toward female, White, non-Hispanic patients and those in lower-poverty, lower-unemployment areas), what conditions and procedures co-occurred with the diagnosis, and discusses how the nearly two-year delay before the code existed, inconsistent coding practice, and unequal access to the primary-care visits that generate the code likely mean the coded population undercounts and misrepresents the true long COVID population. It does not report any direct medical cost, non-medical cost, income loss, or caregiving-time figures.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help care delivery teams and payers/policy audiences understand how structural factors - a nearly two-year coding delay, inconsistent clinical uptake, and socioeconomic/demographic disparities in who receives a diagnosis code - shape which long COVID patients are visible in administrative/EHR data at all, informing where surveillance and outreach gaps exist. Patients and advocates could use the demographic/SDoH disparity findings to understand why certain groups (lower-income, higher-deprivation areas, non-White, male patients) may be underrepresented in long COVID counts despite comparable or higher underlying COVID-19 burden. The document supports questions about diagnostic/care-pattern burden (imaging, ECG, rehabilitation utilization) but cannot answer questions about dollar costs, income loss, or caregiving time, which it does not report.

WHAT YOU COULD DO WITH IT
-------------------------
- Illustrating to policy/payer audiences how reliance on a single ICD-10 code (U09.9) for long COVID case counts likely undercounts the true patient population, and why area-level poverty/unemployment/insurance status correlate with lower odds of receiving the code.
- Helping care delivery teams see which diagnostic procedures (imaging, ECG, echocardiography) and age-stratified symptom clusters are currently associated with a long COVID diagnosis, to benchmark their own practice patterns against this N3C cohort - without extrapolating these EHR-based rates to a national cost or prevalence figure.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 187 Long COVID-related terms (for example, "long COVID", "post-acute sequelae", "PASC"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Pfaff 2023 coding.pdf

PARAMETERS (7)
--------------
- Years from patient symptom reports to dedicated diagnosis code (years), default 2, source: Document states 'nearly 2 years' from Spring 2020 patient reports to October 2021 code release (Abstract/Background, p.1-2); default is the document's approximate value, 1.5-2.5 range is an assumed exploration bound, not from the source.
- Female share of U09.9-coded cohort (%), default 66.9, source: Document reports 66.9% female in the U09.9 cohort (Results, p.5); default from source, 50-85 range is an assumed exploration bound, not from the source.
- Female share of all SARS-CoV-2-positive patients (same sites) (%), default 55.6, source: Document reports 55.6% female among all SARS-CoV-2-positive patients at the same 34 sites (Results, p.5); default from source, 40-75 range is an assumed exploration bound, not from the source.
- White share of U09.9-coded cohort (%), default 71.8, source: Document reports 71.8% White in the U09.9 cohort (Results, p.5); default from source, 55-90 range is an assumed exploration bound, not from the source.
- White share of all SARS-CoV-2-positive patients (same sites) (%), default 61.1, source: Document reports 61.1% White among all SARS-CoV-2-positive patients at the same 34 sites (Results, p.5); default from source, 45-80 range is an assumed exploration bound, not from the source.
- Share of U09.9 patients with no recorded acute-infection date (%), default 37.2, source: Document reports 37.2% (12,550/33,782) of the U09.9 cohort lacked any recorded COVID-19 index date in structured EHR data (Results, p.4-5); default from source, 0-60 range is an assumed exploration bound, not from the source.
- Share of U09.9 cohort hospitalized during acute infection (%), default 9.7, source: Document reports 9.7% (3266/33,782) of the U09.9 cohort were hospitalized during acute SARS-CoV-2 infection (Results, p.4); default from source, 0-30 range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- U09.9 cohort % female minus all-SARS-CoV-2-positive % female (positive = women overrepresented among those coded; negative = underrepresented): 11.3 (percentage points) at default assumptions
- U09.9 cohort % White minus all-SARS-CoV-2-positive % White (positive = White patients overrepresented among those coded; negative = underrepresented): 10.7 (percentage points) at default assumptions
- Share of U09.9 patients with no recorded acute-infection date: 37.2 (%) at default assumptions
- Share of U09.9 cohort hospitalized during acute infection: 9.7 (%) at default assumptions
- Years between symptom reports and dedicated diagnosis code becoming available: 2 (years) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::1::ed2017.do, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::4::Code Descriptions/icd10cm_order_2026.txt, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::3::Code Descriptions/icd10cm_codes_2026.txt, scope: both)

ORIGINAL SOURCE
---------------
Pfaff et al. Coding long COVID: characterizing a new disease through an ICD-10 lens. BMC Med. 2023;21:58
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36793086/
  DOI: https://doi.org/10.1186/s12916-023-02737-6

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.