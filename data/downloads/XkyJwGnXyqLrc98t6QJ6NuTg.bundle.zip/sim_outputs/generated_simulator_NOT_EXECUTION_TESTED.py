#!/usr/bin/env python3
"""
Reference implementation of the N3C U09.9 Long COVID coding-delay and
representation-gap spec. Standard library only. Plain arithmetic
reproduction of the spec's inputs and output expressions; no modeling,
no sampling, no plotting, no CLI.
"""

# ---------------------------------------------------------------------
# Default inputs (from spec["inputs"])
# ---------------------------------------------------------------------

DEFAULT_INPUTS = {
    "coding_delay_years": 2,
    "sex_pct_u099": 66.9,
    "sex_pct_allcovid": 55.6,
    "race_pct_u099": 71.8,
    "race_pct_allcovid": 61.1,
    "missing_covid_index_pct": 37.2,
    "acute_hospitalization_pct": 9.7,
}


def compute_outputs(inputs):
    """
    Compute all outputs exactly as defined in spec["outputs"], using the
    given inputs dict. Returns a dict of output_id -> value.
    """

    sex_representation_gap = inputs["sex_pct_u099"] - inputs["sex_pct_allcovid"]

    race_representation_gap = inputs["race_pct_u099"] - inputs["race_pct_allcovid"]

    missing_index_date_share = inputs["missing_covid_index_pct"]

    acute_hospitalization_share = inputs["acute_hospitalization_pct"]

    coding_delay_output = inputs["coding_delay_years"]

    return {
        "sex_representation_gap": sex_representation_gap,
        "race_representation_gap": race_representation_gap,
        "missing_index_date_share": missing_index_date_share,
        "acute_hospitalization_share": acute_hospitalization_share,
        "coding_delay_output": coding_delay_output,
    }


OUTPUT_META = {
    "sex_representation_gap": (
        "Sex representation gap (U09.9 % female - all-COVID % female)",
        "percentage points",
    ),
    "race_representation_gap": (
        "Race representation gap (U09.9 % White - all-COVID % White)",
        "percentage points",
    ),
    "missing_index_date_share": (
        "Share of U09.9 patients with no recorded acute-infection date",
        "%",
    ),
    "acute_hospitalization_share": (
        "Share of U09.9 cohort hospitalized during acute infection",
        "%",
    ),
    "coding_delay_output": (
        "Years between symptom reports and dedicated diagnosis code availability",
        "years",
    ),
}


def format_report(inputs, outputs):
    lines = []
    lines.append("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        lines.append(f"  {k}: {v}")
    lines.append("")
    lines.append("=== Outputs ===")
    for out_id, value in outputs.items():
        label, unit = OUTPUT_META[out_id]
        lines.append(f"  {out_id}: {value:g} {unit}  -- {label}")
    return "\n".join(lines)


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)
    print(format_report(inputs, outputs))