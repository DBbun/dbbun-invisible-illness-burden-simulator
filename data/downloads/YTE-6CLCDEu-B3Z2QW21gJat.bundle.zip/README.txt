================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : YTE-6CLCDEu-B3Z2QW21gJat
    Generated   : 2026-10-06 17:06:06 UTC
================================================================

TITLE
-----
Long COVID Lost Labor Cost Simulator (2022 MEPS, US Full-Time Workers)

BOUNDARY
--------
This simulation covers only self-reported, wage-based lost-workday ('lost labor') costs for US adults still working full-time in 2022, as measured in a single MEPS survey cross-section. It does not include direct medical costs, non-medical costs, caregiving burden, presenteeism (reduced productivity while still working), or anyone who reduced hours or left the workforce entirely because of Long COVID. The national projection is a formula-based extrapolation, not a directly measured total, and is a structurally different quantity from the survey-weighted group totals the document also reports.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed research letter (JABFM, 2025) that used 2022 Medical Expenditure Panel Survey (MEPS) data on US adult full-time workers to estimate the cost of workdays missed due to illness among people with Long COVID (defined as COVID-19 symptoms lasting 3+ months), compared with people who had COVID-19 without Long COVID and people who never had COVID-19. Using a human-capital (wage-based) approach, the authors found that individuals with Long COVID had substantially higher average lost-labor costs than the other two groups, and they extrapolated this to a national population-level estimate of over $12 billion in lost labor costs in 2022. The study covers only wage/workday-loss burden for employed full-time workers; it does not address direct medical costs, non-medical costs, caregiving burden, or people who left the workforce entirely due to Long COVID.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could let payers/policy audiences and employers model the national or per-employee lost-labor-cost impact of Long COVID using a transparent human-capital formula (hours worked, wage, missed workdays), based on real 2022 MEPS national survey data. Patients/advocates could use the per-individual mean cost figures ($1,944 vs $702 vs $1,466) to illustrate the disproportionate work-loss burden of Long COVID relative to no-COVID or COVID-without-LC baselines. It cannot inform direct medical cost, caregiving, or non-labor financial burden questions, since the document does not measure those categories.

WHAT YOU COULD DO WITH IT
-------------------------
- Payers/policy audiences could use the population-level ($12.8B) and per-individual mean lost-labor-cost figures as one input (labor-cost component only) when scoping the scale of the Long COVID workforce problem for 2022, while explicitly excluding medical/non-medical cost components this document does not measure.
- Employers or benefits planners could use the per-individual mean cost difference between Long COVID and never-had-COVID-19 workers ($1,242.04) as a baseline illustrative figure for sick-leave/absenteeism cost planning, with the caveat that paid sick leave status was not significantly associated with having Long COVID in this sample (OR 0.90, p=.51).

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 18 Long COVID-related terms (for example, "Long COVID", "post-acute sequelae", "post-COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Liu-Galvin 2025.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Mean lost labor cost per person, Long COVID (USD), default 1944.46, source: Results section, p.942; Table 1, p.941 reports this as the observed mean lost labor cost per individual with Long COVID in MEPS 2022; the 0-5000 range is an assumed exploration bound, not from the source.
- Mean lost labor cost per person, never had COVID-19 (USD), default 702.42, source: Results section, p.942; Table 1, p.941 reports this observed mean; the 0-5000 range is an assumed exploration bound, not from the source.
- Mean lost labor cost per person, COVID-19 without Long COVID (USD), default 1465.55, source: Results section, p.942; Table 1, p.941 reports this observed mean; the 0-5000 range is an assumed exploration bound, not from the source.
- Long COVID prevalence among full-time workers (percent), default 7.8, source: Results section, p.942 reports this weighted prevalence among the MEPS 2022 full-time worker study sample; the 0-20 range is an assumed exploration bound, not from the source.
- US full-time workforce count used for national scaling (count), default 131960000, source: Back-calculated by dividing the document's own stated national estimate ($12,784,168,675.20, Results section p.942) by its own reported mean-cost difference (Table 2, p.941) and prevalence (Results section p.942); the document cites BLS 2022 full-time worker counts as the basis but does not state the exact number itself, so this value is back-calculated, not quoted directly. The 100,000,000-160,000,000 range is an assumed exploration bound, not from the source.

OUTPUTS (3)
-----------
- Mean lost labor cost: Long COVID minus never had COVID-19 (positive = Long COVID costs more): 1242.04 (USD) at default assumptions
- Mean lost labor cost: Long COVID minus COVID-19 without Long COVID (positive = Long COVID costs more): 478.91 (USD) at default assumptions
- Projected national lost labor cost attributable to Long COVID, 2022: 1.27842e+10 (USD) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 464 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::436::SAGDP8_US_1997_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::58::SAGDP2_US_1997_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::247::SAGDP5_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::310::SAGDP6_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::373::SAGDP7_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::184::SAGDP4_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Liu-Galvin R et al. Economic Burden of Long COVID: Lost Labor Costs in US Adults. J Am Board Fam Med. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41491558/
  DOI: https://doi.org/10.3122/jabfm.2025.250059R1

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.