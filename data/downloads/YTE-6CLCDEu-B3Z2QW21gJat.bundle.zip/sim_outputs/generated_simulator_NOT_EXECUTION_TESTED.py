#!/usr/bin/env python3
"""
Long COVID Lost Labor Cost Simulator (2022 MEPS, US Full-Time Workers)

Reference implementation of the spec. Standard library only.
"""


def compute_cost_gap_vs_never_covid(mean_cost_long_covid, mean_cost_never_covid):
    """Mean lost labor cost: Long COVID minus never had COVID-19."""
    return mean_cost_long_covid - mean_cost_never_covid


def compute_cost_gap_vs_covid_no_lc(mean_cost_long_covid, mean_cost_covid_no_lc):
    """Mean lost labor cost: Long COVID minus COVID-19 without Long COVID."""
    return mean_cost_long_covid - mean_cost_covid_no_lc


def compute_national_lost_labor_cost_estimate(
    cost_gap_vs_never_covid, long_covid_prevalence, n_full_time_workers
):
    """Projected national lost labor cost attributable to Long COVID, 2022."""
    return cost_gap_vs_never_covid * (
        (long_covid_prevalence / 100) * n_full_time_workers
    )


DEFAULT_INPUTS = {
    "mean_cost_long_covid": 1944.46,
    "mean_cost_never_covid": 702.42,
    "mean_cost_covid_no_lc": 1465.55,
    "long_covid_prevalence": 7.8,
    "n_full_time_workers": 131960000,
}


def run(inputs):
    mean_cost_long_covid = inputs["mean_cost_long_covid"]
    mean_cost_never_covid = inputs["mean_cost_never_covid"]
    mean_cost_covid_no_lc = inputs["mean_cost_covid_no_lc"]
    long_covid_prevalence = inputs["long_covid_prevalence"]
    n_full_time_workers = inputs["n_full_time_workers"]

    cost_gap_vs_never_covid = compute_cost_gap_vs_never_covid(
        mean_cost_long_covid, mean_cost_never_covid
    )
    cost_gap_vs_covid_no_lc = compute_cost_gap_vs_covid_no_lc(
        mean_cost_long_covid, mean_cost_covid_no_lc
    )
    national_lost_labor_cost_estimate = compute_national_lost_labor_cost_estimate(
        cost_gap_vs_never_covid, long_covid_prevalence, n_full_time_workers
    )

    return {
        "cost_gap_vs_never_covid": cost_gap_vs_never_covid,
        "cost_gap_vs_covid_no_lc": cost_gap_vs_covid_no_lc,
        "national_lost_labor_cost_estimate": national_lost_labor_cost_estimate,
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    results = run(inputs)

    print("Long COVID Lost Labor Cost Simulator (2022 MEPS, US Full-Time Workers)")
    print("=" * 72)
    print()
    print("Inputs (defaults):")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print()
    print("Outputs:")
    print(
        "  cost_gap_vs_never_covid (USD): "
        f"{results['cost_gap_vs_never_covid']:.2f}"
    )
    print(
        "  cost_gap_vs_covid_no_lc (USD): "
        f"{results['cost_gap_vs_covid_no_lc']:.2f}"
    )
    print(
        "  national_lost_labor_cost_estimate (USD): "
        f"{results['national_lost_labor_cost_estimate']:.2f}"
    )