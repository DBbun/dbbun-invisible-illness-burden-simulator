DEFAULT_INPUTS = {
    "child_excess_cost_6mo": 1011,
    "adult_excess_cost_6mo": 1562,
    "adult_men_excess_cost_6mo": 1764,
    "adult_women_excess_cost_6mo": 1530,
    "adult_hosp_cost_multiplier": 3.18,
    "child_hosp_cost_multiplier": 9.47,
}


def compute_outputs(inputs):
    child_excess_cost_6mo = inputs["child_excess_cost_6mo"]
    adult_excess_cost_6mo = inputs["adult_excess_cost_6mo"]
    adult_men_excess_cost_6mo = inputs["adult_men_excess_cost_6mo"]
    adult_women_excess_cost_6mo = inputs["adult_women_excess_cost_6mo"]
    adult_hosp_cost_multiplier = inputs["adult_hosp_cost_multiplier"]
    child_hosp_cost_multiplier = inputs["child_hosp_cost_multiplier"]

    excess_cost_children_6mo = child_excess_cost_6mo
    excess_cost_adults_6mo = adult_excess_cost_6mo
    sex_cost_gap_adults_6mo = adult_men_excess_cost_6mo - adult_women_excess_cost_6mo
    hospitalization_cost_multiplier_adults = adult_hosp_cost_multiplier
    hospitalization_cost_multiplier_children = child_hosp_cost_multiplier

    return {
        "excess_cost_children_6mo": excess_cost_children_6mo,
        "excess_cost_adults_6mo": excess_cost_adults_6mo,
        "sex_cost_gap_adults_6mo": sex_cost_gap_adults_6mo,
        "hospitalization_cost_multiplier_adults": hospitalization_cost_multiplier_adults,
        "hospitalization_cost_multiplier_children": hospitalization_cost_multiplier_children,
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("Post-COVID-19 Excess Direct Medical Cost Explorer")
    print("(Privately Insured, 2020 Cohort)")
    print()
    print("Inputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key}: {value}")
    print()
    print("Outputs:")
    print(f"  excess_cost_children_6mo (USD): {outputs['excess_cost_children_6mo']}")
    print(f"  excess_cost_adults_6mo (USD): {outputs['excess_cost_adults_6mo']}")
    print(f"  sex_cost_gap_adults_6mo (USD, men minus women): {outputs['sex_cost_gap_adults_6mo']}")
    print(f"  hospitalization_cost_multiplier_adults (ratio): {outputs['hospitalization_cost_multiplier_adults']}")
    print(f"  hospitalization_cost_multiplier_children (ratio): {outputs['hospitalization_cost_multiplier_children']}")