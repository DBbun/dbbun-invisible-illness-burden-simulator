================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 1BKCLntBLcvoY64pRzy6UIEZ
    Generated   : 2026-10-07 20:18:45 UTC
================================================================

TITLE
-----
Post-COVID-19 Excess Direct Medical Cost Explorer (Privately Insured, 2020 Cohort)

BOUNDARY
--------
This simulation reproduces the CDC/Pike et al. (2023) comparison of total direct medical claims costs (combined insurer- and patient-paid amounts) between privately insured people diagnosed with COVID-19 in April-August 2020 and matched people without a diagnosis, over the 6 months starting 31 days after diagnosis. It covers only people under 65 with commercial insurance, only the pre-vaccine, pre-Delta/Omicron period, and only direct medical claims costs. It does not estimate out-of-pocket spending separately, productivity or caregiving losses, costs beyond 6 months, costs for Medicare/Medicaid/uninsured populations, or costs for later pandemic periods.

ABOUT THE SOURCE DOCUMENT
-------------------------
This CDC study used a large US commercial insurance claims database (IQVIA PharMetrics Plus) to compare medical spending, starting 31 days after diagnosis, between people diagnosed with COVID-19 (April-August 2020) and matched people without a COVID-19 diagnosis. It found that both children and adults with COVID-19 had meaningfully higher medical costs over the following 1, 3, and 6 months than their matched controls, with the largest relative cost gap among children and the largest dollar gap among adults aged 50-64 and among anyone previously hospitalized for COVID-19. The study only measures direct medical (claims) costs for privately insured people under 65 during the first pandemic year, before vaccines, Delta/Omicron, or a dedicated PCC diagnosis code existed, and explicitly does not estimate out-of-pocket cost differences or productivity/caregiving losses. The authors describe their approach as a likely lower-bound estimate of PCC-related health care utilization cost because no PCC-specific ICD-10 code was available during the study period.

WHY THIS COULD BE USEFUL
------------------------
Payers and policy analysts could use the age-, sex-, and hospitalization-stratified excess cost figures to estimate the near-term (1-6 month) added claims burden of COVID-19/PCC in a privately insured working-age population, informing cost-effectiveness models for vaccination or other prevention strategies - with the explicit caveat that this is a lower-bound, claims-only estimate from a single pre-vaccine, pre-Delta/Omicron cohort. Care delivery teams could use the hospitalization cost-multiplier findings to anticipate that a small hospitalized subgroup drives disproportionately higher downstream medical costs, supporting case-management targeting. Patients/advocates could use the relative magnitude of excess costs by age and sex to understand general population-level cost patterns, but the study does not support predicting an individual patient's bill, out-of-pocket exposure, or productivity/caregiving losses.

WHAT YOU COULD DO WITH IT
-------------------------
- A payer or policy analyst could input the age- and sex-stratified 1-, 3-, and 6-month excess direct medical cost figures as scenario inputs to estimate the added near-term claims cost of COVID-19/PCC in a privately insured population, while keeping the 'lower bound, pre-vaccine, pre-Delta/Omicron' caveat attached.
- A care-delivery or case-management team could use the hospitalized-vs-non-hospitalized cost multiplier (e.g., 3.18x for adults, 9.47x for children at 6 months) to flag which COVID-19 patients are likely to generate the highest downstream utilization and prioritize follow-up care coordination.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 6 Long COVID-related terms (for example, "U09.9", "post-COVID", "post-acute sequelae"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Pike 2023.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Child excess direct medical cost, 6 months (USD), default 1011, source: Table 2, p.9 (Pike et al. 2023); 0-3000 range is an assumed exploration bound, not from the source
- Adult excess direct medical cost, 6 months (USD), default 1562, source: Table 2, p.9 (Pike et al. 2023); 0-5000 range is an assumed exploration bound, not from the source
- Adult men's excess direct medical cost, 6 months (USD), default 1764, source: Table 3, p.10 (Pike et al. 2023); 0-5000 range is an assumed exploration bound, not from the source
- Adult women's excess direct medical cost, 6 months (USD), default 1530, source: Table 3, p.10 (Pike et al. 2023); 0-5000 range is an assumed exploration bound, not from the source
- Adult hospitalized-vs-non-hospitalized cost ratio, 6 months (ratio), default 3.18, source: Table 4, p.11 (Pike et al. 2023); 1-10 range is an assumed exploration bound chosen so hospitalized costs cannot fall below non-hospitalized costs, not from the source
- Child hospitalized-vs-non-hospitalized cost ratio, 6 months (ratio), default 9.47, source: Table 4, p.11 (Pike et al. 2023); 1-20 range is an assumed exploration bound chosen so hospitalized costs cannot fall below non-hospitalized costs, not from the source

OUTPUTS (5)
-----------
- Children's 6-month excess direct medical cost: 1,011 (USD) at default assumptions
- Adults' 6-month excess direct medical cost: 1,562 (USD) at default assumptions
- Adult male minus female excess cost at 6 months (positive = men's dollar excess cost higher; negative = women's higher): 234 (USD) at default assumptions
- Adult hospitalization 6-month cost multiplier: 3.18 (ratio) at default assumptions
- Child hospitalization 6-month cost multiplier: 9.47 (ratio) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 451 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::436::SAGDP8_US_1997_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)

ORIGINAL SOURCE
---------------
Pike J et al. Direct Medical Costs Associated With Post-COVID-19 Conditions Among Privately Insured Children and Adults. Prev Chronic Dis. 2023
  PubMed: https://pubmed.ncbi.nlm.nih.gov/36757854/
  DOI: https://doi.org/10.5888/pcd20.220292

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.