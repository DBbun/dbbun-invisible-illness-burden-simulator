#!/usr/bin/env python3
"""
Reference implementation of the Sex Differences in Persistent/Chronic Lyme
Disease simulator spec. Standard library only.

This script reproduces the exact arithmetic described in the spec's
"outputs" expressions, applied to the spec's default "inputs". It is a
plain reference implementation, not a reproduction of the source paper's
full statistical model.
"""

# ---------------------------------------------------------------------------
# Default inputs (from spec "inputs" -> "default")
# ---------------------------------------------------------------------------
DEFAULT_INPUTS = {
    "women_late_stage_pct": 83,
    "men_late_stage_pct": 76,
    "women_misdiag_cfs_fibro_psych_pct": 78,
    "men_misdiag_cfs_fibro_psych_pct": 63,
    "women_bed_days_pct": 63,
    "men_bed_days_pct": 49,
    "women_enrolled_ald_pct": 42,
    "women_enrolled_pldcld_pct": 77,
}


def subtract(a, b):
    """Same arithmetic as the spec's {"op": "subtract", "args": [a, b]}."""
    return a - b


def compute_outputs(inputs):
    """Compute each output exactly as specified by its expression."""
    outputs = {}

    outputs["late_stage_diagnosis_sex_gap_pp"] = subtract(
        inputs["women_late_stage_pct"], inputs["men_late_stage_pct"]
    )

    outputs["misdiagnosis_cfs_fibro_psych_sex_gap_pp"] = subtract(
        inputs["women_misdiag_cfs_fibro_psych_pct"],
        inputs["men_misdiag_cfs_fibro_psych_pct"],
    )

    outputs["bed_days_sex_gap_pp"] = subtract(
        inputs["women_bed_days_pct"], inputs["men_bed_days_pct"]
    )

    outputs["women_enrollment_study_type_gap_pp"] = subtract(
        inputs["women_enrolled_pldcld_pct"], inputs["women_enrolled_ald_pct"]
    )

    return outputs


OUTPUT_LABELS = {
    "late_stage_diagnosis_sex_gap_pp": (
        "Late-stage diagnosis gap: women minus men (pp)"
    ),
    "misdiagnosis_cfs_fibro_psych_sex_gap_pp": (
        "CFS/fibromyalgia/psychiatric misdiagnosis gap: women minus men (pp)"
    ),
    "bed_days_sex_gap_pp": (
        "8+ bed-day gap: women minus men (pp)"
    ),
    "women_enrollment_study_type_gap_pp": (
        "Women-enrollment share gap: persistent-illness minus acute studies (pp)"
    ),
}


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("Inputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key} = {value}")

    print("\nOutputs:")
    for key, value in outputs.items():
        label = OUTPUT_LABELS.get(key, key)
        print(f"  {key} ({label}) = {value}")