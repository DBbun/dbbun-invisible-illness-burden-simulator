================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : BEThvtimF8ZkgpM87oyQMkUX
    Generated   : 2026-10-10 21:10:17 UTC
================================================================

TITLE
-----
Sex Differences in Persistent/Chronic Lyme Disease: Diagnostic Delay, Misdiagnosis, and Functional Impairment

BOUNDARY
--------
This simulator models only the sex-disaggregated percentages this peer-reviewed study reports from its own MyLymeData patient registry sample (N=2170; 1839 women, 331 men; dataset dated April 27, 2017), all self-reported by patients already clinically diagnosed with persistent/chronic Lyme disease (illness continuing six or more months after antibiotic treatment). It also includes the study's separate review of what share of women were enrolled across different Lyme disease study designs. It does not and cannot model any dollar cost, lost income, or caregiving-hour figure, because this document reports none. All percentages describe this specific self-selected registry sample, not a general population estimate.

ABOUT THE SOURCE DOCUMENT
-------------------------
This peer-reviewed study analyzes self-reported survey data from 2,170 U.S. patients (1,839 women, 331 men) in the MyLymeData patient registry who were clinically diagnosed with Lyme disease and remained ill six or more months after antibiotic treatment (persistent/chronic Lyme disease, PLD/CLD). It finds that women in this sample experienced longer diagnostic delays, more misdiagnosis (especially with chronic fatigue syndrome, fibromyalgia, or psychiatric illness), more tick-borne coinfections, worse symptom severity, and greater functional impairment than men, with no significant sex difference in antibiotic treatment response or side effects. The authors also reviewed other Lyme disease studies and found the proportion of women enrolled varies sharply by study design: lowest in acute Lyme disease studies, higher in restrictive RCT/post-treatment-Lyme-disease trials, and highest in more clinically representative persistent-illness cohorts. The paper does not report any direct medical cost, non-medical cost, or lost-income/productivity figures in dollar terms; its burden evidence is limited to diagnostic-delay rates, misdiagnosis rates, symptom severity, and functional-impairment measures (bed days, disability status, special equipment use) in this specific self-selected registry sample.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help patients and advocates understand documented sex-based patterns in diagnostic delay, misdiagnosis, symptom severity, and functional impairment among people with persistent/chronic Lyme disease, informing how they describe their own illness trajectory or advocate for earlier diagnosis. Care delivery teams could use the misdiagnosis findings (especially the high rates of prior CFS, fibromyalgia, or psychiatric misdiagnosis in women) to inform differential-diagnosis awareness and clinician training discussions. Researchers, funders, and policy audiences could use the study's sex-distribution-by-study-type findings (Figure 3) to evaluate whether a proposed or existing Lyme disease trial's eligibility criteria are likely to underrepresent women relative to the population seen in real-world clinical practice. No audience should treat this document as a source of direct medical or economic cost figures, since none are reported.

WHAT YOU COULD DO WITH IT
-------------------------
- A patient/advocate-facing module that surfaces this document's sex-stratified diagnostic-delay and misdiagnosis rates (e.g., likelihood of being misdiagnosed with CFS, fibromyalgia, or a psychiatric condition) to support informed conversations with clinicians about ruling out Lyme disease.
- A research-design/funding-policy module that lets a user compare the documented sex composition of ALD, RCT/PTLD, and PLD/CLD study samples (Figure 3) when designing or reviewing eligibility criteria for a new Lyme disease treatment trial, to assess likely under- or over-representation of women relative to the clinically-observed PLD/CLD population.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 111 Lyme-related terms (for example, "Lyme", "tick-borne", "Borrelia") and 3 Long COVID-related terms (for example, "long COVID"). The 3 term(s) about the other condition are 2.6% of all matched terms, so they are treated as incidental and the document is classified as Lyme disease.

SOURCE FILES
------------
Johnson 2023.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Women diagnosed at a late stage (%) (%), default 83, source: Table 3, p.5; default from document; 60-100 range is an assumed exploration bound, not from the source
- Men diagnosed at a late stage (%) (%), default 76, source: Table 3, p.5; default from document; 60-100 range is an assumed exploration bound, not from the source
- Women misdiagnosed with CFS, fibromyalgia, or psychiatric condition (%) (%), default 78, source: Table 4, p.6; default from document; 50-100 range is an assumed exploration bound, not from the source
- Men misdiagnosed with CFS, fibromyalgia, or psychiatric condition (%) (%), default 63, source: Table 4, p.6; default from document; 50-100 range is an assumed exploration bound, not from the source
- Women with 8+ bed days in 6 months (%) (%), default 63, source: Table 5, p.7; default from document; 30-100 range is an assumed exploration bound, not from the source
- Men with 8+ bed days in 6 months (%) (%), default 49, source: Table 5, p.7; default from document; 30-100 range is an assumed exploration bound, not from the source
- Women enrolled in acute Lyme disease study sources (%, mean) (%), default 42, source: Figure 3 and accompanying text, p.8; default from document (mean across reviewed sources, range 37-47%); 30-55 range is an assumed exploration bound, not from the source
- Women enrolled in persistent/chronic Lyme disease study sources (%, mean) (%), default 77, source: Figure 3 and accompanying text, p.8; default from document (mean across reviewed sources, range 66-88%, including this study's own registry); 60-90 range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Late-stage diagnosis gap: women minus men (percentage points; positive = women higher, negative = men higher): 7 (percentage points) at default assumptions
- CFS/fibromyalgia/psychiatric misdiagnosis gap: women minus men (percentage points; positive = women higher, negative = men higher): 15 (percentage points) at default assumptions
- 8+ bed-day gap: women minus men (percentage points; positive = women higher, negative = men higher): 14 (percentage points) at default assumptions
- Women-enrollment share, persistent-illness studies minus acute-illness studies (percentage points; positive = higher share in persistent-illness study sources): 35 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2022_2023__cdc_9mtj-y2ba.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/nhamcs_ed_2016_2022  (unit cdc/nhamcs_ed_2016_2022/2017/ed2017-stata.zip::1::ed2017.do, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::566::SAGDP11_WA_1998_2025.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson L et al. Does Biological Sex Matter in Lyme Disease? The Need for Sex-Disaggregated Data in Persistent Illness. Int J Gen Med. 2023
  PubMed: https://pubmed.ncbi.nlm.nih.gov/37351009/
  DOI: https://doi.org/10.2147/IJGM.S406466

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.