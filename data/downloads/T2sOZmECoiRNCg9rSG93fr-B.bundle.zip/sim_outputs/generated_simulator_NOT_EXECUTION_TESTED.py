#!/usr/bin/env python3
"""
Reference implementation (standard library only) of the BOLD Lyme disease
diagnostic-delay / manifestation / antibiotic-duration spec.

This script performs only simple arithmetic (subtraction / pass-through) on
user-editable inputs, reproducing the output expressions defined in the
spec. No synthetic patients, no sampling, no plotting, no CLI.
"""

DEFAULT_INPUTS = {
    "em_diagnostic_delay_days": 13.4,
    "disseminated_diagnostic_delay_days": 24.9,
    "other_manifestation_diagnostic_delay_days": 38.5,
    "slovakia_la_share_pct": 76.3,
    "other_countries_la_share_pct": 3.5,
    "antibiotic_duration_mean_days": 15,
    "previous_lb_history_rate_pct": 35.6,
}

SCENARIOS = {
    "slovakia_matches_other_countries": {"slovakia_la_share_pct": 50},
    "other_countries_elevated_la_share": {"other_countries_la_share_pct": 20},
    "widest_manifestation_delay_gap": {
        "em_diagnostic_delay_days": 5,
        "other_manifestation_diagnostic_delay_days": 45,
    },
    "narrowest_disseminated_em_gap": {
        "disseminated_diagnostic_delay_days": 21,
        "em_diagnostic_delay_days": 19,
    },
    "longer_antibiotic_course": {"antibiotic_duration_mean_days": 30},
    "higher_relapse_prevalence": {"previous_lb_history_rate_pct": 60},
}


def compute_outputs(inputs):
    """Compute the spec's output expressions from a dict of inputs."""
    disseminated_minus_em_delay_days = (
        inputs["disseminated_diagnostic_delay_days"]
        - inputs["em_diagnostic_delay_days"]
    )
    other_minus_em_delay_days = (
        inputs["other_manifestation_diagnostic_delay_days"]
        - inputs["em_diagnostic_delay_days"]
    )
    la_share_difference_pct = (
        inputs["slovakia_la_share_pct"] - inputs["other_countries_la_share_pct"]
    )
    repeat_episode_share_pct = inputs["previous_lb_history_rate_pct"]
    antibiotic_duration_typical_days = inputs["antibiotic_duration_mean_days"]

    return {
        "disseminated_minus_em_delay_days": disseminated_minus_em_delay_days,
        "other_minus_em_delay_days": other_minus_em_delay_days,
        "la_share_difference_pct": la_share_difference_pct,
        "repeat_episode_share_pct": repeat_episode_share_pct,
        "antibiotic_duration_typical_days": antibiotic_duration_typical_days,
    }


def build_inputs(overrides=None):
    """Return a copy of the default inputs with optional overrides applied."""
    merged = dict(DEFAULT_INPUTS)
    if overrides:
        merged.update(overrides)
    return merged


def print_outputs(label, inputs, outputs):
    print(f"--- {label} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    for k, v in outputs.items():
        print(f"  {k}: {v}")
    print()


if __name__ == "__main__":
    # Default scenario
    default_inputs = build_inputs()
    default_outputs = compute_outputs(default_inputs)
    print_outputs("Default inputs", default_inputs, default_outputs)

    # Named illustrative scenarios from the spec, each applied on top of defaults
    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs = build_inputs(overrides)
        scenario_outputs = compute_outputs(scenario_inputs)
        print_outputs(scenario_id, scenario_inputs, scenario_outputs)