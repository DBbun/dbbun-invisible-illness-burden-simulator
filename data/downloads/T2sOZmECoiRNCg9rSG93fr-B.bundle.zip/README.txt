================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : T2sOZmECoiRNCg9rSG93fr-B
    Generated   : 2026-10-05 21:16:19 UTC
================================================================

TITLE
-----
Lyme Disease Diagnostic Delay, Country-Level Manifestation Variation, and Antibiotic Treatment Patterns (BOLD Study)

BOUNDARY
--------
This simulation covers only non-monetary, time- and percentage-based findings from the prospective BOLD study of 797 medically attended Lyme borreliosis cases (315 enrolled with detailed data) across six European countries, 2021-2022: diagnostic delay by manifestation type, country-level variation in Lyme-arthritis share, antibiotic treatment duration, and prior-episode history. It omits all dollar costs, income loss, caregiving time, insurance/access barriers, PTLDS burden (explicitly deferred by the authors to a separate manuscript), and quantified adverse-event rates, because this document reports none of these. The reported sex differences in manifestation type (more females with erythema migrans, more males with disseminated disease) are not modeled as sliders here but are preserved in the documentation.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed, Pfizer/Valneva-funded prospective study (BOLD) that tracked 797 medically attended Lyme borreliosis (Lyme disease) cases at 14 primary-care practices in six European countries between April 2021 and December 2022. It reports how often patients had the classic erythema migrans rash versus disseminated disease (such as Lyme arthritis, neuroborreliosis, or carditis), how long it took from symptom onset to diagnosis, how often patients were hospitalized, what antibiotics were prescribed and for how long, and how common prior tick bites or prior Lyme episodes were among enrolled patients. The study found striking country-to-country variation, especially in Slovakia, where 76% of cases were Lyme arthritis compared to about 3.5% elsewhere, a pattern the authors say could reflect several possible, not-yet-distinguishable causes. The document does not report any dollar costs, income loss, caregiving burden, or insurance/access-barrier data; it is a clinical-manifestations and treatment-pattern study, not an economic cost-of-illness analysis.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would be useful for illustrating clinical-process and practical-burden dimensions of Lyme disease across European healthcare settings - diagnostic delay by manifestation type, hospitalization and repeat-treatment likelihood, antibiotic prescribing duration and guideline variation, and the striking country-level differences in disseminated-disease burden - rather than for modeling dollar costs, which this document does not provide. Care delivery teams, public health/policy audiences, and patient/advocate audiences could each draw on different slices of these clinical-burden figures, but any simulator must clearly flag that no cost, income-loss, or caregiving-time data exist here. Any 'economic' framing drawn from this document should be limited to time (diagnostic delay, treatment duration, hospital nights) and care-utilization frequency metrics, explicitly labeled as non-monetary.

WHAT YOU COULD DO WITH IT
-------------------------
- Care delivery teams and public health planners could use the manifestation-frequency and diagnostic-delay findings to benchmark how quickly erythema migrans versus disseminated disease (e.g., Lyme arthritis) is recognized in their own setting, and to flag regions (like Slovakia in this study) where disseminated presentations dominate for additional diagnostic-practice review.
- Policy/payer audiences could use the antibiotic-prescribing-pattern and treatment-duration data (by country and by EM vs. disseminated presentation) to compare real-world prescribing against national guidelines and identify unusually long courses (up to 93 days) warranting guideline-adherence review, while recognizing this document provides no cost data to translate duration into direct medical expenditure.
- Patient/advocate audiences could use the reported time-to-diagnosis ranges (13-39 days depending on manifestation) and previous-LB-history prevalence (35.6% of enrolled cases) to understand how common diagnostic delay and repeat/relapsing presentations were in this cohort, while noting the study reports no cost, income-loss, or caregiving-burden data to quantify the resulting financial impact.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 122 Lyme-related terms (for example, "Lyme", "Borreliosis", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Halsby 2026.pdf

PARAMETERS (7)
--------------
- Mean diagnostic delay, erythema migrans cases (days), default 13.4, source: Section 3.4, p.8
- Mean diagnostic delay, disseminated disease cases (days), default 24.9, source: Section 3.4, p.8
- Mean diagnostic delay, other/unclassified manifestation cases (days), default 38.5, source: Section 3.4, p.8
- Lyme-arthritis share of cases, Slovakia (%), default 76.3, source: Abstract; Discussion, p.10-11
- Lyme-arthritis share of cases, other five BOLD countries (%), default 3.5, source: Abstract, p.1 (narrative comparison figure)
- Mean antibiotic treatment duration (days), default 15, source: Table 2, p.9-10
- Share of enrolled cases with a prior Lyme borreliosis episode (%), default 35.6, source: Section 3.1, p.4

OUTPUTS (5)
-----------
- Disseminated minus EM mean diagnostic delay (positive = disseminated cases diagnosed slower than EM; negative = disseminated cases diagnosed faster): 11.5 (days) at default assumptions
- Other/unclassified minus EM mean diagnostic delay (positive = other-manifestation cases diagnosed slower than EM; negative = faster): 25.1 (days) at default assumptions
- Slovakia minus other-countries Lyme-arthritis share (percentage points; positive = Slovakia had a higher Lyme-arthritis share than the other five countries; negative = lower): 72.8 (percentage points) at default assumptions
- Share of enrolled cases with a prior Lyme borreliosis episode: 35.6 (%) at default assumptions
- Typical (mean) antibiotic treatment duration: 15 (days) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 371 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicare_part_d_lyme_antibiotics_2024.csv, scope: lyme)
- cms/lyme_cost_benchmarks_2024  (unit cms/lyme_cost_benchmarks_2024/medicaid_lyme_antibiotics_2024.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)

ORIGINAL SOURCE
---------------
Halsby K et al. Clinical Manifestations of Lyme Borreliosis in Europe: Burden of Lyme Disease Study (BOLD), 2021-2022. Pathogens. 2026
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41901780/
  DOI: https://doi.org/10.3390/pathogens15030327

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.