================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : rkY6j03coupITjH6tz2gIGU3
    Generated   : 2026-10-05 20:15:33 UTC
================================================================

TITLE
-----
Lyme Disease Diagnostic Delay and Guideline-Linked Coverage Denial (Johnson, Aylward & Stricker, 2011 Survey)

BOUNDARY
--------
This simulation reproduces self-reported percentages from a 2009-2010 web survey of 2424 U.S. residents with clinically diagnosed, laboratory-supported chronic Lyme disease (symptoms ≥6 months despite ≥21 days of antibiotics), recruited through a patient-advocacy organization. It covers diagnostic-delay comparisons between two lab-confirmation subgroups, insurance-denial rate, and guideline-linked disability-denial rate. It omits all dollar costs, income loss, and caregiving time, since the survey itself collected none; it cannot be generalized to acute/early Lyme disease patients (excluded by design) or pooled with CDC surveillance counts or other external studies cited in the document.

ABOUT THE SOURCE DOCUMENT
-------------------------
This 2011 Health Policy study surveyed 2424 U.S. residents with clinically diagnosed, laboratory-supported chronic Lyme disease (symptoms ≥6 months despite ≥21 days of antibiotics) about their path to diagnosis, access to healthcare, and illness burden. Half of respondents saw at least seven physicians before being diagnosed, nearly half had been ill more than 10 years, and a majority who sought hospital care reported difficulty obtaining treatment. The survey also documents insurance denials, disability-benefit denials tied to a particular medical society's guidelines, and frequent emergency-room use. The authors argue these patterns reflect restrictive guideline-driven barriers to care rather than a full accounting of dollar costs, since the survey itself did not collect direct cost, income-loss, or caregiving-time data.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help patients/advocates understand how common extensive diagnostic delay, travel burden, hospital-access difficulty, and insurance/disability denial are among people with chronic, laboratory-supported Lyme disease, though it cannot generate dollar-cost estimates since none were collected here. Care-delivery teams could use the physician-visit and ER-utilization patterns to anticipate care-coordination and repeat-visit burden in this patient population. Payers and policy audiences could use the insurance-denial and guideline-linked disability-denial rates to examine how adherence to a single society's treatment guidelines affects coverage and benefit determinations, informing debates about guideline pluralism and appeals processes.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients/advocates could use the survey's diagnostic-delay and travel-burden percentages to contextualize their own experience against a large (though non-random) patient sample, understanding this is self-reported burden data, not a national epidemiological estimate.
- Payers/policy audiences could use the disability-benefit and insurance-denial rates tied to guideline non-conformity to evaluate the practical consequences of using a single clinical guideline as an eligibility criterion, and to explore what-if scenarios around alternative appeals or coverage pathways.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 134 Lyme-related terms (for example, "Lyme", "Borrelia", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2011.pdf

PARAMETERS (6)
--------------
- CDC two-tier/Western-blot-positive subgroup size (respondents), default 1000, source: Fig. 2 and Results text, p.67; fixed at the document's reported subgroup size and not user-adjustable since it is the denominator for the CDC-subgroup diagnostic-delay rate.
- CDC two-tier subgroup: respondents seeing 10+ physicians (respondents), default 346, source: Fig. 2 and Results text, p.67; 300-390 range is an assumed exploration bound, chosen so the comparison direction cannot flip relative to the other-lab-test subgroup, not from the source itself.
- Other-supporting-lab-test subgroup size (respondents), default 1424, source: Fig. 2 and Results text, p.67; fixed at the document's reported subgroup size and not user-adjustable since it is the denominator for the other-lab-test subgroup diagnostic-delay rate.
- Other-lab-test subgroup: respondents seeing 10+ physicians (respondents), default 563, source: Fig. 2 and Results text, p.67; 560-650 range is an assumed exploration bound, chosen so the comparison direction cannot flip relative to the CDC two-tier subgroup, not from the source itself.
- Insurance denial rate after Lyme diagnosis (%), default 39.9, source: Table 2, p.68; 0-100 range is an assumed exploration bound, not from the source.
- Disability denial rate for IDSA guideline non-conformity (%), default 38.6, source: Table 2, p.68; 0-100 range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- CDC two-tier subgroup: rate of seeing 10+ physicians before diagnosis: 34.6 (%) at default assumptions
- Other-lab-test subgroup: rate of seeing 10+ physicians before diagnosis: 39.5365 (%) at default assumptions
- Other-lab-test subgroup minus CDC two-tier subgroup 10+-physician rate (percentage points; positive = other-lab-test subgroup had more extensive diagnostic delay, negative = CDC two-tier subgroup had more): 4.93652 (percentage points) at default assumptions
- Insurance denial rate after Lyme diagnosis: 39.9 (%) at default assumptions
- Disability denial rate for IDSA guideline non-conformity: 38.6 (%) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson L et al. Healthcare access and burden of care for patients with Lyme disease: a large United States survey. Health Policy. 2011
  PubMed: https://pubmed.ncbi.nlm.nih.gov/21676482/
  DOI: https://doi.org/10.1016/j.healthpol.2011.05.007

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.