#!/usr/bin/env python3
"""
Reference implementation: Lyme Disease Diagnostic Delay and
Guideline-Linked Coverage Denial (Johnson, Aylward & Stricker, 2011 Survey)

Standard-library-only reproduction of the interactive spec's arithmetic.
This is NOT a reproduction of the source paper's full statistical model;
it is a plain calculator over the document's reported figures and the
spec's default inputs.
"""


# ---------------------------------------------------------------------------
# Inputs (ids, labels, defaults match the spec)
# ---------------------------------------------------------------------------

def get_default_inputs():
    return {
        "cdc_two_tier_subgroup_n": 1000,
        "cdc_two_tier_10plus_count": 346,
        "other_lab_subgroup_n": 1424,
        "other_lab_10plus_count": 563,
        "insurance_denial_pct": 39.9,
        "disability_denial_pct": 38.6,
    }


# ---------------------------------------------------------------------------
# Output expressions (same arithmetic, same order, as the spec)
# ---------------------------------------------------------------------------

def compute_cdc_subgroup_10plus_rate(inputs):
    # (cdc_two_tier_10plus_count / cdc_two_tier_subgroup_n) * 100
    return (inputs["cdc_two_tier_10plus_count"] / inputs["cdc_two_tier_subgroup_n"]) * 100


def compute_other_lab_subgroup_10plus_rate(inputs):
    # (other_lab_10plus_count / other_lab_subgroup_n) * 100
    return (inputs["other_lab_10plus_count"] / inputs["other_lab_subgroup_n"]) * 100


def compute_diagnostic_delay_gap(inputs):
    # other_lab_subgroup_10plus_rate - cdc_subgroup_10plus_rate
    other_rate = compute_other_lab_subgroup_10plus_rate(inputs)
    cdc_rate = compute_cdc_subgroup_10plus_rate(inputs)
    return other_rate - cdc_rate


def compute_insurance_denial_rate(inputs):
    # direct reference to insurance_denial_pct
    return inputs["insurance_denial_pct"]


def compute_disability_denial_rate(inputs):
    # direct reference to disability_denial_pct
    return inputs["disability_denial_pct"]


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def compute_all_outputs(inputs):
    return {
        "cdc_subgroup_10plus_rate": compute_cdc_subgroup_10plus_rate(inputs),
        "other_lab_subgroup_10plus_rate": compute_other_lab_subgroup_10plus_rate(inputs),
        "diagnostic_delay_gap": compute_diagnostic_delay_gap(inputs),
        "insurance_denial_rate": compute_insurance_denial_rate(inputs),
        "disability_denial_rate": compute_disability_denial_rate(inputs),
    }


if __name__ == "__main__":
    inputs = get_default_inputs()
    outputs = compute_all_outputs(inputs)

    print("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        print(f"{k}: {v}")

    print("\n=== Outputs ===")
    print(f"cdc_subgroup_10plus_rate (%): {outputs['cdc_subgroup_10plus_rate']:.4f}")
    print(f"other_lab_subgroup_10plus_rate (%): {outputs['other_lab_subgroup_10plus_rate']:.4f}")
    print(f"diagnostic_delay_gap (percentage points): {outputs['diagnostic_delay_gap']:.4f}")
    print(f"insurance_denial_rate (%): {outputs['insurance_denial_rate']:.4f}")
    print(f"disability_denial_rate (%): {outputs['disability_denial_rate']:.4f}")