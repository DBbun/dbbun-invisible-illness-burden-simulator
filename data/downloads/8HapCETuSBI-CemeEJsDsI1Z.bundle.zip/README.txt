================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 8HapCETuSBI-CemeEJsDsI1Z
    Generated   : 2026-10-05 21:16:14 UTC
================================================================

TITLE
-----
Objective Exercise Capacity and Occupational Status in a Severe Post-COVID Condition (PCC) Cohort

BOUNDARY
--------
This simulation reflects only a German cross-sectional study of 92 severely and long-term affected post-COVID-19 condition (PCC) patients, mostly healthcare/social-service workers who had filed for occupational-disease recognition and already carried a formal ICD-10 U09.9 diagnosis, assessed by cardiopulmonary exercise testing (CPET) between July 2023 and March 2025. It covers only prevalence-style percentages reported in this specific cohort (objective CPET-based work disability, post-exertional malaise, ME/CFS status, and occupational/sick-leave status). It contains no dollar-denominated cost data of any kind, no general long-COVID population estimates, and no longitudinal or outcome-after-assessment data; none of these figures should be generalized beyond this severe, occupationally-selected, 88%-female sample.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a German cross-sectional study of 92 severely and long-term affected post-COVID-19 condition (PCC) patients, mostly healthcare and social-service workers who had filed for occupational-disease recognition, examined using cardiopulmonary exercise testing (CPET) between July 2023 and March 2025. Nearly half of the cohort met diagnostic criteria for ME/CFS, and the large majority showed objective signs of post-exertional malaise. Most patients showed markedly reduced oxygen uptake and power output on CPET, with about two-thirds meeting the study's objective thresholds for 'absolute work disability,' and these objective measures correlated with self-reported disability (Bell Disability Scale) and with whether patients were on sick leave, in work reintegration, or currently working. The document reports functional/occupational-capacity burden in this specific severe, occupationally-selected cohort; it contains no dollar-denominated medical, non-medical, or indirect cost data of any kind, and no Lyme disease content.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document would be most useful to occupational-medicine clinicians, disability/insurance evaluators (such as the BGW-type occupational-disease system in this study), and researchers designing PCC/ME/CFS rehabilitation or return-to-work pathways, since the document's core findings link objective CPET thresholds to self-reported disability and current occupational status in a severe, real-world patient population. It cannot inform direct-cost, indirect-cost, or financial-planning questions because no dollar figures are reported anywhere in the source. It is relevant to a narrow, severely affected and occupationally-selected PCC/ME/CFS subgroup, not the general Long COVID population.

WHAT YOU COULD DO WITH IT
-------------------------
- Occupational-medicine or disability-insurance review: illustrating how objective CPET thresholds (VO2peak <15 mL/min/kg, PPO <1 W/kg) relate to self-reported work status (sick leave vs. reintegration vs. working) within this specific severe, occupationally-disabled PCC cohort, to support (not replace) individualized work-capacity discussions.
- Patient/advocate and clinical education: showing how common ME/CFS features (49%) and post-exertional malaise (79%) are within a severely affected, real-world PCC cohort selected for occupational disability, to help contextualize why 'invisible' functional impairment can coexist with unremarkable organ-system test results.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 46 Long COVID-related terms (for example, "Post-COVID", "Long COVID", "U09.9"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Tomaskovic 2026.pdf

PARAMETERS (8)
--------------
- Objective CPET-based work disability rate (%), default 66.3, source: Abstract p.1 and Conclusion p.13 ('Most patients (66.3%) had a VO2peak < 15 mL/min/kg and/or a PPO < 1 W/kg'); the 0-100 range is an assumed exploration bound covering the full possible percentage, not from the source.
- Proportion currently on medical sick leave (%), default 75, source: p.10 'Occupational Status in Relation to Functional Capacity' (69/92 patients); 0-100 range is an assumed exploration bound, not from the source.
- Proportion in occupational work reintegration (%), default 12, source: p.10 'Occupational Status in Relation to Functional Capacity' (11/92 patients); 0-100 range is an assumed exploration bound, not from the source.
- Proportion currently working (%), default 13, source: p.10 'Occupational Status in Relation to Functional Capacity' (12/92 patients); 0-100 range is an assumed exploration bound, not from the source.
- ME/CFS prevalence within this PCC cohort (%), default 49, source: p.7 'Clinical Profile' (45/92 patients meeting Canadian Consensus Criteria); 0-100 range is an assumed exploration bound, not from the source.
- Post-exertional malaise (PEM) positive screen rate (%), default 79, source: p.7 'Clinical Profile' (71/92 patients, DSQ-PEM questionnaire); 0-100 range is an assumed exploration bound, not from the source.
- Multimorbidity share among ME/CFS-positive patients (%), default 67, source: p.7 'Clinical Profile' (30/45 ME/CFS-positive patients with ≥3 comorbidities or ≥1 severe comorbidity); 0-100 range is an assumed exploration bound, not from the source.
- Multimorbidity share among non-ME/CFS patients (%), default 45, source: p.7 'Clinical Profile' (21/47 non-ME/CFS patients with ≥3 comorbidities or ≥1 severe comorbidity); 0-100 range is an assumed exploration bound, not from the source.

OUTPUTS (4)
-----------
- Objective CPET-based work disability rate (display): 66.3 (%) at default assumptions
- Combined share in work reintegration or currently working: 25 (%) at default assumptions
- Objective CPET disability rate minus sick-leave rate (positive = more patients meet the objective disability threshold than are formally on sick leave; negative = more patients are on sick leave than meet the objective threshold): -8.7 (percentage points) at default assumptions
- Multimorbidity share, ME/CFS-positive minus non-ME/CFS patients (positive = ME/CFS group had a higher multimorbidity share; negative = lower): 22 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::3::Code Descriptions/icd10cm_codes_2026.txt, scope: both)

ORIGINAL SOURCE
---------------
Tomaskovic A et al. Cardiopulmonary Exercise Testing Reveals Functional Limitations and Work Disability in Severe Post-COVID-19 and ME/CFS Patients. Sports Med Open. 2026
  PubMed: https://pubmed.ncbi.nlm.nih.gov/42043742/
  DOI: https://doi.org/10.1186/s40798-026-00995-1

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.