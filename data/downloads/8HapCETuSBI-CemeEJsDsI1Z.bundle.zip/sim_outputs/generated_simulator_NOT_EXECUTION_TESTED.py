#!/usr/bin/env python3
"""
Reference implementation (standard library only) of the spec:
"Objective Exercise Capacity and Occupational Status in a Severe
Post-COVID Condition (PCC) Cohort"

This script reproduces exactly the arithmetic defined in the spec's
`inputs` and `outputs` sections, using the same default values.
It performs no sampling, no synthetic patient generation, and
produces no plots or files.
"""


def compute_outputs(inputs):
    """Compute all spec outputs from a dict of input values."""

    work_disability_rate = inputs["work_disability_rate"]
    sick_leave_rate = inputs["sick_leave_rate"]
    reintegration_rate = inputs["reintegration_rate"]
    working_rate = inputs["working_rate"]
    mecfs_multimorbidity_rate = inputs["mecfs_multimorbidity_rate"]
    non_mecfs_multimorbidity_rate = inputs["non_mecfs_multimorbidity_rate"]

    # work_disability_percentage = work_disability_rate * 1
    work_disability_percentage = work_disability_rate * 1

    # work_engagement_share = reintegration_rate + working_rate
    work_engagement_share = reintegration_rate + working_rate

    # disability_administrative_gap = work_disability_rate - sick_leave_rate
    disability_administrative_gap = work_disability_rate - sick_leave_rate

    # mecfs_multimorbidity_gap = mecfs_multimorbidity_rate - non_mecfs_multimorbidity_rate
    mecfs_multimorbidity_gap = (
        mecfs_multimorbidity_rate - non_mecfs_multimorbidity_rate
    )

    return {
        "work_disability_percentage": work_disability_percentage,
        "work_engagement_share": work_engagement_share,
        "disability_administrative_gap": disability_administrative_gap,
        "mecfs_multimorbidity_gap": mecfs_multimorbidity_gap,
    }


def default_inputs():
    """Return the default input values exactly as specified."""
    return {
        "work_disability_rate": 66.3,
        "sick_leave_rate": 75,
        "reintegration_rate": 12,
        "working_rate": 13,
        "mecfs_prevalence": 49,
        "pem_positive_rate": 79,
        "mecfs_multimorbidity_rate": 67,
        "non_mecfs_multimorbidity_rate": 45,
    }


if __name__ == "__main__":
    inputs = default_inputs()
    outputs = compute_outputs(inputs)

    print("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        print(f"{k}: {v}")

    print()
    print("=== Outputs ===")
    print(
        "work_disability_percentage (%): "
        f"{outputs['work_disability_percentage']}"
    )
    print(
        "work_engagement_share (%): "
        f"{outputs['work_engagement_share']}"
    )
    print(
        "disability_administrative_gap (percentage points): "
        f"{outputs['disability_administrative_gap']}"
    )
    print(
        "mecfs_multimorbidity_gap (percentage points): "
        f"{outputs['mecfs_multimorbidity_gap']}"
    )