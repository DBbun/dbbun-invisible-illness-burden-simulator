#!/usr/bin/env python3
"""
Reference implementation of the Lyme Disease Diagnosis Frequency spec:
Claims-Based Estimate vs. Surveillance Counts (Kugeler et al., CDC dispatch).

Standard library only. Computes the three outputs defined in the spec
from the default inputs. No synthetic patients, no sampling, no plots.
"""

# ---------------------------------------------------------------------------
# Inputs (id -> default value), per spec "inputs" section
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "standardized_annual_count": 205000,      # patients/year
    "undercoding_correction_factor": 2.33,    # multiplier
    "surveillance_cases_per_year": 35000,     # cases/year
    "low_incidence_share_claims": 19,         # percent
    "low_incidence_share_surveillance": 5,    # percent
}

# ---------------------------------------------------------------------------
# Scenario overrides, per spec "scenarios" section (kept for reference;
# not auto-run in __main__, which uses default inputs only).
# ---------------------------------------------------------------------------

SCENARIOS = {
    "minimum_undercoding_correction": {"undercoding_correction_factor": 1.5},
    "maximum_undercoding_correction": {"undercoding_correction_factor": 3.5},
    "surveillance_range_low": {"surveillance_cases_per_year": 30000},
    "surveillance_range_high": {"surveillance_cases_per_year": 40000},
    "equalized_geographic_pattern": {"low_incidence_share_claims": 5},
    "higher_geographic_concentration": {"low_incidence_share_claims": 30},
}


def compute_outputs(inputs):
    """
    Compute the three spec outputs from a dict of input values, using
    exactly the expressions defined in the spec.
    """

    # diagnosed_and_treated_estimate = standardized_annual_count * undercoding_correction_factor
    diagnosed_and_treated_estimate = (
        inputs["standardized_annual_count"] * inputs["undercoding_correction_factor"]
    )

    # diagnosed_vs_surveillance_gap = diagnosed_and_treated_estimate - surveillance_cases_per_year
    diagnosed_vs_surveillance_gap = (
        diagnosed_and_treated_estimate - inputs["surveillance_cases_per_year"]
    )

    # geographic_diagnosis_share_difference =
    #     low_incidence_share_claims - low_incidence_share_surveillance
    geographic_diagnosis_share_difference = (
        inputs["low_incidence_share_claims"]
        - inputs["low_incidence_share_surveillance"]
    )

    return {
        "diagnosed_and_treated_estimate": diagnosed_and_treated_estimate,
        "diagnosed_vs_surveillance_gap": diagnosed_vs_surveillance_gap,
        "geographic_diagnosis_share_difference": geographic_diagnosis_share_difference,
    }


OUTPUT_LABELS = {
    "diagnosed_and_treated_estimate": (
        "Estimated annual diagnosed-and-treated Lyme cases (patients/year)"
    ),
    "diagnosed_vs_surveillance_gap": (
        "Claims-based estimate minus surveillance-reported cases "
        "(patients/year; positive = claims-based estimate higher)"
    ),
    "geographic_diagnosis_share_difference": (
        "Low-incidence-state diagnosis share difference "
        "(percentage points; positive = claims-based more concentrated "
        "in low-incidence states)"
    ),
}


def run(inputs=None):
    """Merge provided overrides onto the defaults and compute outputs."""
    merged = dict(DEFAULT_INPUTS)
    if inputs:
        merged.update(inputs)
    return merged, compute_outputs(merged)


if __name__ == "__main__":
    used_inputs, results = run()

    print("=== Inputs (defaults) ===")
    for key, value in used_inputs.items():
        print(f"{key}: {value}")

    print()
    print("=== Outputs ===")
    for key in (
        "diagnosed_and_treated_estimate",
        "diagnosed_vs_surveillance_gap",
        "geographic_diagnosis_share_difference",
    ):
        print(f"{OUTPUT_LABELS[key]}: {results[key]}")