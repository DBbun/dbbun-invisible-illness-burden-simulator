================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : sgx1UxHhyd9Q3mC6fqIRhMWz
    Generated   : 2026-10-10 15:22:04 UTC
================================================================

TITLE
-----
Lyme Disease Diagnosis Frequency: Claims-Based Estimate vs. Surveillance Counts

BOUNDARY
--------
This simulator models only the case-frequency correction pipeline reported in Kugeler et al. (CDC dispatch, using 2010-2018 MarketScan commercial insurance claims data): a standardized, age-corrected count of people diagnosed and treated for Lyme disease, adjusted by a correction factor for missing diagnosis codes, compared against the much smaller national surveillance case count. It does not include dollar costs, treatment duration, diagnostic delay, caregiving burden, or productivity loss, because the source document reports none of these. The claims-based estimate is built from privately insured US residents under 65 (MarketScan) before standardization to the full US population, so it does not directly represent Medicare, Medicaid, or uninsured populations. The document states that the gap between its estimate and surveillance counts reflects an unseparated combination of real underreporting and clinical overdiagnosis/overtreatment; this simulator preserves that ambiguity rather than resolving it.

ABOUT THE SOURCE DOCUMENT
-------------------------
This CDC dispatch estimates how many people in the United States were actually diagnosed and treated for Lyme disease each year from 2010 to 2018, using commercial insurance claims data rather than relying only on cases reported to public health surveillance. After adjusting the claims data for the population not covered by the insurance database (people 65+) and for the fact that medical records often omit the specific Lyme billing code, the authors estimate about 476,000 people were diagnosed and treated annually - roughly 14 times higher than the ~30,000-40,000 cases reported through official surveillance each year. The authors are explicit that this gap reflects a combination of real underreporting of infections and clinical overdiagnosis/overtreatment, and that their data cannot separate how much each contributes. The paper reports no dollar costs, no information on treatment duration, delay to diagnosis, caregiving burden, or indirect/productivity costs - it is a pure case-frequency/diagnosis-count study.

WHY THIS COULD BE USEFUL
------------------------
This document gives a model-based estimate of how many people are clinically diagnosed and treated for Lyme disease each year, which is far larger than the number captured by official surveillance - useful for patients/advocates wanting context on how undercounted their condition's true diagnostic frequency may be, for care delivery teams gauging real clinical workload versus surveillance-reported caseloads, and for payers/policy audiences assessing the scale of a diagnostic and coding gap. Because the document contains no cost, delay, or outcome data, any simulator built from it can only model case-frequency scenarios (e.g., applying different correction-factor assumptions) and cannot by itself produce dollar burden estimates without pairing it with a separate cost-per-case source. It also usefully illustrates, for a simulator's methodology layer, how claims-based and surveillance-based counts diverge and why their gap cannot be cleanly attributed to one cause.

WHAT YOU COULD DO WITH IT
-------------------------
- Let a user toggle between the raw claims-based count, the population-standardized count, and the final undercoding-corrected estimate to see how each modeling assumption (age correction, code-undercounting correction) changes the estimated annual number of diagnosed Lyme cases, without implying any one of these is 'the true' case count.
- Let a policy-focused user compare the surveillance-reported case range (~30,000-40,000/year) against the claims-based diagnosed-and-treated estimate (~476,000/year) side by side, with the simulator explicitly preserving the document's own caveat that the gap reflects an unseparated combination of underreporting and overdiagnosis.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 45 Lyme-related terms (for example, "Lyme", "Borrelia", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Kugeler 2021.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Standardized annual diagnosed-and-treated count (patients/year), default 205000, source: Kugeler et al., page 617; 150,000-260,000 range is an assumed exploration bound, not from the source
- Undercoding correction factor (multiplier), default 2.33, source: Kugeler et al., page 617; 1.5-3.5 range is an assumed exploration bound, not from the source
- Surveillance-reported Lyme cases per year (cases/year), default 35000, source: Kugeler et al., page 616 (range) and page 618 (~35,000 figure); 30,000-40,000 range reflects the document's own stated range
- Low-incidence-state share of claims-based diagnoses (percent), default 19, source: Kugeler et al., page 618; 5-30 range is an assumed exploration bound, not from the source
- Typical low-incidence-state share in surveillance (percent), default 5, source: Kugeler et al., page 618; 2-10 range is an assumed exploration bound, not from the source

OUTPUTS (3)
-----------
- Estimated annual diagnosed-and-treated Lyme cases: 477,650 (patients/year) at default assumptions
- Claims-based estimate minus surveillance-reported cases (positive = claims-based estimate higher): 442,650 (patients/year) at default assumptions
- Low-incidence-state diagnosis share difference (claims-based minus surveillance; positive = claims-based more concentrated in low-incidence states): 14 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 436 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Kugeler KJ et al. Estimating the Frequency of Lyme Disease Diagnoses, United States, 2010-2018. Emerg Infect Dis. 2021
  PubMed: https://pubmed.ncbi.nlm.nih.gov/33496229/
  DOI: https://doi.org/10.3201/eid2702.202731

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.