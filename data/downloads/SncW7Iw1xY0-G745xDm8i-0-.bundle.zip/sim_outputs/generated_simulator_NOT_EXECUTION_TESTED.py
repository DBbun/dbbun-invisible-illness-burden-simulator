#!/usr/bin/env python3
"""
Long COVID Quality-of-Life Burden Simulator (OpenPROMPT UK Cohort)

Reference implementation of the spec's arithmetic only. Standard library only.
This is not a reproduction of the source paper's full statistical model -
it simply recomputes the stated output expressions from the stated inputs.
"""


def compute_outputs(
    qalm_self_report_long_covid=0.81,
    qalm_no_long_covid=0.44,
    eq5d_utility_long_covid=0.49,
    eq5d_utility_no_long_covid=0.71,
    self_report_prevalence_pct=24.6,
    ehr_diagnosis_prevalence_pct=6,
    unadjusted_odds_ratio=4.7,
    adjusted_odds_ratio=1.46,
):
    """Compute all spec-defined outputs from the given inputs (defaults match spec)."""

    # qalm_loss_difference = qalm_self_report_long_covid - qalm_no_long_covid
    qalm_loss_difference = qalm_self_report_long_covid - qalm_no_long_covid

    # eq5d_utility_gap = eq5d_utility_no_long_covid - eq5d_utility_long_covid
    eq5d_utility_gap = eq5d_utility_no_long_covid - eq5d_utility_long_covid

    # prevalence_measurement_gap = self_report_prevalence_pct - ehr_diagnosis_prevalence_pct
    prevalence_measurement_gap = self_report_prevalence_pct - ehr_diagnosis_prevalence_pct

    # unadjusted_odds_ratio_output = unadjusted_odds_ratio (passthrough)
    unadjusted_odds_ratio_output = unadjusted_odds_ratio

    # adjusted_odds_ratio_output = adjusted_odds_ratio (passthrough)
    adjusted_odds_ratio_output = adjusted_odds_ratio

    return {
        "qalm_loss_difference": qalm_loss_difference,
        "eq5d_utility_gap": eq5d_utility_gap,
        "prevalence_measurement_gap": prevalence_measurement_gap,
        "unadjusted_odds_ratio_output": unadjusted_odds_ratio_output,
        "adjusted_odds_ratio_output": adjusted_odds_ratio_output,
    }


if __name__ == "__main__":
    # Default inputs, exactly as specified in the spec's "default" fields
    defaults = {
        "qalm_self_report_long_covid": 0.81,
        "qalm_no_long_covid": 0.44,
        "eq5d_utility_long_covid": 0.49,
        "eq5d_utility_no_long_covid": 0.71,
        "self_report_prevalence_pct": 24.6,
        "ehr_diagnosis_prevalence_pct": 6,
        "unadjusted_odds_ratio": 4.7,
        "adjusted_odds_ratio": 1.46,
    }

    results = compute_outputs(**defaults)

    print("Long COVID Quality-of-Life Burden Simulator (OpenPROMPT UK Cohort)")
    print("=" * 70)
    print("\nInputs (defaults):")
    for k, v in defaults.items():
        print(f"  {k}: {v}")

    print("\nOutputs:")
    print(
        "  qalm_loss_difference (QALM, self-report LC group minus no-LC group): "
        f"{results['qalm_loss_difference']:.4f}"
    )
    print(
        "  eq5d_utility_gap (utility points, no-LC group minus self-report LC group): "
        f"{results['eq5d_utility_gap']:.4f}"
    )
    print(
        "  prevalence_measurement_gap (percentage points, self-report minus EHR-coded): "
        f"{results['prevalence_measurement_gap']:.4f}"
    )
    print(
        "  unadjusted_odds_ratio_output (OR, self-report LC vs not, unadjusted model): "
        f"{results['unadjusted_odds_ratio_output']:.4f}"
    )
    print(
        "  adjusted_odds_ratio_output (OR, self-report LC vs not, adjusted for "
        f"breathlessness and fatigue): {results['adjusted_odds_ratio_output']:.4f}"
    )