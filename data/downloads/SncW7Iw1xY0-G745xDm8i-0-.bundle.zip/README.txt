================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : SncW7Iw1xY0-G745xDm8i-0-
    Generated   : 2026-10-05 21:16:22 UTC
================================================================

TITLE
-----
Long COVID Quality-of-Life Burden Simulator (OpenPROMPT UK Cohort)

BOUNDARY
--------
This simulates only the health-related quality-of-life (HRQoL) burden measures reported in the OpenPROMPT UK cohort study (Carlile et al. 2024): EQ-5D-5L utility scores, quality-adjusted life-months (QALM) lost (complete-case analysis), odds ratios for reporting HRQoL loss, and the gap between self-reported and EHR-coded Long COVID prevalence in the same cohort. It does not include any monetary cost, workforce-productivity, or caregiving-burden estimate, since the document itself reports none of these in currency terms. A sex/gender skew is noted in documentation (women were 70% of the self-reported Long COVID group vs. 61% of the overall cohort) but is not separately modeled as an input.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed UK study (OpenPROMPT) that measured how much Long COVID reduces health-related quality of life using patient-reported surveys (EQ-5D-5L) linked to electronic health records. Among 6070 study participants, 24.6% self-reported Long COVID, but only about 6% (described elsewhere in the paper as 'fewer than 10%') had a Long COVID diagnosis recorded in their EHR, showing a large gap between lived experience and formally coded diagnoses. People who self-reported Long COVID had substantially worse quality-of-life scores than those who did not, with losses described in quality-adjusted life-months (QALMs) and compared, in the Discussion, to conditions such as heart failure, multiple sclerosis, and end-stage renal disease. The study reports no direct medical, non-medical, or monetary cost figures - its burden measures are entirely in quality-of-life (QALY/QALM, EQ-5D utility, odds-ratio) terms, not dollars or pounds.

WHY THIS COULD BE USEFUL
------------------------
This OpenPROMPT study provides UK population-based, non-monetized evidence on how much self-reported Long COVID degrades health-related quality of life (via EQ-5D-5L, QALM loss, and odds ratios), and documents a substantial gap between self-reported Long COVID (24.6%) and EHR-coded diagnosis (6%, or 'fewer than 10%') within the same cohort. A simulator built from it could help patients/advocates contextualize the severity of Long COVID symptom burden against other chronic conditions (e.g., heart failure, MS, renal disease), help care-delivery teams understand how much self-reported burden may be invisible to EHR-based surveillance, and help payers/policymakers gauge the scale of HRQoL loss relevant to resource-allocation discussions - but it cannot itself answer monetary cost-of-illness questions, since the document reports no direct medical, non-medical, or indirect cost figures in currency terms.

WHAT YOU COULD DO WITH IT
-------------------------
- Illustrate for policymakers/payers the magnitude of HRQoL loss (QALM, disutility, EQ-5D utility gap versus conditions like heart failure/MS/end-stage renal disease) attributable to self-reported Long COVID, to inform HRQoL-focused (not monetary cost-based) prioritization discussions.
- Help care-delivery teams and researchers understand that EHR/diagnosis-code-based Long COVID counts (6%, or 'fewer than 10%' here) substantially undercount self-reported symptom burden (24.6%) in the same population, informing how claims/EHR-based surveillance figures should be interpreted alongside patient-reported outcomes.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 129 Long COVID-related terms (for example, "long COVID", "post COVID", "post-COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Carlile 2024.pdf

PARAMETERS (8)
--------------
- QALM lost - self-reported Long COVID group (complete-case analysis) (QALM (quality-adjusted life-months lost)), default 0.81, source: Table 2, p.12; 0.5-1.2 range is an assumed exploration bound chosen to keep this value above the no-Long-COVID group's range, not from the source.
- QALM lost - no Long COVID group (complete-case analysis) (QALM (quality-adjusted life-months lost)), default 0.44, source: Table 2, p.12; 0.1-0.49 range is an assumed exploration bound chosen to keep this value below the self-reported Long COVID group's range, not from the source.
- Mean EQ-5D-5L utility score - self-reported Long COVID group (utility score (0-1 scale)), default 0.49, source: Discussion, p.12; 0.2-0.6 range is an assumed exploration bound chosen to keep this value below the no-Long-COVID group's range, not from the source.
- Mean EQ-5D-5L utility score - no Long COVID group (utility score (0-1 scale)), default 0.71, source: Discussion, p.12; 0.61-0.9 range is an assumed exploration bound chosen to keep this value above the Long COVID group's range, not from the source.
- Self-reported Long COVID prevalence in cohort (%), default 24.6, source: Results, p.7; Table 1, p.6-7; 15-40 range is an assumed exploration bound chosen to keep this value above the EHR-coded diagnosis range, not from the source.
- EHR-coded Long COVID diagnosis prevalence in cohort (%), default 6, source: Results, p.7; Discussion, p.13; 2-14 range is an assumed exploration bound chosen to keep this value below the self-reported prevalence range, not from the source.
- Odds ratio of HRQoL loss, self-reported Long COVID vs not (unadjusted model) (odds ratio), default 4.7, source: Abstract, p.1 (95% CI used as the exploration range).
- Odds ratio of HRQoL loss, self-reported Long COVID vs not (adjusted for breathlessness and fatigue) (odds ratio), default 1.46, source: Results, p.9 (95% CI used as the exploration range).

OUTPUTS (5)
-----------
- QALM-lost difference: self-reported Long COVID group minus no-Long-COVID group (positive = Long COVID group lost more quality-adjusted life-months; negative would mean the no-Long-COVID group lost more): 0.37 (QALM (quality-adjusted life-months)) at default assumptions
- EQ-5D-5L utility gap: no-Long-COVID group minus self-reported Long COVID group (positive = Long COVID group has lower health-related quality of life; negative would mean the Long COVID group scored higher): 0.22 (utility points (0-1 scale)) at default assumptions
- Self-reported minus EHR-coded Long COVID prevalence (percentage points; positive = more people self-report Long COVID than have a matching diagnosis code in their health record; negative would mean more people have a diagnosis code than self-report): 18.6 (percentage points) at default assumptions
- Odds ratio of reporting any HRQoL loss, self-reported Long COVID vs not (unadjusted model): 4.7 (odds ratio) at default assumptions
- Odds ratio of reporting any HRQoL loss, self-reported Long COVID vs not (adjusted for breathlessness and fatigue scores): 1.46 (odds ratio) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened; see provenance-and-review.json for full retrieval scoring detail.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::310::SAGDP6_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle06_PUF_CSV.zip::0::hps_04_01_06_puf.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week52_PUF_CSV.zip::1::pulse2022_puf_52.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle04_PUF_CSV.zip::0::hps_04_01_04_puf.csv, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week54_PUF_CSV.zip::1::pulse2023_puf_54.csv, scope: long_covid)

ORIGINAL SOURCE
---------------
Carlile O et al. Impact of long COVID on health-related quality-of-life: an OpenSAFELY population cohort study using patient-reported outcome measures (OpenPROMPT). Lancet Reg Health Eur. 2024
  PubMed: https://pubmed.ncbi.nlm.nih.gov/38689605/
  DOI: https://doi.org/10.1016/j.lanepe.2024.100908

FILES IN THIS BUNDLE
---------------------
Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
provenance-and-review.json   - complete audit trail: every model call, its
                               token usage, and review status
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/                       - everything actually sent to the model: your
                               uploaded document(s), plus
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
federal_sources/             - the raw federal data/document files those
                               summaries were built from (reference/
                               verification material, not itself model input)
sim_outputs/                 - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.