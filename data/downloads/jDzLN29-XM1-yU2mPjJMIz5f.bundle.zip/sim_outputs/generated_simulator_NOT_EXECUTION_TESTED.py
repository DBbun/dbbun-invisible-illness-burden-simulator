#!/usr/bin/env python3
"""
2022 NHIS Long COVID Prevalence Explorer

Reference implementation of the interactive spec. This script represents
only self-reported "ever had" and "currently have" Long COVID prevalence
percentages among U.S. adults from the 2022 National Health Interview
Survey (NCHS Data Brief No. 480), broken out by sex, age group, and
race/Hispanic origin. It does not represent and cannot be used to estimate
any dollar cost, financial burden, healthcare utilization, diagnostic
delay, or caregiving burden, because the source document reports none of
these.
"""

# -----------------------------
# Default inputs (from spec)
# -----------------------------

DEFAULT_INPUTS = {
    "national_ever_prevalence": 6.9,
    "national_current_prevalence": 3.4,
    "women_ever_prevalence": 8.5,
    "men_ever_prevalence": 5.2,
    "age_3549_ever_prevalence": 8.9,
    "age_65plus_ever_prevalence": 4.1,
    "hispanic_ever_prevalence": 8.3,
    "asian_ever_prevalence": 2.6,
}


def compute_outputs(inputs):
    """Compute all spec outputs from a dict of input values."""

    sex_gap_ever = inputs["women_ever_prevalence"] - inputs["men_ever_prevalence"]

    age_gap_ever = (
        inputs["age_3549_ever_prevalence"] - inputs["age_65plus_ever_prevalence"]
    )

    race_gap_ever = (
        inputs["hispanic_ever_prevalence"] - inputs["asian_ever_prevalence"]
    )

    current_share_of_ever = (
        inputs["national_current_prevalence"] / inputs["national_ever_prevalence"]
    )

    return {
        "sex_gap_ever": sex_gap_ever,
        "age_gap_ever": age_gap_ever,
        "race_gap_ever": race_gap_ever,
        "current_share_of_ever": current_share_of_ever,
    }


def run_scenario(base_inputs, overrides):
    """Apply overrides on top of base inputs and compute outputs."""
    scenario_inputs = dict(base_inputs)
    scenario_inputs.update(overrides)
    return scenario_inputs, compute_outputs(scenario_inputs)


SCENARIOS = {
    "amplified_sex_gap": {"women_ever_prevalence": 9.5, "men_ever_prevalence": 3.0},
    "narrowed_sex_gap": {"women_ever_prevalence": 7.0, "men_ever_prevalence": 6.5},
    "amplified_age_gap": {
        "age_3549_ever_prevalence": 10.0,
        "age_65plus_ever_prevalence": 3.0,
    },
    "amplified_race_gap": {"hispanic_ever_prevalence": 9.5, "asian_ever_prevalence": 1.5},
    "higher_current_share": {
        "national_ever_prevalence": 8.5,
        "national_current_prevalence": 4.5,
    },
    "lower_current_share": {
        "national_ever_prevalence": 5.5,
        "national_current_prevalence": 2.5,
    },
}


if __name__ == "__main__":
    print("2022 NHIS Long COVID Prevalence Explorer")
    print("=" * 50)
    print()
    print("Default inputs:")
    for key, value in DEFAULT_INPUTS.items():
        print(f"  {key}: {value}")
    print()

    default_outputs = compute_outputs(DEFAULT_INPUTS)

    print("Default outputs:")
    print(f"  sex_gap_ever (women - men, pct points): {default_outputs['sex_gap_ever']:.4f}")
    print(f"  age_gap_ever (35-49 - 65+, pct points): {default_outputs['age_gap_ever']:.4f}")
    print(f"  race_gap_ever (Hispanic - Asian non-Hispanic, pct points): {default_outputs['race_gap_ever']:.4f}")
    print(f"  current_share_of_ever (fraction): {default_outputs['current_share_of_ever']:.6f}")
    print()

    print("Scenario outputs:")
    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs, scenario_outputs = run_scenario(DEFAULT_INPUTS, overrides)
        print(f"  Scenario: {scenario_id}")
        print(f"    overrides: {overrides}")
        print(
            f"    sex_gap_ever: {scenario_outputs['sex_gap_ever']:.4f}, "
            f"age_gap_ever: {scenario_outputs['age_gap_ever']:.4f}, "
            f"race_gap_ever: {scenario_outputs['race_gap_ever']:.4f}, "
            f"current_share_of_ever: {scenario_outputs['current_share_of_ever']:.6f}"
        )
        print()