================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : jDzLN29-XM1-yU2mPjJMIz5f
    Generated   : 2026-10-08 23:29:14 UTC
================================================================

TITLE
-----
2022 NHIS Long COVID Prevalence Explorer

BOUNDARY
--------
This simulation represents only self-reported 'ever had' and 'currently have' Long COVID prevalence percentages among U.S. adults from the 2022 National Health Interview Survey (NCHS Data Brief No. 480), broken out by sex, age group, and race/Hispanic origin. It does not represent and cannot be used to estimate any dollar cost, direct or indirect financial burden, healthcare utilization, diagnostic delay, or caregiving burden, because the source document reports none of these.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a CDC/NCHS government data brief (No. 480, September 2023) reporting how many U.S. adults said they ever had or currently had Long COVID in 2022, based on the National Health Interview Survey. It breaks these percentages down by sex, age group, race and Hispanic origin, family income relative to the poverty level, and urbanization level. It does not report any dollar costs, direct or indirect financial burden, insurance/access barriers, or caregiving burden - it is strictly a self-reported prevalence survey. Long COVID is defined as self-reported symptoms lasting 3+ months after a positive test or doctor's diagnosis of COVID-19, among people who were symptomatic.

WHY THIS COULD BE USEFUL
------------------------
This document alone supports demographic-pattern analysis (who is more or less likely to report Long COVID) rather than cost modeling, since it contains no dollar figures or cost-related measures. Patients/advocates could use it to see which demographic groups (women, ages 35-49, Hispanic adults, non-metro residents, middle-income families) report higher prevalence. Care delivery teams could use the subgroup breakdowns to prioritize outreach or screening capacity planning by demographic risk pattern. Payers/policy audiences could use the national prevalence rate to estimate the scale of the affected population for program sizing, but would need to pair it with an external, appropriately-dated cost-of-illness source before estimating financial burden, since this document contains no such cost data.

WHAT YOU COULD DO WITH IT
-------------------------
- A simulator could let users explore how estimated Long COVID 'ever' or 'current' prevalence varies by sex, age group, race/Hispanic origin, income level, or urbanization level, using the document's own 2022 NHIS point estimates and confidence intervals, to understand which populations are more affected - without attaching any cost figure, since none exists in this document.
- A simulator could flag for users that population-affected estimates (e.g., applying the 6.9% national 'ever' rate to a population count) are a researcher-added extrapolation beyond what NCHS directly reports, and must be clearly labeled as assumed/projected rather than observed.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 127 Long COVID-related terms (for example, "Long COVID", "post-acute sequelae", "PASC"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
db480-tables.pdf
db480.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- National: ever had Long COVID (percent of adults), default 6.9, source: NCHS Data Brief No. 480, Key findings and Figure 1, page 1. The 5.5-8.5 range is an assumed exploration bound, not from the source, chosen to stay above the current-prevalence range below since current cases are a subset of ever cases.
- National: currently has Long COVID (percent of adults), default 3.4, source: NCHS Data Brief No. 480, Key findings and Figure 1, page 1. The 2.5-4.5 range is an assumed exploration bound, kept below the ever-prevalence range because current cases are always a subset of ever cases in this survey's design.
- Women: ever had Long COVID (percent of adults), default 8.5, source: NCHS Data Brief No. 480, Figure 1 and accompanying text, page 2. The 7.0-9.5 range is an assumed exploration bound, set above the men's range below to preserve the document's reported, statistically significant sex difference.
- Men: ever had Long COVID (percent of adults), default 5.2, source: NCHS Data Brief No. 480, Figure 1 and accompanying text, page 2. The 3.0-6.5 range is an assumed exploration bound, kept below the women's range above to preserve the document's reported sex ordering.
- Ages 35-49: ever had Long COVID (percent of adults), default 8.9, source: NCHS Data Brief No. 480, Figure 2 and accompanying text, page 2. The 7.5-10.0 range is an assumed exploration bound, set above the 65+ range below to preserve the document's reported age ordering (35-49 was the highest group, 65+ the lowest).
- Ages 65+: ever had Long COVID (percent of adults), default 4.1, source: NCHS Data Brief No. 480, Figure 2 and accompanying text, page 2. The 3.0-5.0 range is an assumed exploration bound, kept below the 35-49 range above to preserve the document's reported age ordering.
- Hispanic adults: ever had Long COVID (percent of adults), default 8.3, source: NCHS Data Brief No. 480, Figure 3 and accompanying text, page 3. The 7.0-9.5 range is an assumed exploration bound, set above the Asian non-Hispanic range below to preserve the document's reported ordering (Hispanic adults were the highest group, Asian non-Hispanic adults the lowest).
- Asian non-Hispanic adults: ever had Long COVID (percent of adults), default 2.6, source: NCHS Data Brief No. 480, Figure 3 and accompanying text, page 3. The 1.5-3.5 range is an assumed exploration bound, kept below the Hispanic adults range above to preserve the document's reported ordering.

OUTPUTS (4)
-----------
- Women's minus men's ever-prevalence (positive = women higher, negative = men higher): 3.3 (percentage points) at default assumptions
- Ages 35-49 minus ages 65+ ever-prevalence (positive = 35-49 group higher, negative = 65+ group higher): 4.8 (percentage points) at default assumptions
- Hispanic minus Asian non-Hispanic ever-prevalence (positive = Hispanic higher, negative = Asian non-Hispanic higher): 5.7 (percentage points) at default assumptions
- Current prevalence divided by ever prevalence (share of ever cases still current): 0.4928 (fraction) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle04_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle04_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle05_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle05_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle06_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle06_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-1Cycle07_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.1 Cycle07_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-2Cycle08_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.2 Cycle08_CSV.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4-2Cycle09_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.2 Cycle09_CSV .xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Week58_PUF_CSV.zip::0::pulse2023_data.dictionary_CSV_58.xlsx, scope: long_covid)
- census/household_pulse_long_covid_2022_2024  (unit census/household_pulse_long_covid_2022_2024/HPS_Phase4Cycle01_PUF_CSV.zip::2::HPS_data.dictionary_Phase 4.0 Cycle01_CSV.xlsx, scope: long_covid)

ORIGINAL SOURCE
---------------
Adjaye-Gbewonyo D, Vahratian A, Perrine CG, Bertolli J. Long COVID in adults: United States, 2022. NCHS Data Brief No. 480, National Center for Health Statistics (CDC). September 2023
  DOI: https://doi.org/10.15620/cdc:132417
  CDC page: https://www.cdc.gov/nchs/products/databriefs/db480.htm
  PDF: https://www.cdc.gov/nchs/data/databriefs/db480.pdf
  Data tables: https://www.cdc.gov/nchs/data/databriefs/db480-tables.pdf

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.