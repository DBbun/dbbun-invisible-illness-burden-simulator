================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : ZjULONFTPMLtBI66Ek91EdeG
    Generated   : 2026-10-07 21:41:21 UTC
================================================================

TITLE
-----
Long COVID Occupational Disability Cohort: CPET and Functional Status Findings (Mainz, Germany)

BOUNDARY
--------
This simulation reproduces percentages and counts reported for a single, severity-selected German occupational-disease cohort (n=92) of post-COVID-19 condition (PCC) patients evaluated with cardiopulmonary exercise testing (CPET). It does not include any medical cost, wage, insurance-payment, or caregiver-cost data, because none are reported in the document. It should not be used to estimate PCC or ME/CFS (myalgic encephalomyelitis/chronic fatigue syndrome) prevalence or disability rates in the general population.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a German clinical study of 92 patients with long-standing, severe post-COVID-19 condition (PCC), about half of whom also met criteria for ME/CFS, who were undergoing evaluation for occupational disability. Using cardiopulmonary exercise testing (CPET), the authors found that most patients had objectively reduced oxygen uptake and power output, with 66.3% meeting thresholds the authors define as 'absolute work disability,' and that these objective measures correlated with patients' self-reported disability (Bell Disability Scale) and with their actual employment status (sick leave, reintegration, or working). The study documents functional/occupational burden (persistent symptoms averaging ~24 months, high post-exertional malaise prevalence, high rates of being on sick leave) but does not report any direct medical costs, indirect monetary costs, insurance payment amounts, or caregiver costs. It is a single-cohort clinical/occupational-medicine study, not a cost-of-illness analysis, and the cohort was deliberately selected for severity and occupational-disability referral, so its percentages should not be read as general-population PCC or ME/CFS burden estimates.

WHY THIS COULD BE USEFUL
------------------------
This document supports occupational-medicine and disability-evaluation decisions for severely affected, long-standing PCC/ME-CFS patients rather than general cost-of-illness modeling, since it contains no dollar figures. Occupational physicians, workers'-compensation/disability insurers, and rehabilitation teams could use the reported CPET thresholds (VO2peak < 15 mL/min/kg, PPO < 1 W/kg) alongside the Bell Disability Scale to structure objective, non-organ-specific evaluations of work capacity. Patient advocates and clinicians could use the cohort's observed burden rates (66% objective work disability, 79% PEM positivity, 75% on sick leave) to illustrate functional burden within this specific severely-affected population, while researchers could use the explicit recruitment-bias and subgroup-disaggregation caveats to design better-stratified future PCC/ME-CFS cohorts.

WHAT YOU COULD DO WITH IT
-------------------------
- Occupational-disease evaluators and insurers (e.g., workers'-compensation assessors) could incorporate the CPET-derived VO2peak/PPO work-disability thresholds alongside subjective Bell-Score ratings into return-to-work and disability-determination protocols for severe PCC/ME-CFS, rather than relying on normal organ-centered test results alone.
- Clinicians and rehabilitation teams could use the occupational-status stratification (sick leave vs. reintegration vs. working) and its association with VO2peak/PPO to counsel patients and plan individualized, graded return-to-work pathways.
- Researchers designing future PCC/ME-CFS burden studies could use the stated recruitment-bias caveats (severity-selected, occupational-disease-referral, 88% female cohort) to decide how to stratify sampling and avoid pooling this cohort's thresholds with population-based prevalence or capacity estimates from other studies.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 46 Long COVID-related terms (for example, "Post-COVID", "Long COVID", "U09.9"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Tomaskovic 2026.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Cohort size (patients), default 92, source: Cohort size (n=92) reported in Results, Clinical Profile, p.7; the 50-150 range is an assumed exploration bound, not from the source.
- Objective work-disability rate (CPET-defined) (%), default 66.3, source: 66.3% reported in Conclusion, p.14; the 0-100 range is an assumed exploration bound, not from the source.
- ME/CFS prevalence within cohort (%), default 49, source: 49% (45/92) reported in Results, Clinical Profile, p.7; the 0-100 range is an assumed exploration bound, not from the source.
- Post-exertional malaise positivity, ME/CFS subgroup (%), default 93, source: 93% reported in Results, Clinical Profile, p.7; the 0-100 range is an assumed exploration bound, not from the source.
- Post-exertional malaise positivity, non-ME/CFS subgroup (%), default 64, source: 64% reported in Results, Clinical Profile, p.7; the 0-100 range is an assumed exploration bound, not from the source.
- Share of cohort on medical sick leave (%), default 75, source: 75% (69/92) reported in Results, Occupational Status in Relation to Functional Capacity, p.10; the 0-100 range is an assumed exploration bound, not from the source.
- Share of cohort currently working (%), default 13, source: 13% (12/92) reported in Results, Occupational Status in Relation to Functional Capacity, p.10; the 0-100 range is an assumed exploration bound, not from the source.
- Share scoring ≤30 on Bell Disability Scale (%), default 48.9, source: 48.9% (of n=88 responders) reported in Results, Association Between CPET and Bell Disability Scale, p.10; the 0-100 range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- Estimated patients meeting objective work-disability threshold: 61 (patients) at default assumptions
- PEM positivity gap: ME/CFS minus non-ME/CFS subgroup (positive = ME/CFS subgroup higher; negative = non-ME/CFS subgroup higher): 29 (percentage points) at default assumptions
- Occupational-status gap: sick leave minus currently-working rate (positive = more on sick leave than working; negative = more working than on sick leave): 62 (percentage points) at default assumptions
- Self-reported moderate-to-severe disability share (Bell Scale ≤30): 48.9 (%) at default assumptions
- Estimated patients meeting ME/CFS criteria: 45.08 (patients) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bls/labor_costs_2025  (unit bls/labor_costs_2025/cpi_u_all_items_2015_2026.csv, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::3::Code Descriptions/icd10cm_codes_2026.txt, scope: both)

ORIGINAL SOURCE
---------------
Tomaskovic A et al. Cardiopulmonary Exercise Testing Reveals Functional Limitations and Work Disability in Severe Post-COVID-19 and ME/CFS Patients. Sports Med Open. 2026
  PubMed: https://pubmed.ncbi.nlm.nih.gov/42043742/
  DOI: https://doi.org/10.1186/s40798-026-00995-1

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.