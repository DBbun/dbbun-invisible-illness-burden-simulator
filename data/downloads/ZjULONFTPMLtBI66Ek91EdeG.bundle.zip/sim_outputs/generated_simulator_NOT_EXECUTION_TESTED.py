#!/usr/bin/env python3
"""
Reference implementation of the Long COVID Occupational Disability Cohort
(Mainz, Germany) CPET and Functional Status spec.

Standard library only. Reproduces the exact arithmetic defined in the
spec's "outputs" expressions using the spec's default "inputs".

This is NOT a reproduction of the source paper's statistical model; it is
a plain arithmetic reference implementation of the interactive spec.
"""

# ---------------------------------------------------------------------------
# Default inputs (from spec "inputs" -> "default")
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "cohort_size": 92,                       # patients
    "objective_work_disability_rate": 66.3,  # %
    "mecfs_prevalence": 49,                  # %
    "pem_positivity_mecfs": 93,              # %
    "pem_positivity_non_mecfs": 64,          # %
    "sick_leave_rate": 75,                   # %
    "working_rate": 13,                      # %
    "bell_score_severe_rate": 48.9,          # %
}


# ---------------------------------------------------------------------------
# Output expressions (mirroring spec "outputs" -> "expression" trees exactly)
# ---------------------------------------------------------------------------

def objective_work_disability_count(inputs):
    """multiply(cohort_size, divide(objective_work_disability_rate, 100))"""
    cohort_size = inputs["cohort_size"]
    rate = inputs["objective_work_disability_rate"]
    return cohort_size * (rate / 100)


def pem_gap_mecfs_vs_non(inputs):
    """subtract(pem_positivity_mecfs, pem_positivity_non_mecfs)"""
    return inputs["pem_positivity_mecfs"] - inputs["pem_positivity_non_mecfs"]


def sick_leave_minus_working_gap(inputs):
    """subtract(sick_leave_rate, working_rate)"""
    return inputs["sick_leave_rate"] - inputs["working_rate"]


def bell_score_severe_share(inputs):
    """ref(bell_score_severe_rate)"""
    return inputs["bell_score_severe_rate"]


def mecfs_subgroup_count(inputs):
    """multiply(cohort_size, divide(mecfs_prevalence, 100))"""
    cohort_size = inputs["cohort_size"]
    prevalence = inputs["mecfs_prevalence"]
    return cohort_size * (prevalence / 100)


# ---------------------------------------------------------------------------
# Output computation wrapper
# ---------------------------------------------------------------------------

def compute_outputs(inputs):
    return {
        "objective_work_disability_count": objective_work_disability_count(inputs),
        "pem_gap_mecfs_vs_non": pem_gap_mecfs_vs_non(inputs),
        "sick_leave_minus_working_gap": sick_leave_minus_working_gap(inputs),
        "bell_score_severe_share": bell_score_severe_share(inputs),
        "mecfs_subgroup_count": mecfs_subgroup_count(inputs),
    }


OUTPUT_LABELS = {
    "objective_work_disability_count": (
        "Estimated patients meeting objective work-disability threshold (patients)"
    ),
    "pem_gap_mecfs_vs_non": (
        "PEM positivity gap: ME/CFS minus non-ME/CFS subgroup (percentage points)"
    ),
    "sick_leave_minus_working_gap": (
        "Occupational-status gap: sick leave minus currently-working rate "
        "(percentage points)"
    ),
    "bell_score_severe_share": (
        "Self-reported moderate-to-severe disability share (Bell Scale <=30) (%)"
    ),
    "mecfs_subgroup_count": (
        "Estimated patients meeting ME/CFS criteria (patients)"
    ),
}


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("Inputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key}: {value}")

    print("\nOutputs:")
    for key, value in outputs.items():
        label = OUTPUT_LABELS.get(key, key)
        print(f"  {label}: {value}")