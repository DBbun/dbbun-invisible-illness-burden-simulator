#!/usr/bin/env python3
"""
Reference implementation of the "Chronic Lyme Disease Diagnostic Delay and
Care-Access Barriers (2009-2010 U.S. Patient Survey)" spec.

Standard library only. This script reproduces the percentage-based inputs,
outputs, and scenario overrides exactly as defined in the spec, with no
synthetic patient generation, sampling, plotting, or CLI.
"""

DEFAULT_INPUTS = {
    "physicians_seen_10plus_pct": 37.5,
    "travel_over_50_miles_pct": 49.5,
    "hospital_access_difficulty_pct": 81.7,
    "insurance_denial_pct": 39.9,
    "disability_denial_pct": 38.6,
    "er_visit_pct": 53.5,
}

SCENARIOS = {
    "diagnostic_delay_broader_threshold": {
        "label": "Broader diagnostic-delay threshold (7+ physicians)",
        "overrides": {"physicians_seen_10plus_pct": 50},
    },
    "extreme_travel_distance": {
        "label": "Extreme travel distance (500+ miles)",
        "overrides": {"travel_over_50_miles_pct": 9.0},
    },
    "frequent_er_visits": {
        "label": "Frequent ER use (6+ visits)",
        "overrides": {"er_visit_pct": 9.1},
    },
}


def compute_outputs(inputs):
    """Compute all defined outputs from a given inputs dict."""
    diagnostic_delay_output = inputs["physicians_seen_10plus_pct"]
    travel_burden_output = inputs["travel_over_50_miles_pct"]
    hospital_access_output = inputs["hospital_access_difficulty_pct"]
    insurance_vs_disability_denial_gap = (
        inputs["insurance_denial_pct"] - inputs["disability_denial_pct"]
    )
    er_visit_output = inputs["er_visit_pct"]

    return {
        "diagnostic_delay_output": diagnostic_delay_output,
        "travel_burden_output": travel_burden_output,
        "hospital_access_output": hospital_access_output,
        "insurance_vs_disability_denial_gap": insurance_vs_disability_denial_gap,
        "er_visit_output": er_visit_output,
    }


def apply_overrides(base_inputs, overrides):
    merged = dict(base_inputs)
    merged.update(overrides)
    return merged


def format_outputs(outputs):
    lines = []
    lines.append(
        f"  diagnostic_delay_output (Share seeing 10+ physicians before diagnosis): "
        f"{outputs['diagnostic_delay_output']}%"
    )
    lines.append(
        f"  travel_burden_output (Share traveling over 50 miles for treatment): "
        f"{outputs['travel_burden_output']}%"
    )
    lines.append(
        f"  hospital_access_output (Share reporting difficulty obtaining hospital "
        f"treatment): {outputs['hospital_access_output']}%"
    )
    lines.append(
        f"  insurance_vs_disability_denial_gap (Insurance denial % minus disability "
        f"denial %): {outputs['insurance_vs_disability_denial_gap']} percentage points"
    )
    lines.append(
        f"  er_visit_output (Share with at least one ER visit tied to Lyme symptoms): "
        f"{outputs['er_visit_output']}%"
    )
    return "\n".join(lines)


if __name__ == "__main__":
    print("=== Default inputs ===")
    for k, v in DEFAULT_INPUTS.items():
        print(f"  {k}: {v}")

    print("\n=== Outputs (default inputs) ===")
    default_outputs = compute_outputs(DEFAULT_INPUTS)
    print(format_outputs(default_outputs))

    print("\n=== Scenario outputs ===")
    for scenario_id, scenario in SCENARIOS.items():
        scenario_inputs = apply_overrides(DEFAULT_INPUTS, scenario["overrides"])
        scenario_outputs = compute_outputs(scenario_inputs)
        print(f"\n--- {scenario_id}: {scenario['label']} ---")
        print(f"  overrides: {scenario['overrides']}")
        print(format_outputs(scenario_outputs))