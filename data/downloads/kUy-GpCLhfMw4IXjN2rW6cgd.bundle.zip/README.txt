================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : kUy-GpCLhfMw4IXjN2rW6cgd
    Generated   : 2026-10-09 00:24:08 UTC
================================================================

TITLE
-----
Chronic Lyme Disease Diagnostic Delay and Care-Access Barriers (2009-2010 U.S. Patient Survey)

BOUNDARY
--------
This simulation reproduces percentage-based findings from a 2011 peer-reviewed web-based survey of 2,424 U.S. residents with clinically diagnosed, lab-confirmed chronic Lyme disease (symptoms persisting 6+ months despite at least 21 days of antibiotics), surveyed June 2009-March 2010. It covers diagnostic delay, travel burden, hospital-access difficulty, and insurance/disability benefit denial rates as reported by respondents. It does not include any dollar cost figures computed by this study (the study itself collected no cost data), does not include the CDC case-count/underreporting discussion, and does not break any finding down by age, sex/gender, socioeconomic status, or race/ethnicity because the authors did not collect or analyze those variables. The sample is self-selected, internet-recruited, and limited to chronic/persistent-symptom patients, excluding early or acute Lyme disease by design.

ABOUT THE SOURCE DOCUMENT
-------------------------
This 2011 peer-reviewed study reports results from a 2009-2010 web-based survey of 2,424 U.S. residents with clinically diagnosed, lab-confirmed chronic Lyme disease (symptoms persisting 6+ months despite at least 21 days of antibiotics). It documents substantial diagnostic delay (many saw 7 or more physicians before diagnosis), high travel burden for treatment, frequent difficulty obtaining hospital care, insurance denials and insurer-imposed restrictions tied to contested clinical guidelines, high rates of disability-benefit applications and denials, and frequent emergency-room use. The authors argue these patterns reflect the influence of one medical society's (IDSA) restrictive Lyme treatment guidelines on hospital protocols, insurance coverage, and disability determinations. The study does not itself calculate dollar costs; it cites an external 2006 cost-of-illness study (Zhang et al.) for context. Its sample is self-selected and non-random, limited to chronic/persistent-symptom patients, and not broken down by age, gender, socioeconomic status, or ethnicity.

WHY THIS COULD BE USEFUL
------------------------
This document could inform patients/advocates by quantifying how common extensive diagnostic delay, travel burden, and insurance/disability denial are among people with chronic Lyme disease, helping set realistic expectations and advocacy priorities. Care delivery teams could use the diagnostic-delay and hospital-access-difficulty figures to benchmark their own referral and treatment patterns against this patient-reported national sample. Payers/policy audiences could use the insurance-denial and disability-benefit-denial percentages tied to guideline non-conformity to examine how clinical practice guideline disputes translate into coverage and benefit access barriers. All uses must respect that this is a self-selected, chronic-illness-only survey sample without age/gender/SES breakdowns and with no document-derived dollar costs.

WHAT YOU COULD DO WITH IT
-------------------------
- Patients and advocacy organizations could use the diagnostic-delay (physicians seen) and insurance/disability-denial percentages to anticipate and prepare for care-access obstacles tied to contested Lyme treatment guidelines.
- Payers or policymakers could use the hospital-access-difficulty and insurer-requirement percentages to evaluate how guideline-driven coverage policies affect access to care for patients with persistent Lyme disease symptoms, while keeping in mind the non-random survey sample and lack of a document-derived cost model.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 134 Lyme-related terms (for example, "Lyme", "Borrelia", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Johnson 2011.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Share seeing 10+ physicians before Lyme diagnosis (percent), default 37.5, source: Table 2, p.68 of the document
- Share traveling more than 50 miles for Lyme treatment (percent), default 49.5, source: Table 2, p.68 of the document
- Share reporting difficulty obtaining local hospital treatment (percent), default 81.7, source: Table 2, p.68 of the document (among n=963 who sought local hospital treatment)
- Share denied new insurance coverage after Lyme diagnosis (percent), default 39.9, source: Table 2, p.68 of the document (among n=416 who applied for a new policy post-diagnosis)
- Share denied disability benefits for guideline non-conformity (percent), default 38.6, source: Table 2, p.68 of the document (among n=739 who applied for disability benefits)
- Share with at least one ER visit due to Lyme symptoms (percent), default 53.5, source: Table 3, p.69 of the document (complement of the 46.5% 'Never' category)

OUTPUTS (5)
-----------
- Share seeing 10+ physicians before diagnosis: 37.5 (percent) at default assumptions
- Share traveling over 50 miles for treatment: 49.5 (percent) at default assumptions
- Share reporting difficulty obtaining hospital treatment: 81.7 (percent) at default assumptions
- Insurance denial percent minus disability-benefit denial percent (positive = insurance denial more common; negative = disability denial more common): 1.3 (percentage points) at default assumptions
- Share with at least one ER visit tied to Lyme symptoms: 53.5 (percent) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Johnson L et al. Healthcare access and burden of care for patients with Lyme disease: a large United States survey. Health Policy. 2011
  PubMed: https://pubmed.ncbi.nlm.nih.gov/21676482/
  DOI: https://doi.org/10.1016/j.healthpol.2011.05.007

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.