================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : EwGLkCyqnuHL-A2x8rh6dAnl
    Generated   : 2026-10-07 13:15:18 UTC
================================================================

TITLE
-----
Lyme Antibiotic Retreatment Trials: Statistical Power and Adverse-Event Reanalysis

BOUNDARY
--------
This simulation reproduces only the statistical significance findings and trial-specific adverse-event counts reported in a biostatistical reanalysis of four NIH-funded randomized, placebo-controlled Lyme disease antibiotic-retreatment trials. It contains no dollar costs, productivity-loss, caregiving-time, or insurance-access data, because the document reports none; it must not be used to answer financial what-if questions about retreatment. It also does not pool the four trials' differing populations, outcome measures, or follow-up windows into a single benefit or harm estimate, because the document explicitly states this would not be valid.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed biostatistical reanalysis of the four NIH-funded randomized, placebo-controlled trials that current (as of the paper's 2012 publication) Lyme disease guidelines relied on to recommend against antibiotic retreatment for patients with persistent symptoms after a standard course of treatment. The authors argue that the two Klempner trials, and one outcome in the Krupp trial, were designed around unrealistically large target treatment effects and were likely underpowered, so their 'no significant benefit' conclusions do not prove retreatment is ineffective. The Krupp trial's fatigue outcome showed a statistically significant, sustained improvement with retreatment; the Fallon trial's 12-week cognitive-function outcome did not reach statistical significance by the paper's own threshold (p=0.053 vs. its stated p<0.05 cutoff) and was not sustained at 24 weeks, while secondary Fallon analyses found improvement in fatigue, pain, and physical functioning specifically among patients with worse baseline symptom severity. The paper reports trial-level counts of treatment-related adverse events (e.g., 6 of 55 Krupp participants; 7 of 37 Fallon participants, 18.9%) but provides no dollar costs, productivity-loss, caregiving, or insurance-access data for Lyme disease.

WHY THIS COULD BE USEFUL
------------------------
This document could inform clinicians, Lyme disease patients/advocates, and research funders or guideline panels evaluating whether antibiotic retreatment should be considered for patients with persistent symptoms after standard Lyme treatment. It contains no cost, insurance, or productivity data, so it cannot by itself answer financial what-if questions about retreatment; its value is in clarifying which trial findings about benefit and harm are statistically well-supported versus likely artifacts of underpowered study design, and in flagging where treatment guidelines may have overstated the strength of 'no benefit' conclusions. Clinicians and patients weighing retreatment could use the documented adverse-event counts and the fatigue/cognitive effect-size findings as qualitative risk-benefit inputs, while trial designers or funders could use the power/sample-size critique to scope better-designed future retreatment trials.

WHAT YOU COULD DO WITH IT
-------------------------
- A clinician or patient considering IV ceftriaxone retreatment for persistent Lyme symptoms could weigh the trial-specific adverse-event counts (Krupp: 6/55; Fallon: 7/37, 18.9%) against the Krupp fatigue-improvement finding and the Fallon secondary pain/physical-function findings in patients with worse baseline severity, understanding these are small, trial-specific counts rather than population-wide incidence or benefit rates.
- A guideline panel or research funder designing future retreatment RCTs could use the document's sample-size and minimum-clinically-important-difference critique (e.g., the finding that the Klempner trials' design treatment effects were several times larger than published MCIDs) to set more realistic, adequately powered enrollment targets and avoid repeating the same design flaws.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 106 Lyme-related terms (for example, "Lyme", "borreliosis", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
DeLong 2012.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Fallon trial 12-week cognitive-function p-value (p-value), default 0.053, source: Document Results, Section 3 (Fallon trial 12-week cognitive-function outcome, p=0.053); 0.01-0.2 range is an assumed exploration bound, not from the source
- Significance threshold (p-value cutoff) (p-value), default 0.05, source: Document applies p<0.05 as its own cutoff when describing the Fallon trial result; 0.01-0.1 range is an assumed exploration bound, not from the source
- Krupp trial treatment-related adverse events (count) (count), default 6, source: Document Section 3.2.1, Krupp et al. STOP-LD trial summary (6 of 55 randomized patients with significant adverse events); range reflects the trial's own enrollment size, not an assumed bound
- Krupp trial total randomized patients (count), default 55, source: Document Section 3.2.1 (55 total randomized: 28 ceftriaxone, 27 placebo); 10-100 range is an assumed exploration bound, not from the source
- Fallon trial treatment-related adverse events (count) (count), default 7, source: Document Section 3.3.1, Fallon et al. trial summary (7 of 37 randomized subjects, 18.9%, with significant treatment-related adverse events); range reflects the trial's own enrollment size, not an assumed bound
- Fallon trial total randomized patients (count), default 37, source: Document Section 3.3.1 (37 total randomized: 23 ceftriaxone, 14 placebo); 10-80 range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Fallon p-value minus significance threshold (positive = missed cutoff; negative = crossed cutoff): 0.003 (fraction) at default assumptions
- Krupp trial adverse-event rate: 10.91 (percent) at default assumptions
- Fallon trial adverse-event rate: 18.92 (percent) at default assumptions
- Fallon minus Krupp adverse-event rate (positive = Fallon higher; negative = Krupp higher): 8.01 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 397 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::30::Table 12 Dental Services Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::20::Table 05-3 Federal Government Sponsor Expenditures.xlsx, scope: general)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::7::Table 20 Private Health Insurance Benefits and  Non-Medical Insurance Expenditures.xlsx, scope: general)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::0::Table 13 Other Health, Residential, and Personal Care Expenditures.xlsx, scope: general)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::4::Table 17 Durable Medical Equipment Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::22::Table 05-5 Medicare Spending by Sponsor.xlsx, scope: general)

ORIGINAL SOURCE
---------------
Delong AK et al. Antibiotic retreatment of Lyme disease in patients with persistent symptoms: a biostatistical review of randomized, placebo-controlled, clinical trials. Contemp Clin Trials. 2012
  PubMed: https://pubmed.ncbi.nlm.nih.gov/22922244/
  DOI: https://doi.org/10.1016/j.cct.2012.08.009

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.