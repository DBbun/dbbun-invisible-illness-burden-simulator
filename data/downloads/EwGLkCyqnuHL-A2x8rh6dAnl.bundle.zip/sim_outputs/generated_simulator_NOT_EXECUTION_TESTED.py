#!/usr/bin/env python3
"""
Reference implementation of the Lyme Antibiotic Retreatment Trials
statistical power and adverse-event reanalysis spec.

Stdlib only. Reproduces the exact arithmetic of the spec's inputs,
defaults, and output expressions. No synthetic data, no sampling,
no plotting, no CLI.
"""

# ---------------------------------------------------------------------
# Inputs (id -> default value), per spec defaults
# ---------------------------------------------------------------------

DEFAULT_INPUTS = {
    "fallon_pvalue": 0.053,
    "significance_threshold": 0.05,
    "krupp_adverse_events": 6,
    "krupp_total_n": 55,
    "fallon_adverse_events": 7,
    "fallon_total_n": 37,
}

# ---------------------------------------------------------------------
# Output expressions, computed exactly as specified
# ---------------------------------------------------------------------


def compute_outputs(inputs):
    fallon_pvalue = inputs["fallon_pvalue"]
    significance_threshold = inputs["significance_threshold"]
    krupp_adverse_events = inputs["krupp_adverse_events"]
    krupp_total_n = inputs["krupp_total_n"]
    fallon_adverse_events = inputs["fallon_adverse_events"]
    fallon_total_n = inputs["fallon_total_n"]

    # fallon_significance_gap = fallon_pvalue - significance_threshold
    fallon_significance_gap = fallon_pvalue - significance_threshold

    # krupp_adverse_event_rate = (krupp_adverse_events / krupp_total_n) * 100
    krupp_adverse_event_rate = (krupp_adverse_events / krupp_total_n) * 100

    # fallon_adverse_event_rate = (fallon_adverse_events / fallon_total_n) * 100
    fallon_adverse_event_rate = (fallon_adverse_events / fallon_total_n) * 100

    # adverse_event_rate_difference = fallon_adverse_event_rate - krupp_adverse_event_rate
    adverse_event_rate_difference = fallon_adverse_event_rate - krupp_adverse_event_rate

    return {
        "fallon_significance_gap": fallon_significance_gap,
        "krupp_adverse_event_rate": krupp_adverse_event_rate,
        "fallon_adverse_event_rate": fallon_adverse_event_rate,
        "adverse_event_rate_difference": adverse_event_rate_difference,
    }


# ---------------------------------------------------------------------
# Output metadata for display (label, unit)
# ---------------------------------------------------------------------

OUTPUT_META = {
    "fallon_significance_gap": (
        "Fallon p-value minus significance threshold "
        "(positive = missed cutoff; negative = crossed cutoff)",
        "fraction",
    ),
    "krupp_adverse_event_rate": (
        "Krupp trial adverse-event rate",
        "percent",
    ),
    "fallon_adverse_event_rate": (
        "Fallon trial adverse-event rate",
        "percent",
    ),
    "adverse_event_rate_difference": (
        "Fallon minus Krupp adverse-event rate "
        "(positive = Fallon higher; negative = Krupp higher)",
        "percentage points",
    ),
}


def print_outputs(inputs, outputs):
    print("Inputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key} = {value}")
    print()
    print("Outputs:")
    for key, value in outputs.items():
        label, unit = OUTPUT_META[key]
        print(f"  {key} [{unit}]: {value}")
        print(f"    {label}")


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)
    print_outputs(inputs, outputs)