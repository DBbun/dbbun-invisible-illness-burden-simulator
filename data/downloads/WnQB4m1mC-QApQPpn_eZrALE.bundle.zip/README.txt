================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : WnQB4m1mC-QApQPpn_eZrALE
    Generated   : 2026-10-10 13:01:41 UTC
================================================================

TITLE
-----
2022 Long COVID Lost-Labor (Productivity) Cost Simulator

BOUNDARY
--------
This simulation covers only lost-labor/productivity costs (missed workdays x wages, the human-capital approach) for US full-time workers in 2022, as reported in a single research letter using MEPS survey data. It does not include direct medical costs, non-medical costs (travel, paid help), caregiving time, multi-year/lifetime costs, or subgroup breakdowns by sex, age, or race/ethnicity. Associations shown are observational; the study did not test whether earlier diagnosis or treatment changes these costs.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed research letter estimating the 2022 US lost-labor (productivity) costs tied to Long COVID, using nationally representative Medical Expenditure Panel Survey (MEPS) data on full-time workers. It compares self-reported missed workdays and wages across three groups: never had COVID-19, had COVID-19 without Long COVID, and had Long COVID (defined as COVID-19 symptoms lasting 3+ months). The authors report that individuals with Long COVID had more than twice the mean lost-labor cost of those who never had COVID-19, and they extrapolate this to a national population-level estimate of over $12 billion in lost labor costs in 2022. The study used the human-capital approach (hours × wage × missed days) and does not address direct medical costs, non-medical costs, caregiving burden, or long-term financial consequences.

WHY THIS COULD BE USEFUL
------------------------
This document gives employers, disability/paid-leave policymakers, and payers a real-world, nationally representative estimate of lost-labor costs from missed workdays associated with Long COVID in 2022, broken out by per-person mean/median cost and a national population-level total. It is useful for understanding the workforce-productivity dimension of Long COVID's economic burden specifically, but it does not capture direct medical costs, non-medical costs, caregiving burden, or long-term financial consequences, so any simulator built from it should be scoped narrowly to lost-labor/productivity cost rather than total cost of illness. Patients/advocates could use the per-person cost difference to illustrate the real income/productivity impact of Long COVID; policymakers and employers could use the population-level $12.78 billion 2022 estimate to motivate prevention (vaccination) and sick-leave policy discussions, while being clear the paid-sick-leave/LC association shown here did not reach statistical significance.

WHAT YOU COULD DO WITH IT
-------------------------
- Employer benefits/HR policy teams could use the per-person mean lost-labor-cost difference ($1,242.04 for LC vs. never-had-COVID-19, 2022 USD) and the population-level $12.78 billion national estimate to model workforce productivity-cost scenarios under different assumed LC prevalence levels, clearly scoped to missed-workday cost only.
- Disability and paid-sick-leave policymakers could use the sick-leave prevalence figures (81.2% overall, 79.6% among those with LC) alongside the logistic regression result to inform leave-policy discussions, while explicitly noting the paid-sick-leave/LC odds ratio (0.90, 95% CI 0.66–1.23) did not reach statistical significance (p=0.51) and should not be presented as evidence of an association.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 18 Long COVID-related terms (for example, "Long COVID", "post-acute sequelae", "post-COVID"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Liu-Galvin 2025.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (7)
--------------
- Mean lost-labor cost, Long COVID group (USD/person/year), default 1944.46, source: Observed value from Results, p.2 and Table 1; the 1800-2500 exploration range is an assumed bound chosen so it cannot overlap with the other two group ranges, preserving the document's own reported group ordering.
- Mean lost-labor cost, had COVID-19 without Long COVID (USD/person/year), default 1465.55, source: Observed value from Table 1 and Results, p.2; the 1150-1750 exploration range is an assumed bound chosen so it cannot overlap with the never-had-COVID-19 or Long COVID ranges.
- Mean lost-labor cost, never had COVID-19 (USD/person/year), default 702.42, source: Observed value from Table 1; the 300-1100 exploration range is an assumed bound chosen so it cannot overlap with the other two group ranges.
- US full-time workers, 2022 (BLS count) (count), default 131960000, source: Observed value cited in Results, p.2 (BLS full-time workforce count used in the document's own national extrapolation); the 100,000,000-150,000,000 range is an assumed exploration bound, not from the source.
- Long COVID prevalence in study sample (percent), default 7.8, source: Observed value from Results, p.2 (weighted prevalence among the 2022 MEPS full-time worker study sample, not the general US adult population); the 0-20 range is an assumed exploration bound.
- Paid sick leave prevalence, overall study sample (percent), default 81.2, source: Observed value from Results, p.2.
- Paid sick leave prevalence, Long COVID group (percent), default 79.6, source: Observed value from Results, p.2.

OUTPUTS (5)
-----------
- Mean lost-labor cost gap: Long COVID minus never-had-COVID-19 (positive = Long COVID group higher): 1,242 (USD/person/year) at default assumptions
- Mean lost-labor cost gap: had COVID-19 without Long COVID minus never-had-COVID-19 (positive = COVID-without-LC group higher): 763.13 (USD/person/year) at default assumptions
- Mean lost-labor cost gap: Long COVID minus had-COVID-19-without-LC (positive = Long COVID group higher): 478.91 (USD/person/year) at default assumptions
- National 2022 lost-labor cost attributable to Long COVID (population-scaled): 12,784,168,675 (USD) at default assumptions
- Paid sick leave prevalence gap: overall sample minus Long COVID group (positive = overall sample higher, negative = Long COVID group higher): 1.6 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 464 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- bea/regional_economics  (unit bea/regional_economics/CAEMP25N.zip::52::CAEMP25N_US_2001_2022.csv, scope: general)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::436::SAGDP8_US_1997_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::58::SAGDP2_US_1997_2025.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::247::SAGDP5_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::310::SAGDP6_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::121::SAGDP3_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::373::SAGDP7_US_1997_2024.csv, scope: general)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::184::SAGDP4_US_1997_2024.csv, scope: general)

ORIGINAL SOURCE
---------------
Liu-Galvin R et al. Economic Burden of Long COVID: Lost Labor Costs in US Adults. J Am Board Fam Med. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41491558/
  DOI: https://doi.org/10.3122/jabfm.2025.250059R1

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.