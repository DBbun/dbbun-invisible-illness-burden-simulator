#!/usr/bin/env python3
"""
2022 Long COVID Lost-Labor (Productivity) Cost Simulator
Reference implementation of the interactive spec (standard library only).

Boundary: covers only lost-labor/productivity costs (missed workdays x wages)
for US full-time workers in 2022, per a single research letter using MEPS data.
Does not include medical costs, non-medical costs, caregiving time, or
multi-year/lifetime costs. Associations are observational.
"""

# ---------------------------------------------------------------------------
# Default inputs
# ---------------------------------------------------------------------------

DEFAULT_INPUTS = {
    "mean_cost_long_covid": 1944.46,      # USD/person/year
    "mean_cost_covid_no_lc": 1465.55,     # USD/person/year
    "mean_cost_never_covid": 702.42,      # USD/person/year
    "fulltime_workers": 131960000,        # count
    "lc_prevalence": 7.8,                 # percent
    "sick_leave_overall": 81.2,           # percent
    "sick_leave_lc": 79.6,                # percent
}


# ---------------------------------------------------------------------------
# Output calculations
# ---------------------------------------------------------------------------

def cost_diff_lc_vs_never(inputs):
    return inputs["mean_cost_long_covid"] - inputs["mean_cost_never_covid"]


def cost_diff_covidnolc_vs_never(inputs):
    return inputs["mean_cost_covid_no_lc"] - inputs["mean_cost_never_covid"]


def cost_diff_lc_vs_covidnolc(inputs):
    return inputs["mean_cost_long_covid"] - inputs["mean_cost_covid_no_lc"]


def population_lost_labor_cost(inputs):
    gap = cost_diff_lc_vs_never(inputs)
    return gap * inputs["fulltime_workers"] * (inputs["lc_prevalence"] / 100)


def sick_leave_prevalence_gap(inputs):
    return inputs["sick_leave_overall"] - inputs["sick_leave_lc"]


def compute_outputs(inputs):
    return {
        "cost_diff_lc_vs_never": cost_diff_lc_vs_never(inputs),
        "cost_diff_covidnolc_vs_never": cost_diff_covidnolc_vs_never(inputs),
        "cost_diff_lc_vs_covidnolc": cost_diff_lc_vs_covidnolc(inputs),
        "population_lost_labor_cost": population_lost_labor_cost(inputs),
        "sick_leave_prevalence_gap": sick_leave_prevalence_gap(inputs),
    }


# ---------------------------------------------------------------------------
# Trajectory: cumulative excess lost-labor cost per Long COVID worker
# over 5 years, flat projection, 2022 USD, no inflation.
# ---------------------------------------------------------------------------

def cumulative_excess_cost_per_worker(inputs, periods=5):
    gap = cost_diff_lc_vs_never(inputs)
    series = []
    prev = 0.0
    for _ in range(periods):
        prev = prev + gap
        series.append(prev)
    return series


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    outputs = compute_outputs(inputs)

    print("=== Inputs (defaults) ===")
    for k, v in inputs.items():
        print(f"{k}: {v}")

    print("\n=== Outputs ===")
    print(f"cost_diff_lc_vs_never (USD/person/year): "
          f"{outputs['cost_diff_lc_vs_never']:.2f}")
    print(f"cost_diff_covidnolc_vs_never (USD/person/year): "
          f"{outputs['cost_diff_covidnolc_vs_never']:.2f}")
    print(f"cost_diff_lc_vs_covidnolc (USD/person/year): "
          f"{outputs['cost_diff_lc_vs_covidnolc']:.2f}")
    print(f"population_lost_labor_cost (USD): "
          f"{outputs['population_lost_labor_cost']:.2f}")
    print(f"sick_leave_prevalence_gap (percentage points): "
          f"{outputs['sick_leave_prevalence_gap']:.2f}")

    print("\n=== Trajectory: cumulative_excess_cost_per_worker (5 years) ===")
    traj = cumulative_excess_cost_per_worker(inputs, periods=5)
    for year, value in enumerate(traj, start=1):
        print(f"Year {year}: {value:.2f} USD/person")