================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : kQIx4BvIqV6PnMqy4efSlw96
    Generated   : 2026-10-10 14:51:04 UTC
================================================================

TITLE
-----
Chronic Chest Pain and Numbness After Thoracoscopic Surgery for Pneumothorax: Technique and Chest-Tube Comparisons

BOUNDARY
--------
This simulation covers only the rates of chronic chest pain (pain scored 3 or higher out of 10, lasting at least 2 months) and chronic chest-wall paresthesia (numbness/altered sensation lasting at least 2 months) reported in a retrospective, 9-center Italian cohort study of 920 patients aged 40 or younger who had video-assisted thoracoscopic surgery (VATS) for a first spontaneous lung collapse (primary spontaneous pneumothorax), followed for a median of 68 months. It compares these rates across pleurodesis technique (the method used to make the lung stick to the chest wall to prevent recurrence) and chest tube size. It contains no dollar costs, insurance data, productivity-loss data, or validated quality-of-life scores, and cannot be used to estimate the financial burden of these complications.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a retrospective, multicenter (9 Italian centers, 2007-2017) study of 920 patients aged 40 or younger who had video-assisted thoracoscopic surgery (VATS) for primary spontaneous pneumothorax, followed by telephone interview for a median of 68 months. It reports that 8% of patients developed chronic chest pain (rated at least 3 on a 0-10 pain scale) and 22% developed chronic chest-wall paresthesia (numbness/altered sensation) lasting at least 2 months after surgery. The choice of pleurodesis technique, chest tube size, and how long the chest tube stayed in were independently associated with higher rates of both complications. Despite these incidence rates, the paper reports that no patient with chronic pain and/or paresthesia described any limitation in daily-life activities, and only 0.5% needed regular pain medication. This is a clinical/surgical risk-factor study, not a cost-of-illness analysis - it contains no dollar figures, insurance data, productivity-loss data, or caregiving-burden data.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help surgeons and surgical teams compare expected rates of chronic chest pain and paresthesia across different pleurodesis techniques, chest tube sizes, and chest-tube dwell times when planning VATS for primary spontaneous pneumothorax in young patients. Patients and advocates could use it to understand the documented likelihood and typical severity (mostly not requiring regular analgesia, and not reported to limit daily activities) of these long-term complications before consenting to surgery. Because the document contains no cost, insurance, or productivity data, it cannot inform payer/policy cost-of-illness questions; any economic extension would require separately sourced cost data clearly labeled as not from this document.

WHAT YOU COULD DO WITH IT
-------------------------
- Surgeons or patients could use a simulator to compare the document's own reported incidence of chronic chest pain and paresthesia across pleurodesis techniques (partial pleurectomy, pleural abrasion, pleural electrocauterization, talc poudrage) and chest tube sizes (24F vs 28F) to inform preoperative counseling and technique selection.
- Quality-improvement or surgical-protocol teams could use the reported association between postoperative chest tube duration and both outcomes to evaluate whether an early-removal tube-management policy is likely to reduce long-term chronic pain/paresthesia rates in their own practice, as this single cohort reported it.

DETECTED FOCUS
--------------
other: Labeled reuse demonstration chosen by the owner; no federal evidence pack was curated for this condition.

SOURCE FILES
------------
Cattoni 2021.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Chronic chest pain rate after partial pleurectomy (%), default 18, source: Results, p.616 (partial pleurectomy subgroup of the 920-patient cohort); 0-40% range is an assumed exploration bound, not from the source
- Chronic chest pain rate after talc poudrage (%), default 0.3, source: Results, p.616 (talc poudrage subgroup of the 920-patient cohort); 0-10% range is an assumed exploration bound, not from the source
- Chronic chest paresthesia rate after partial pleurectomy (%), default 56, source: Results, p.617 (partial pleurectomy subgroup of the 915-patient paresthesia cohort); 0-80% range is an assumed exploration bound, not from the source
- Chronic chest paresthesia rate after talc poudrage (%), default 6, source: Results, p.617 (talc poudrage subgroup of the 915-patient paresthesia cohort); 0-20% range is an assumed exploration bound, not from the source
- Chronic chest pain rate with 28F chest tube (%), default 11, source: Results, p.616 (28F chest tube subgroup); 0-30% range is an assumed exploration bound, not from the source
- Chronic chest pain rate with 24F chest tube (%), default 2, source: Results, p.616 (24F chest tube subgroup); 0-15% range is an assumed exploration bound, not from the source
- Chronic chest paresthesia rate with 28F chest tube (%), default 27, source: Results, p.617 (28F chest tube subgroup); 0-50% range is an assumed exploration bound, not from the source
- Chronic chest paresthesia rate with 24F chest tube (%), default 7, source: Results, p.617 (24F chest tube subgroup); 0-20% range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Chronic pain rate gap: partial pleurectomy minus talc poudrage (positive = pleurectomy higher, negative = talc poudrage higher): 17.7 (percentage points) at default assumptions
- Chronic paresthesia rate gap: partial pleurectomy minus talc poudrage (positive = pleurectomy higher, negative = talc poudrage higher): 50 (percentage points) at default assumptions
- Chronic pain rate gap: 28F tube minus 24F tube (positive = 28F higher, negative = 24F higher): 9 (percentage points) at default assumptions
- Chronic paresthesia rate gap: 28F tube minus 24F tube (positive = 28F higher, negative = 24F higher): 20 (percentage points) at default assumptions

ORIGINAL SOURCE
---------------
Cattoni M et al. Chronic chest pain and paresthesia after video-assisted thoracoscopy for primary pneumothorax. J Thorac Dis. 2021;13(2):613-620
  PubMed: https://pubmed.ncbi.nlm.nih.gov/33717534/
  DOI: https://doi.org/10.21037/jtd-20-2860

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.