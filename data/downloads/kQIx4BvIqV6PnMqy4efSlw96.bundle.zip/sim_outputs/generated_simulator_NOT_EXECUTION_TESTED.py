def compute_outputs(inputs):
    """Compute all output metrics from the given inputs dict."""
    outputs = {}

    outputs["pain_rate_difference_pleurodesis_technique"] = (
        inputs["pain_rate_partial_pleurectomy"] - inputs["pain_rate_talc_poudrage"]
    )

    outputs["paresthesia_rate_difference_pleurodesis_technique"] = (
        inputs["paresthesia_rate_partial_pleurectomy"]
        - inputs["paresthesia_rate_talc_poudrage"]
    )

    outputs["pain_rate_difference_tube_size"] = (
        inputs["pain_rate_28f_tube"] - inputs["pain_rate_24f_tube"]
    )

    outputs["paresthesia_rate_difference_tube_size"] = (
        inputs["paresthesia_rate_28f_tube"] - inputs["paresthesia_rate_24f_tube"]
    )

    return outputs


def default_inputs():
    """Return the default input values as specified."""
    return {
        "pain_rate_partial_pleurectomy": 18,
        "pain_rate_talc_poudrage": 0.3,
        "paresthesia_rate_partial_pleurectomy": 56,
        "paresthesia_rate_talc_poudrage": 6,
        "pain_rate_28f_tube": 11,
        "pain_rate_24f_tube": 2,
        "paresthesia_rate_28f_tube": 27,
        "paresthesia_rate_24f_tube": 7,
    }


OUTPUT_LABELS = {
    "pain_rate_difference_pleurodesis_technique": (
        "Chronic pain rate gap: partial pleurectomy minus talc poudrage "
        "(percentage points)"
    ),
    "paresthesia_rate_difference_pleurodesis_technique": (
        "Chronic paresthesia rate gap: partial pleurectomy minus talc poudrage "
        "(percentage points)"
    ),
    "pain_rate_difference_tube_size": (
        "Chronic pain rate gap: 28F tube minus 24F tube (percentage points)"
    ),
    "paresthesia_rate_difference_tube_size": (
        "Chronic paresthesia rate gap: 28F tube minus 24F tube "
        "(percentage points)"
    ),
}


if __name__ == "__main__":
    inputs = default_inputs()
    results = compute_outputs(inputs)

    print("Inputs (defaults):")
    for key, value in inputs.items():
        print(f"  {key}: {value}")

    print()
    print("Outputs:")
    for key, value in results.items():
        label = OUTPUT_LABELS.get(key, key)
        print(f"  {label}: {value}")