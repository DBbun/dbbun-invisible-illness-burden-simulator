================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : PcxWKkTKrFQ5RNR4_lRDdKuR
    Generated   : 2026-10-06 17:06:13 UTC
================================================================

TITLE
-----
Lyme Disease Diagnosis-Count Gap Simulator (CDC Claims-Based Estimate vs. Surveillance)

BOUNDARY
--------
This simulation reconstructs the case-count correction steps in a CDC dispatch (Kugeler et al., 2021) that estimates how many people are clinically diagnosed and treated for Lyme disease each year using commercial insurance claims (IBM MarketScan, 2010-2018), and compares that corrected estimate to the officially surveilled case count for the same period. It represents only the frequency/case-count burden; it contains no dollar costs, no productivity-loss data, and no demographic (sex, age, race) breakdown of the final estimate - the document itself defers that breakdown to a companion paper. The document explicitly states the gap between its claims-based estimate and the surveillance count reflects a combination of surveillance underreporting and clinical overdiagnosis/overtreatment that it cannot separate; this simulator preserves that ambiguity and does not resolve it. Federal Lyme surveillance line-list data (2008-2021, a separate passive-surveillance data source) show more reported cases among males than females over that period, but this document's own claims-based estimate carries no sex breakdown.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a CDC-authored scientific dispatch (Emerging Infectious Diseases, Feb 2021) that uses commercial health insurance claims data (IBM MarketScan) to estimate how many people are diagnosed and treated for Lyme disease in the United States each year. The authors estimate that Lyme disease was diagnosed and treated in about 476,000 people annually during 2010-2018, notably higher than the approximately 35,000 cases reported annually through official passive public health surveillance in the same period. The gap between these two figures reflects a combination of underreporting in surveillance and overdiagnosis/overtreatment in clinical practice, and the authors explicitly state they cannot determine how much each factor contributes. The document reports no dollar cost figures, no productivity-loss data, and no demographic breakdown of its own diagnosis estimate; it addresses the frequency (case-count) burden of Lyme disease only, not its financial or caregiving cost.

WHY THIS COULD BE USEFUL
------------------------
This document quantifies a large gap between passively surveilled Lyme disease case counts (~35,000/year) and a claims-based estimate of clinically diagnosed-and-treated cases (~476,000/year) for 2010-2018, attributed to a combination of underreporting and overdiagnosis that the authors cannot separate. It contains no cost figures at all, so a simulator built from it can inform discussions of true clinical/diagnostic workload magnitude, surveillance investment, and diagnostic-uncertainty/overdiagnosis awareness for policy and care-delivery audiences, but cannot itself produce a dollar cost-of-illness figure without an external, clearly labeled cost-per-case assumption. Patient/advocate audiences could use it to understand why official case counts likely understate the number of people actually treated, while being careful not to read either number as 'the true incidence.'

WHAT YOU COULD DO WITH IT
-------------------------
- Payers/policy audiences could use the ~476,000 vs ~35,000 comparison to gauge the scale of clinical resource use and surveillance investment needs, while explicitly treating the gap as an unresolved mix of underreporting and overdiagnosis rather than a precise 'true burden' number.
- Care delivery teams could use the ICD-9 undercoding finding (only 43.0% of confirmed/probable/suspect cases had the specific code) to motivate improved coding practices and clinician training, without over-generalizing from the underlying 672-record, 3-state sample.

DETECTED FOCUS
--------------
lyme: The uploaded material contains 45 Lyme-related terms (for example, "Lyme", "Borrelia", "tick-borne"). The content does not contain Long COVID-related terms.

SOURCE FILES
------------
Kugeler 2021.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Age- and state-standardized diagnosed-and-treated patients (pre-undercoding correction) (patients/year), default 205000, source: p.617 (Results); 150,000-260,000 range is an assumed exploration bound, not from the source
- ICD code undercoding correction factor (fraction of qualifying records with the specific Lyme code) (fraction), default 0.43, source: p.617 (Results), based on 672 medical records from NY, MD, and MN chart reviews; 0.30-0.60 range is an assumed exploration bound reflecting the small 3-state sample, not from the source
- Lyme disease cases reported through passive public health surveillance (cases/year), default 35000, source: p.618 (Conclusions); 20,000-50,000 range is an assumed exploration bound, not from the source
- Share of claims-based diagnoses among low-incidence-state residents (%), default 19, source: p.618 (Conclusions); 12-30 range is an assumed exploration bound, not from the source
- Typical share of surveillance-confirmed cases among low-incidence-state residents (%), default 5, source: p.618 (Conclusions); 2-10 range is an assumed exploration bound, not from the source

OUTPUTS (4)
-----------
- Estimated annual diagnosed-and-treated Lyme patients (claims-based, corrected): 476744 (patients/year) at default assumptions
- Claims-based diagnosis estimate minus surveillance-reported cases (positive = claims-based estimate exceeds surveillance count; negative = surveillance count exceeds claims-based estimate): 441744 (patients/year) at default assumptions
- Claims-based diagnosis estimate divided by surveillance-reported cases (fold-difference): 13.6213 (ratio) at default assumptions
- Low-incidence-state diagnosis share minus typical surveillance share (positive = claims-based diagnoses more concentrated in low-incidence states than typical surveillance; negative = less concentrated): 14 (percentage points) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 436 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2008_2021__cdc_qtbi-xd4i.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_1992_2007__cdc_84rx-ksgd.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_2008_2021__cdc_abzs-b3gw.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/aggregated_geography_2022_2023__cdc_x5j9-wybp.csv, scope: lyme)
- cdc/lyme_surveillance  (unit cdc/lyme_surveillance/line_list_no_geography_1992_2007__cdc_e2a5-s9pr.csv, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_County_Table_through_2025.xlsx, scope: lyme)
- cdc/tick_surveillance_2025  (unit cdc/tick_surveillance_2025/Public_Use_Ixodes_Pathogens_County_Table_2026.xlsx, scope: lyme)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)

ORIGINAL SOURCE
---------------
Kugeler KJ et al. Estimating the Frequency of Lyme Disease Diagnoses, United States, 2010-2018. Emerg Infect Dis. 2021
  PubMed: https://pubmed.ncbi.nlm.nih.gov/33496229/
  DOI: https://doi.org/10.3201/eid2702.202731

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.