#!/usr/bin/env python3
"""
Lyme Disease Diagnosis-Count Gap Simulator
(CDC Claims-Based Estimate vs. Surveillance)

Reference implementation of the interactive spec. Standard library only.
"""

DEFAULT_INPUTS = {
    "coded_and_treated_patients": 205000,
    "undercoding_correction_factor": 0.43,
    "surveillance_reported_cases": 35000,
    "low_incidence_state_claims_share": 19,
    "low_incidence_state_typical_share": 5,
}

SCENARIOS = {
    "lower_coding_capture_assumed": {"undercoding_correction_factor": 0.3},
    "higher_coding_capture_assumed": {"undercoding_correction_factor": 0.6},
    "fewer_coded_patients": {"coded_and_treated_patients": 150000},
    "more_coded_patients": {"coded_and_treated_patients": 260000},
    "narrower_low_incidence_gap": {
        "low_incidence_state_claims_share": 12,
        "low_incidence_state_typical_share": 10,
    },
    "wider_low_incidence_gap": {
        "low_incidence_state_claims_share": 30,
        "low_incidence_state_typical_share": 2,
    },
}


def compute_outputs(inputs):
    """Compute the four spec outputs from a dict of inputs."""
    coded_and_treated_patients = inputs["coded_and_treated_patients"]
    undercoding_correction_factor = inputs["undercoding_correction_factor"]
    surveillance_reported_cases = inputs["surveillance_reported_cases"]
    low_incidence_state_claims_share = inputs["low_incidence_state_claims_share"]
    low_incidence_state_typical_share = inputs["low_incidence_state_typical_share"]

    estimated_diagnosed_treated_patients = (
        coded_and_treated_patients / undercoding_correction_factor
    )

    diagnosis_surveillance_gap = (
        estimated_diagnosed_treated_patients - surveillance_reported_cases
    )

    diagnosis_to_surveillance_ratio = (
        estimated_diagnosed_treated_patients / surveillance_reported_cases
    )

    low_incidence_share_difference = (
        low_incidence_state_claims_share - low_incidence_state_typical_share
    )

    return {
        "estimated_diagnosed_treated_patients": estimated_diagnosed_treated_patients,
        "diagnosis_surveillance_gap": diagnosis_surveillance_gap,
        "diagnosis_to_surveillance_ratio": diagnosis_to_surveillance_ratio,
        "low_incidence_share_difference": low_incidence_share_difference,
    }


def run_scenario(overrides=None):
    """Apply overrides on top of the default inputs and compute outputs."""
    inputs = dict(DEFAULT_INPUTS)
    if overrides:
        inputs.update(overrides)
    return inputs, compute_outputs(inputs)


def print_result(title, inputs, outputs):
    print(f"--- {title} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    print(
        "  estimated_diagnosed_treated_patients (patients/year): "
        f"{outputs['estimated_diagnosed_treated_patients']:.2f}"
    )
    print(
        "  diagnosis_surveillance_gap (patients/year): "
        f"{outputs['diagnosis_surveillance_gap']:.2f}"
    )
    print(
        "  diagnosis_to_surveillance_ratio (ratio): "
        f"{outputs['diagnosis_to_surveillance_ratio']:.4f}"
    )
    print(
        "  low_incidence_share_difference (percentage points): "
        f"{outputs['low_incidence_share_difference']:.2f}"
    )
    print()


if __name__ == "__main__":
    base_inputs, base_outputs = run_scenario()
    print_result("Default inputs", base_inputs, base_outputs)

    for scenario_id, overrides in SCENARIOS.items():
        s_inputs, s_outputs = run_scenario(overrides)
        print_result(scenario_id, s_inputs, s_outputs)