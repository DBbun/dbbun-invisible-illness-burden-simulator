================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : NVKsi9A_jC__6cFMb9foLgBj
    Generated   : 2026-10-10 04:34:40 UTC
================================================================

TITLE
-----
Long COVID Symptom Patterns and Self-Reported Work/Economic Impact (Japanese 36-Month Cohort)

BOUNDARY
--------
This simulator reflects only a 515-adult Japanese multicenter cohort of patients hospitalized for COVID-19 (pandemic waves 1-3, January 2020-February 2021), followed by self-report questionnaire to 36 months (survey conducted November 2023-February 2024). It covers self-reported work-performance impairment scores (WHO Health and Work Performance Questionnaire presenteeism/absenteeism) and self-reported 'economic condition worsened' percentages by symptom trajectory group or symptom-count subgroup. It does not include any direct medical costs, non-medical costs, caregiver costs, or monetized lost wages - none of these are reported anywhere in the document. Findings are specific to this hospitalized Japanese cohort and should not be generalized to non-hospitalized populations or other countries.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a Japanese multicenter retrospective cohort study that followed 515 adults hospitalized with COVID-19 (first to third pandemic waves, Jan 2020-Feb 2021) for 36 months using questionnaires. It grouped patients both by symptom trajectory (continuous, relapsed, recovered, late-onset, never) and by symptom-cluster patterns measured at 3 months, then tracked quality of life (SF-36) and self-reported work-productivity (WHO Health and Work Performance Questionnaire presenteeism/absenteeism scores) and subjective economic condition through 36 months. It found that a substantial minority of patients still had persistent or relapsing symptoms (fatigue and dyspnea especially) at 3 years, that patients in the 'multiple symptoms' cluster and the 'continuous' trajectory group had the worst quality-of-life and work-productivity scores, and that a higher proportion of patients with more symptoms or continuous symptoms reported their economic situation had worsened. No dollar costs are reported anywhere in the study; burden is measured only through self-reported scales and percentages within this specific Japanese hospitalized cohort.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help care-delivery teams anticipate which Long COVID symptom patterns (continuous trajectory, 'multiple symptoms' cluster, five-or-more symptoms) are associated with worse self-reported work productivity and subjective economic decline over a 3-year horizon, informing earlier referral to vocational or rehabilitation support within a Japanese hospitalized-COVID population. Patients/advocates could use the relative severity rankings (e.g., which symptom clusters have the worst QOL and productivity scores) to contextualize their own experience, though the document provides no dollar figures to budget against. Payers/policy audiences could use the trajectory/cluster-based productivity-impairment patterns as a signal of which patient profiles may need longer-term disability or return-to-work accommodation, but cannot derive cost estimates from this document alone since it contains no direct medical, non-medical, or monetized indirect cost data.

WHAT YOU COULD DO WITH IT
-------------------------
- Clinicians following COVID-19 patients could use the 3-month symptom-cluster classification (especially the 'multiple symptoms' cluster) as an early flag for patients likely to have persistent, productivity-impairing symptoms at 36 months, prompting earlier workplace-accommodation planning.
- Policy or research teams could use the relative (non-monetized) severity ranking of presenteeism/absenteeism and 'economic condition worsened' proportions across symptom trajectory groups to prioritize which Long COVID phenotypes most need income-support or disability-policy attention, while clearly labeling these as Japanese cohort self-report scores not transferable as dollar figures to other health systems.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 81 Long COVID-related terms (for example, "long COVID", "PASC", "Post-Covid"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Ozawa 2026.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Economic condition worsened, continuous-trajectory group (percent), default 43.6, source: Results/Fig. 5a, p.7; 35-55 range is an assumed exploration bound, not from the source, chosen so sliders cannot reverse the ordering the study found significant (p<0.001) versus the recovered group.
- Economic condition worsened, recovered-trajectory group (percent), default 14.9, source: Results/Fig. 5a, p.7; 5-25 range is an assumed exploration bound, not from the source, chosen so sliders cannot reverse the ordering the study found significant (p<0.001) versus the continuous group.
- Economic condition worsened, five-or-more-symptom group (percent), default 47.3, source: Results, p.6; 20-60 range is an assumed exploration bound, not from the source.
- Economic condition worsened, one-to-four-symptom group (percent), default 24.3, source: Results, p.6; 10-40 range is an assumed exploration bound, not from the source.
- Presenteeism score, continuous-trajectory group (WHO HPQ score (0-100 scale, study's own definition)), default 60, source: Results/Fig. 5b, p.8; 0-100 range reflects the typical WHO HPQ absolute score scale and is an assumed exploration bound, since the source's own scale definition is in a supplementary appendix not included in this excerpt.
- Presenteeism score, 'multiple symptoms' cluster (WHO HPQ score (0-100 scale, study's own definition)), default 48.8, source: Table 2, p.5; 0-100 range reflects the typical WHO HPQ absolute score scale and is an assumed exploration bound, since the source's own scale definition is in a supplementary appendix not included in this excerpt.

OUTPUTS (4)
-----------
- Economic worsening gap: continuous minus recovered trajectory group (percentage points; positive = continuous group's share is higher, negative = recovered group's share is higher): 28.7 (percentage points) at default assumptions
- Economic worsening gap: five-or-more symptoms minus one-to-four symptoms (percentage points; positive = five-or-more-symptom group's share is higher, negative = one-to-four-symptom group's share is higher): 23 (percentage points) at default assumptions
- Presenteeism score, continuous-trajectory group (reported value): 60 (WHO HPQ score (0-100 scale, study's own definition)) at default assumptions
- Presenteeism score, 'multiple symptoms' cluster (reported value): 48.8 (WHO HPQ score (0-100 scale, study's own definition)) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 438 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- bea/regional_economics  (unit bea/regional_economics/SAGDP.zip::562::SAGDP11_US_1998_2025.csv, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::0::Table 13 Other Health, Residential, and Personal Care Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::4::Table 17 Durable Medical Equipment Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::30::Table 12 Dental Services Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::3::Table 16 Retail Prescription Drugs Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::1::Table 14 Home Health Care Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::2::Table 15 Nursing Care Facilities and Continuing Care Retirement Communities Expenditures.xlsx, scope: general)
- cms/nhea_2024  (unit cms/nhea_2024/nhe-tables.zip::7::Table 20 Private Health Insurance Benefits and  Non-Medical Insurance Expenditures.xlsx, scope: general)

ORIGINAL SOURCE
---------------
Ozawa T et al. Japanese nationwide survey to track the impact of long COVID over 3 years. Environ Health Prev Med. 2025
  PubMed: https://pubmed.ncbi.nlm.nih.gov/41161755/
  DOI: https://doi.org/10.1265/ehpm.25-00293

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.