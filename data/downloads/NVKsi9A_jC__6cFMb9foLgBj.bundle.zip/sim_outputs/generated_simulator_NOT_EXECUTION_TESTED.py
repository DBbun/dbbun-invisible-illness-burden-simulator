#!/usr/bin/env python3
"""
Reference implementation of the spec:
"Long COVID Symptom Patterns and Self-Reported Work/Economic Impact
(Japanese 36-Month Cohort)"

Standard library only. Plain arithmetic reference, no synthetic data,
no sampling, no plotting, no CLI.
"""


def compute_outputs(
    economic_worsened_continuous_pct=43.6,
    economic_worsened_recovered_pct=14.9,
    economic_worsened_five_plus_symptoms_pct=47.3,
    economic_worsened_one_to_four_symptoms_pct=24.3,
    presenteeism_continuous_trajectory_score=60,
    presenteeism_multiple_symptoms_cluster_score=48.8,
):
    """Compute all defined outputs from the spec using the given inputs."""

    economic_worsening_gap_trajectory = (
        economic_worsened_continuous_pct - economic_worsened_recovered_pct
    )

    economic_worsening_gap_symptom_count = (
        economic_worsened_five_plus_symptoms_pct
        - economic_worsened_one_to_four_symptoms_pct
    )

    presenteeism_continuous_trajectory_reported = presenteeism_continuous_trajectory_score

    presenteeism_multiple_symptoms_cluster_reported = (
        presenteeism_multiple_symptoms_cluster_score
    )

    return {
        "economic_worsening_gap_trajectory": economic_worsening_gap_trajectory,
        "economic_worsening_gap_symptom_count": economic_worsening_gap_symptom_count,
        "presenteeism_continuous_trajectory_reported": presenteeism_continuous_trajectory_reported,
        "presenteeism_multiple_symptoms_cluster_reported": presenteeism_multiple_symptoms_cluster_reported,
    }


if __name__ == "__main__":
    defaults = {
        "economic_worsened_continuous_pct": 43.6,
        "economic_worsened_recovered_pct": 14.9,
        "economic_worsened_five_plus_symptoms_pct": 47.3,
        "economic_worsened_one_to_four_symptoms_pct": 24.3,
        "presenteeism_continuous_trajectory_score": 60,
        "presenteeism_multiple_symptoms_cluster_score": 48.8,
    }

    results = compute_outputs(**defaults)

    print("Long COVID Symptom Patterns and Self-Reported Work/Economic Impact")
    print("(Japanese 36-Month Cohort) - Reference Calculation\n")

    print("Inputs (defaults):")
    for k, v in defaults.items():
        print(f"  {k}: {v}")

    print("\nOutputs:")
    print(
        "  economic_worsening_gap_trajectory "
        f"(continuous - recovered, percentage points): "
        f"{results['economic_worsening_gap_trajectory']}"
    )
    print(
        "  economic_worsening_gap_symptom_count "
        f"(five-or-more - one-to-four, percentage points): "
        f"{results['economic_worsening_gap_symptom_count']}"
    )
    print(
        "  presenteeism_continuous_trajectory_reported "
        f"(WHO HPQ score, continuous-trajectory group): "
        f"{results['presenteeism_continuous_trajectory_reported']}"
    )
    print(
        "  presenteeism_multiple_symptoms_cluster_reported "
        f"(WHO HPQ score, 'multiple symptoms' cluster): "
        f"{results['presenteeism_multiple_symptoms_cluster_reported']}"
    )