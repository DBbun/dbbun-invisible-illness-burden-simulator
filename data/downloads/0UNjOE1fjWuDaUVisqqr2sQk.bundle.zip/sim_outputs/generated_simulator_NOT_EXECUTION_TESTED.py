#!/usr/bin/env python3
"""
Long COVID Phenotyping vs. Diagnosis-Code Surveillance Gap Explorer

Reference implementation of the spec's arithmetic using plain Python
standard library only. Default inputs reproduce the document's
reported default scenario.
"""


# ----------------------------- Default Inputs -----------------------------

DEFAULT_INPUTS = {
    "phenotyping_prevalence_pct": 16.28,
    "code_based_surveillance_pct": 7,
    "chronic_pasc_rate_pct": 14.54,
    "national_covid_case_count": 103000000,
    "decade_compounded_increase_pct": 47,
}


# ----------------------------- Output Expressions -----------------------------

def surveillance_gap_pp(phenotyping_prevalence_pct, code_based_surveillance_pct, **_):
    """Phenotyping-identified prevalence minus code-based surveillance rate (pp)."""
    return phenotyping_prevalence_pct - code_based_surveillance_pct


def national_chronic_pasc_estimate(chronic_pasc_rate_pct, national_covid_case_count, **_):
    """National chronic-PASC projection (cohort rate applied to cited national case count)."""
    return (chronic_pasc_rate_pct / 100) * national_covid_case_count


def chronic_share_of_pasc_pct(chronic_pasc_rate_pct, phenotyping_prevalence_pct, **_):
    """Chronic conditions as a share of identified PASC patients (%)."""
    return (chronic_pasc_rate_pct / phenotyping_prevalence_pct) * 100


def projected_future_chronic_prevalence_pct(chronic_pasc_rate_pct, decade_compounded_increase_pct, **_):
    """Illustrative projected future chronic PASC prevalence (%)."""
    return chronic_pasc_rate_pct + (chronic_pasc_rate_pct * decade_compounded_increase_pct) / 100


def compute_all_outputs(inputs):
    """Compute all outputs for a given dict of inputs, returning a dict."""
    return {
        "surveillance_gap_pp": surveillance_gap_pp(**inputs),
        "national_chronic_pasc_estimate": national_chronic_pasc_estimate(**inputs),
        "chronic_share_of_pasc_pct": chronic_share_of_pasc_pct(**inputs),
        "projected_future_chronic_prevalence_pct": projected_future_chronic_prevalence_pct(**inputs),
    }


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    results = compute_all_outputs(inputs)

    print("Long COVID Phenotyping vs. Diagnosis-Code Surveillance Gap Explorer")
    print("=" * 70)
    print("\nInputs (defaults):")
    for k, v in inputs.items():
        print(f"  {k}: {v}")

    print("\nOutputs:")
    print(
        f"  surveillance_gap_pp: {results['surveillance_gap_pp']:.4f} "
        f"percentage points"
    )
    print(
        f"  national_chronic_pasc_estimate: "
        f"{results['national_chronic_pasc_estimate']:.2f} individuals"
    )
    print(
        f"  chronic_share_of_pasc_pct: "
        f"{results['chronic_share_of_pasc_pct']:.4f} percent"
    )
    print(
        f"  projected_future_chronic_prevalence_pct: "
        f"{results['projected_future_chronic_prevalence_pct']:.4f} percent"
    )