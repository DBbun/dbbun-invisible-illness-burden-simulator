================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : 0UNjOE1fjWuDaUVisqqr2sQk
    Generated   : 2026-10-10 17:16:09 UTC
================================================================

TITLE
-----
Long COVID Phenotyping vs. Diagnosis-Code Surveillance Gap Explorer

BOUNDARY
--------
This simulator reflects only what a 2026 JAMA Network Open EHR cohort study (457,950 COVID-19 patients, 58 hospitals, 4 US regions, Q2 2020-Q2 2024) reported: AI phenotyping-identified PASC (Long COVID) prevalence, chronic-condition prevalence, a cited diagnosis-code surveillance benchmark, and the study's own cautious national and decade-ahead projections. It contains no dollar costs, income loss, or caregiving-time data, because the source document reports none; all cost language is intentionally absent.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a peer-reviewed cohort study (JAMA Network Open, 2026) that used a validated AI phenotyping algorithm (P2RC) on electronic health record data from 457,950 COVID-19 patients across 58 hospitals in four US regions (New England, Southeast Texas, Southern California, Western Pennsylvania) to estimate how many people actually develop Long COVID (PASC), compared with how many are captured by standard diagnostic coding. The algorithm identified PASC in 16.28% of COVID-19 patients overall, more than double the under-7% typically found by diagnosis-code-based surveillance, and found that 89.31% of identified PASC cases involved at least one chronic condition requiring ongoing management (14.54% of all COVID-19 patients in the cohort). The study also found substantial regional differences in which organ systems were affected, and found that cumulative PASC prevalence kept rising through mid-2024, suggesting an accumulating rather than resolving burden. The document reports no dollar costs, lost-income, caregiving-time, or out-of-pocket figures; its burden evidence is limited to prevalence, chronicity, and surveillance-gap percentages drawn from EHR/diagnostic-coding data.

WHY THIS COULD BE USEFUL
------------------------
This study quantifies how badly standard diagnostic coding undercounts Long COVID and how much of that invisible burden is chronic rather than self-limiting, which is directly relevant to care-delivery teams planning capacity for ongoing PASC management, payers/policy audiences assessing why reimbursement and disability-recognition systems may be miscalibrated relative to true caseloads, and patient/advocate audiences seeking validation that under-diagnosis is a documented system failure rather than an individual experience. A simulator could let users compare 'code-based visible' vs. 'phenotyping-estimated true' PASC burden by region and over time, and explore how the accumulating (not resolving) prevalence trend might project forward -- while making clear no cost, income-loss, or caregiving-burden data exist in this source to attach dollar figures to those scenarios. The document's own national extrapolation (~15 million) and decade-compounded projection (13%-81% relative increase) can be surfaced as explicitly labeled projections, not observed counts.

WHAT YOU COULD DO WITH IT
-------------------------
- Health-system capacity planners could use the regional chronic-PASC prevalence rates (12.03%-19.88%) and the accumulating (non-resolving) temporal trend to scenario-plan ongoing specialty-care demand, while being shown that Southeast Texas's trend did not reach statistical significance and its point estimates are based on a much smaller sample.
- Policy/payer audiences could use the gap between code-based surveillance (<7%) and phenotyping-identified prevalence (13.64%-22.69%) to illustrate, in a what-if explorer, how reimbursement and disability-determination systems calibrated to diagnosis-code counts may be structurally missing a large share of chronically affected patients -- without inferring a specific dollar undercount, since this document provides none.

DETECTED FOCUS
--------------
longCovid: The uploaded material contains 132 Long COVID-related terms (for example, "Long COVID", "PASC", "U09.9"). The content does not contain Lyme-related terms.

SOURCE FILES
------------
Tian 2026 surveillance gaps.pdf

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Phenotyping-identified PASC prevalence (percent), default 16.28, source: Results 'PASC Prevalence' p.4; Table 1. The 13.64-22.69 range is the document's own reported regional range, used here as the exploration bounds.
- Diagnosis-code-based surveillance rate (percent), default 7, source: Discussion p.7-8 (citing refs 15-17, 35), which states broader diagnosis-code-based approaches identify well under 7% of cases; the 1.0-7.0 range is an assumed exploration bound chosen to stay below the document's reported code-based ceiling, not a reported lower bound.
- Chronic PASC prevalence among all COVID-19 patients (percent), default 14.54, source: Results 'Chronic Disease Burden' p.6; Table 2. The 12.03-19.88 range is the document's own reported regional range.
- National COVID-19 case count (external, cited) (individuals), default 103000000, source: Discussion p.7-8 (citing CDC surveillance, ref 36); the 90,000,000-110,000,000 range is an assumed exploration bound around the cited ~103 million figure, not from the source.
- Projected decade-compounded relative increase (percent), default 47, source: Discussion p.8. The 13-81 range is the document's own reported projection range for the 3 regions with statistically significant quarterly trends; the default of 47 is an assumed midpoint, not a document-stated central estimate.

OUTPUTS (4)
-----------
- Phenotyping-identified prevalence minus code-based surveillance rate (positive = phenotyping found more cases than coding captured): 9.28 (percentage points) at default assumptions
- National chronic-PASC projection (cohort rate applied to cited national case count): 14,976,200 (individuals) at default assumptions
- Chronic conditions as a share of identified PASC patients: 89.31 (percent) at default assumptions
- Illustrative projected future chronic PASC prevalence: 21.37 (percent) at default assumptions

FEDERAL KNOWLEDGE SOURCES REFERENCED
-------------------------------------
10 of 490 eligible federal decision-knowledge
units were locally retrieved as supporting context for the model. Raw federal files
were not opened. The full retrieval scoring detail is left out of this public copy.

- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::11::Table and Index/icd10cm_index_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/fy-2026-icd-10-cm-coding-guidelines.pdf, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::7::Table and Index/icd10cm_tabular_2026.pdf, scope: both)
- cdc/long_covid_aggregate_2022_2024  (unit cdc/long_covid_aggregate_2022_2024/cdc_post_covid_conditions_gsea-w83j.csv, scope: long_covid)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::4::Code Descriptions/icd10cm_order_2026.txt, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::2::Table and Index/icd10cm_eindex_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::5::Table and Index/icd10cm_drug_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::6::Table and Index/icd10cm_neoplasm_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-tables-tabular-index.zip::9::Table and Index/icd10cm_tabular_2026.xml, scope: both)
- cms/icd10cm_2026_04  (unit cms/icd10cm_2026_04/april-1-2026-code-descriptions-tabular-order.zip::1::Code Descriptions/icd10cmCodesFile.pdf, scope: both)

ORIGINAL SOURCE
---------------
Tian J et al. Long COVID Persistence and Surveillance Gaps Across 58 US Hospitals. JAMA Netw Open. 2026;9(5):e2614909
  PubMed: https://pubmed.ncbi.nlm.nih.gov/42201733/
  DOI: https://doi.org/10.1001/jamanetworkopen.2026.14909

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.